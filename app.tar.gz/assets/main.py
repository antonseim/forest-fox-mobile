import asyncio
import platform
import pygame
import random
import sys
import math
import json, os

SAVE_FILE = os.path.expanduser('~/.jungle_foxes_items.json')
TREASURES = ['acorn','feather','crystal','bell','badge']   # little collectibles from the shop
ITEM_KEYS = ('berries','sticks','stones','axes','bombs') + tuple(TREASURES) + ('dagger',)   # dagger = the wizard's gift
def load_items():
    try:
        if sys.platform == 'emscripten': d = json.loads(platform.window.localStorage.getItem('forestfox_items') or '{}')
        else:
            with open(SAVE_FILE) as fh: d = json.load(fh)
        return {k:(0 if k == 'dagger' else int(d.get(k,0))) for k in ITEM_KEYS}   # the dagger never carries over
    except Exception:
        return {k:0 for k in ITEM_KEYS}
def save_items(inv):
    try:
        if sys.platform == 'emscripten': platform.window.localStorage.setItem('forestfox_items', json.dumps(inv))
        else:
            with open(SAVE_FILE,'w') as fh: json.dump(inv, fh)
    except Exception:
        pass

pygame.init()
WIDTH, HEIGHT = 1200, 700
DISPLAY = pygame.display.set_mode((WIDTH, HEIGHT))
# Everything is drawn on this solid canvas and copied to the window once per frame.
# (A Mac game window has its own see-through channel: drawing sprites straight onto it
#  punched see-through holes that showed up as BLACK boxes behind the fox, rocks, berries and trees.)
screen = pygame.Surface((WIDTH, HEIGHT), 0, 32)
def _ready(img):
    """finished sprite: see-through background, in the fastest format for the screen"""
    return img.convert_alpha()
pygame.display.set_caption("Forest Fox – Final Surprise Edition")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 48)
bigfont = pygame.font.Font(None, 100)
tinyfont = pygame.font.Font(None, 28)

# Colors
GREEN = (34, 139, 34)
DARK_GREEN = (0, 100, 0)
MOUNTAIN = (100, 100, 100)
SNOW = (240, 240, 255)
BROWN = (139, 69, 19)
RED = (220, 20, 20)
ORANGE = (255, 150, 0)
GOLD = (255, 215, 0)
GRAY = (90, 90, 90)
YELLOW = (255, 255,100)
WHITE = (255,255,255)
BLACK = (0,0,0)
RAIN_COLOR = (100,150,200,100)

TILE = 40
MAP_W, MAP_H = 450, 300   # 1.5x bigger world
WORLD_W = MAP_W * TILE
WORLD_H = MAP_H * TILE
WS = 1.5          # world scale: landmark spots and distances grow with the map
AREA = WS * WS    # how many more things fit (same density on a bigger map)
VILLAGE_X, VILLAGE_Y = WORLD_W - int(1500*WS), int(800*WS)
# the village is a big open area to explore (no longer ends the game)
VILLAGE_RECT = pygame.Rect(VILLAGE_X-100, VILLAGE_Y-100, 1200, 900)
# touch the golden fox statue in the middle of the village to win
STATUE_RECT = pygame.Rect(0, 0, 70, 90); STATUE_RECT.center = VILLAGE_RECT.center

# 4× bigger mini-map top-left
MINI_W = int(MAP_W * 0.5 / WS)   # mini-map stays the same size on screen
MINI_H = int(MAP_H * 0.5 / WS)

# Change to True to bring the trolls back
TROLLS_ON = True
# Change to True to bring back the 2-minute timer
TIMER_ON = True

TIME_LIMIT_MS = 180000
start_ticks = 0

# ================= ANIME ART: soft shading, clean dark outlines, shiny eyes =================
# (everything is drawn once and kept, so the game stays fast)
OUTLINE = (150, 105, 80)  # soft warm wood-brown for furniture lines (never black)
INK = (95, 55, 100)       # soft plum edge for TEXT (readable, never black)
def _lerp(a, b, t): return tuple(int(a[i] + (b[i]-a[i])*t) for i in range(3))
def _light(c, k=55): return tuple(min(255, v+k) for v in c[:3])
def _dark(c, k=55): return tuple(max(0, v-k) for v in c[:3])
def _vgrad(w, h, top, bot):
    g = pygame.Surface((w, h), 0, 32)   # solid (no see-through channel)
    for y in range(h): pygame.draw.line(g, _lerp(top, bot, y/max(1, h-1)), (0, y), (w, y))
    return g
_CEL = {}
def _shade(surf, low=200):
    """anime cel shading: a bright lit top and a soft-edged 2-tone shadow (a little cool lavender) on the lower part.
    keeps see-through parts see-through; the shadow mask is made once per size (fast)"""
    w, h = surf.get_size(); key = (w, h, low)
    if key not in _CEL:
        g = pygame.Surface((w, h), 0, 32); g.fill((255,255,255))
        sh = low + (255 - low)*0.3; y0 = int(h*0.55); soft = max(2, h//12)
        for y in range(y0, h):
            t = min(1.0, (y - y0)/soft); v = 255 - (255 - sh)*t
            pygame.draw.line(g, (int(max(0, v-6*t)), int(max(0, v-9*t)), int(v)), (0, y), (w, y))
        _CEL[key] = g
    surf.blit(_CEL[key], (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    return surf
def _outline(surf, col=None, th=1):
    # edge = a darker version of the thing's OWN colors (no black lines)
    if col is None:
        o = surf.copy(); o.fill((150,128,150,255), special_flags=pygame.BLEND_RGBA_MULT)   # deeper, slightly plum anime line
    else:
        m = pygame.mask.from_surface(surf, 60)
        o = m.to_surface(setcolor=col+(255,), unsetcolor=(0,0,0,0))
    out = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    for dx in range(-th, th+1):
        for dy in range(-th, th+1):
            if dx or dy: out.blit(o, (dx, dy))
    out.blit(surf, (0, 0))
    return out
def _shine_eye(s, cx, cy, rw, rh, iris):
    pygame.draw.ellipse(s, _dark(iris, 45), (cx-rw-1, cy-rh-1, 2*rw+2, 2*rh+2))
    pygame.draw.ellipse(s, iris, (cx-rw, cy-rh, 2*rw, 2*rh))
    pygame.draw.ellipse(s, _dark(iris, 30), (cx-rw, cy-rh, 2*rw, rh+1))           # darker top of the iris (anime eye)
    pygame.draw.ellipse(s, _light(iris, 80), (cx-rw+1, cy, 2*rw-2, rh))          # lighter bottom of the eye
    pygame.draw.ellipse(s, (25,12,25), (cx-max(1,rw//2), cy-rh//2, max(2,rw), max(2,rh)))   # pupil
    pygame.draw.circle(s, WHITE, (cx-max(1,rw//3), cy-max(1,rh//3)), max(1, (rw+1)//2))      # big sparkle
    pygame.draw.circle(s, WHITE, (cx+max(1,rw//3), cy+max(1,rh//3)), 1)                       # little sparkle
# ---------- ANIME MAX helpers (all art is made once and cached) ----------
_DISC = {}
def _disc(th):   # round pen tip
    if th not in _DISC: _DISC[th] = [(dx, dy) for dx in range(-th, th+1) for dy in range(-th, th+1) if (dx or dy) and dx*dx + dy*dy <= th*th + th//2]
    return _DISC[th]
def _ink(surf, col, th=2):   # bold clean dark outline all the way round (same size)
    m = pygame.mask.from_surface(surf, 60)
    o = m.to_surface(setcolor=tuple(col)[:3] + (255,), unsetcolor=(0,0,0,0))
    out = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    for dx, dy in _disc(th): out.blit(o, (dx, dy))
    out.blit(surf, (0, 0)); return out
def _rim(surf, col, a=200, dx=-1, dy=-2):   # rim light: a bright edge where the sun hits (top-left)
    m = pygame.mask.from_surface(surf, 60); e = m.copy(); e.erase(m, (-dx, -dy))
    surf.blit(e.to_surface(setcolor=tuple(col)[:3] + (a,), unsetcolor=(0,0,0,0)), (0, 0)); return surf
_HCEL = {}
def _hard_cel(surf, frac=0.56, col=(190,172,225)):   # HARD anime cel shadow on the lower part (cool lavender)
    w, h = surf.get_size(); key = (w, h, frac, col)
    if key not in _HCEL:
        g = pygame.Surface((w, h), 0, 32); g.fill((255,255,255)); y0 = int(h*frac)
        pts = [(x, y0 + int(2*math.sin(x*0.35))) for x in range(0, w + 2, 2)]
        pygame.draw.polygon(g, col, pts + [(w, h), (0, h)]); _HCEL[key] = g
    surf.blit(_HCEL[key], (0, 0), special_flags=pygame.BLEND_RGB_MULT); return surf
def _vivid(c, k=1.3):   # more saturated color
    m = sum(c[:3])/3.0; return tuple(max(0, min(255, int(m + (v - m)*k))) for v in c[:3])
def _taper(surf, col, p0, p1, w=3):   # brush stroke: bold in the middle, pointy ends
    (x0, y0), (x1, y1) = p0, p1; d = math.hypot(x1-x0, y1-y0) or 1
    nx, ny = -(y1-y0)/d*w/2, (x1-x0)/d*w/2; mx, my = (x0+x1)/2, (y0+y1)/2
    pygame.draw.polygon(surf, col, [(x0, y0), (mx+nx, my+ny), (x1, y1), (mx-nx, my-ny)])
def _glint4(surf, x, y, r, col=(255,255,255)):   # 4-point shine star
    pygame.draw.polygon(surf, col, [(x, y-r), (x+r*0.25, y-r*0.25), (x+r, y), (x+r*0.25, y+r*0.25), (x, y+r), (x-r*0.25, y+r*0.25), (x-r, y), (x-r*0.25, y-r*0.25)])
def _anime_eye(s, cx, cy, rw, rh, iris, mood="n", lid=None, lash=(45,18,35)):
    """huge sparkly anime eye that shows the mood: n = normal, happy = ^ ^ arcs, hit = wide shocked, run = determined"""
    if mood == "happy":
        _taper(s, lash, (cx-rw-1, cy+2), (cx, cy-rh+3), 3); _taper(s, lash, (cx, cy-rh+3), (cx+rw+1, cy+2), 3); return
    if mood == "hit":
        pygame.draw.ellipse(s, lash, (cx-rw-2, cy-rh-2, 2*rw+4, 2*rh+4)); pygame.draw.ellipse(s, WHITE, (cx-rw-1, cy-rh-1, 2*rw+2, 2*rh+2))
        pygame.draw.circle(s, _dark(iris, 25), (cx, cy), max(2, rw//2)); s.set_at((cx-1, cy-1), WHITE); return
    pygame.draw.ellipse(s, lash, (cx-rw-1, cy-rh-1, 2*rw+2, 2*rh+2))                               # dark rim
    pygame.draw.ellipse(s, iris, (cx-rw, cy-rh, 2*rw, 2*rh))
    pygame.draw.ellipse(s, _dark(iris, 45), (cx-rw, cy-rh, 2*rw, rh))                              # deep top of the iris
    pygame.draw.ellipse(s, _vivid(_light(iris, 100), 1.2), (cx-rw+1, cy+rh//3, 2*rw-2, max(2, rh*2//3)))   # glowing bottom
    pygame.draw.ellipse(s, (20,8,22), (cx-max(1, rw//2), cy-rh//2, max(2, rw), max(3, rh)))        # pupil
    pygame.draw.ellipse(s, WHITE, (cx-rw+1, cy-rh+1, max(2, rw), max(2, rh*2//3)))                 # big highlight
    pygame.draw.circle(s, WHITE, (cx+max(1, rw//2), cy+max(1, rh//2)), 1)                         # 2nd highlight
    s.set_at((cx+rw-2, cy-rh//2+1), WHITE)                                                       # 3rd tiny sparkle
    _taper(s, lash, (cx-rw-2, cy-rh+1), (cx+rw+2, cy-rh-1), 3)                                   # bold top lash
    if mood == "run" and lid:   # determined: a flat lid slanting down toward the front
        pygame.draw.polygon(s, lid, [(cx-rw-1, cy-rh-2), (cx+rw+2, cy-rh-2), (cx+rw+2, cy-rh//3)])
        _taper(s, lash, (cx-rw-2, cy-rh+1), (cx+rw+2, cy-rh//3+1), 3)
_TXT = {}
def otext(fnt, txt, col, oc=INK, th=2):
    """bubbly anime text: round bold outline, soft drop shadow and a glossy top (kept in a cache)"""
    key = (id(fnt), txt, col, oc, th)
    if key not in _TXT:
        T = th + 1
        base = fnt.render(txt, True, col); edge = fnt.render(txt, True, oc); shade = fnt.render(txt, True, _dark(oc, 40)); shade.set_alpha(120)
        w, h = base.get_size(); s = pygame.Surface((w + 2*T, h + 2*T + 2), pygame.SRCALPHA)
        for dx, dy in _disc(T): s.blit(shade, (T+dx, T+dy+2))     # drop shadow
        for dx, dy in _disc(T): s.blit(edge, (T+dx, T+dy))        # round bold outline
        s.blit(base, (T, T))
        gloss = fnt.render(txt, True, _light(col, 85)); s.blit(gloss, (T, T), (0, 0, w, int(h*0.42)))   # shiny top half
        _TXT[key] = s
    return _TXT[key]
_BUB = {}
def anime_bubble(surf, b, tail_x, edge=(90,50,20), fill=WHITE):   # rounded anime speech bubble: shadow, bold edge, gloss, tail, sparkle
    key = (b.w, b.h)
    if key not in _BUB:
        sh = pygame.Surface((b.w, b.h), pygame.SRCALPHA); pygame.draw.rect(sh, (40,20,50,70), (0, 0, b.w, b.h), border_radius=16); _BUB[key] = sh
    surf.blit(_BUB[key], (b.x + 3, b.y + 4))
    pygame.draw.polygon(surf, edge, [(tail_x-10, b.bottom-3), (tail_x+10, b.bottom-3), (tail_x-2, b.bottom+13)])
    pygame.draw.rect(surf, edge, b.inflate(6, 6), border_radius=18)
    pygame.draw.rect(surf, fill, b, border_radius=15)
    pygame.draw.polygon(surf, fill, [(tail_x-7, b.bottom-4), (tail_x+7, b.bottom-4), (tail_x-2, b.bottom+8)])
    pygame.draw.rect(surf, _lerp(fill, (215,225,255), 0.5), (b.x + 6, b.bottom - 7, b.w - 12, 4), border_radius=2)   # soft cel shade inside
    pygame.draw.rect(surf, WHITE, (b.x + 8, b.y + 3, max(4, b.w//3), 3), border_radius=2)
    _glint4(surf, b.right - 6, b.y + 2, 5, (255,240,150))

# FOX  (pose 0 = standing, 1-4 = walking steps, 5 = paw up with an axe, 6 = paw thrown forward)
_FOX_CACHE = {}
def make_fox(FOX=(255,130,20), DARK=(200,85,0), pose=0, mood="n"):
    key = (tuple(FOX), tuple(DARK), pose, mood)
    if key not in _FOX_CACHE: _FOX_CACHE[key] = _ready(_draw_fox(FOX, DARK, pose, mood))
    return _FOX_CACHE[key]
def _draw_fox(FOX, DARK, pose, mood="n"):   # CHIBI anime fox (same 56x42 size): big head, huge mood eyes, bold ink, hard cel
    s = pygame.Surface((56,42), pygame.SRCALPHA)
    FOX = _vivid(FOX, 1.3); DARK = _vivid(DARK, 1.3)
    CREAM = (255,247,232); PAW = _lerp(DARK, FOX, 0.2); FUR = _light(FOX, 12); INKC = _vivid(_dark(DARK, 100), 1.4)
    for i, (lx, ly) in enumerate(((19,30),(25,31),(32,31),(38,30))):   # short stubby legs
        if pose in (5, 6) and i == 3: continue
        if pose == 7 and i in (2, 3): continue           # victory: front paws up in the air
        sw = lift = 0
        if 1 <= pose <= 4:
            ph = (pose-1) * math.pi/2 + (0 if i in (0, 3) else math.pi)
            sw = int(round(3*math.sin(ph))); lift = max(0, int(round(2*math.cos(ph))))
        pygame.draw.line(s, PAW, (lx, ly), (lx+sw, 37-lift), 5); pygame.draw.ellipse(s, PAW, (lx+sw-3, 35-lift, 8, 5))
    for tx, ty, tr in ((14,18,9),(8,13,7),(19,13,6)): pygame.draw.circle(s, FUR, (tx, ty), tr)   # big fluffy tail
    pygame.draw.circle(s, CREAM, (5,10), 5); pygame.draw.circle(s, CREAM, (8,7), 3)                 # white tail tip
    pygame.draw.ellipse(s, FUR, (15,18,27,15)); pygame.draw.ellipse(s, CREAM, (22,25,15,7))        # small round body + belly
    pygame.draw.polygon(s, FUR, [(30,12),(31,0),(39,6)]); pygame.draw.polygon(s, FUR, [(43,6),(50,0),(52,12)])   # big ears
    pygame.draw.polygon(s, (255,160,185), [(32,9),(32.5,3),(37,7)]); pygame.draw.polygon(s, (255,160,185), [(45,7),(49,3),(50,10)])
    pygame.draw.circle(s, FUR, (41,17), 12)                                                          # BIG chibi head
    pygame.draw.ellipse(s, CREAM, (37,19,16,10)); pygame.draw.polygon(s, CREAM, [(30,21),(27,27),(35,24)])   # cream face + cheek fluff
    pygame.draw.polygon(s, CREAM, [(47,17),(55,21),(47,25)])                                        # little snout
    if pose == 5:    # paw up and back holding a little axe
        pygame.draw.line(s, (150,105,60), (28,10), (23,0), 4); pygame.draw.line(s, (200,155,100), (28,10), (23,0), 2)
        pygame.draw.polygon(s, (200,205,215), [(20,0),(27,0),(26,5),(20,4)])
        pygame.draw.line(s, FUR, (34,25), (29,11), 5); pygame.draw.circle(s, PAW, (28,10), 3)
    elif pose == 6:  # paw swung forward
        pygame.draw.line(s, FUR, (36,27), (49,32), 5); pygame.draw.circle(s, PAW, (50,32), 3)
    elif pose == 7:  # VICTORY: both paws up!
        pygame.draw.line(s, FUR, (30,25), (24,8), 5); pygame.draw.circle(s, PAW, (24,7), 3)
        pygame.draw.line(s, FUR, (36,27), (29,5), 5); pygame.draw.circle(s, PAW, (29,4), 3)
    _hard_cel(s, 0.6)
    _rim(s, (255,250,215), 220)
    pygame.draw.ellipse(s, _light(FUR, 75), (20,19,13,3)); pygame.draw.ellipse(s, _light(FUR, 75), (6,8,9,3))   # highlight bands
    pygame.draw.arc(s, _light(FUR, 85), (32,6,16,12), 1.7, 2.9, 2)
    s = _ink(s, INKC, 2)
    pygame.draw.circle(s, (75,25,40), (54,21), 2); s.set_at((54,20), WHITE)                          # shiny nose
    _anime_eye(s, 43, 15, 4, 6, (125,62,18), mood, FUR, _dark(INKC, 10))                              # HUGE mood eye
    if mood == "happy": pygame.draw.arc(s, INKC, (46,23,7,5), math.pi, 2*math.pi, 1)                 # open happy smile
    elif mood == "hit": pygame.draw.ellipse(s, INKC, (48,24,4,4))                                     # little "oh!"
    bl = pygame.Surface((9,4), pygame.SRCALPHA); pygame.draw.ellipse(bl, (255,95,135,170), (0,0,9,4)); s.blit(bl, (35,21))   # blush
    for k in range(3): _taper(s, (235,70,110), (36+k*3, 25), (38+k*3, 21), 1.5)                     # anime blush lines
    return s
def _old_draw_fox(FOX, DARK, pose):
    # side view of a cute anime fox facing right
    s = pygame.Surface((56,42), pygame.SRCALPHA)
    CREAM = (255,244,225); PAW = _lerp(DARK, FOX, 0.25)
    FUR = _light(FOX, 15)
    # legs: diagonal pairs swing when walking
    legs = ((20,28),(26,29),(34,29),(40,28))
    for i, (lx, ly) in enumerate(legs):
        if pose in (5, 6) and i == 3: continue           # this paw is busy throwing
        sw = lift = 0
        if 1 <= pose <= 4:
            ph = (pose-1) * math.pi/2 + (0 if i in (0, 3) else math.pi)
            sw = int(round(4*math.sin(ph))); lift = max(0, int(round(2.5*math.cos(ph))))
        pygame.draw.line(s, PAW, (lx, ly), (lx+sw, 38-lift), 4)
        pygame.draw.ellipse(s, PAW, (lx+sw-3, 36-lift, 7, 4))
    # big bushy tail with a white tip
    pygame.draw.ellipse(s, FUR, (1,7,27,16))
    pygame.draw.ellipse(s, CREAM, (1,10,11,11))
    # body and belly
    pygame.draw.ellipse(s, FUR, (14,15,31,17))
    pygame.draw.ellipse(s, CREAM, (22,24,17,7))
    # pointy ears with soft pink insides
    pygame.draw.polygon(s, FUR, [(34,11),(36,0),(42,8)])
    pygame.draw.polygon(s, FUR, [(41,8),(47,0),(50,11)])
    pygame.draw.polygon(s, (255,170,180), [(36,8),(36.5,3),(39.5,8)])
    pygame.draw.polygon(s, (255,170,180), [(43.5,8),(46,3),(47.5,9)])
    # head, cheek and pointy snout
    pygame.draw.circle(s, FUR, (42,16), 10)
    pygame.draw.circle(s, CREAM, (45,21), 4)
    pygame.draw.polygon(s, CREAM, [(46,14),(55,19),(46,24)])
    _shade(s, 195)
    # glossy fur highlights
    pygame.draw.ellipse(s, _light(FUR, 60), (20,16,14,3))
    pygame.draw.ellipse(s, _light(FUR, 60), (5,9,12,3))
    pygame.draw.arc(s, _light(FUR, 70), (34,7,14,10), 1.6, 2.9, 2)
    if pose == 5:    # paw up and back holding a little axe
        pygame.draw.line(s, (150,105,60), (30,10), (25,0), 4)    # light brown wooden handle
        pygame.draw.line(s, (200,155,100), (30,10), (25,0), 2)
        pygame.draw.polygon(s, (200,205,215), [(22,0),(29,0),(28,5),(22,4)])
        pygame.draw.line(s, FUR, (38,24), (31,11), 5); pygame.draw.circle(s, PAW, (30,10), 3)
    elif pose == 6:  # paw swung forward
        pygame.draw.line(s, FUR, (38,25), (50,31), 5); pygame.draw.circle(s, PAW, (51,31), 3)
    s = _outline(s)
    pygame.draw.circle(s, (110,55,60), (54,19), 2)                   # shiny nose (dark brown-pink)
    pygame.draw.circle(s, WHITE, (54,18), 1)
    _shine_eye(s, 44, 13, 4, 5, (110,60,25))                           # BIG shiny anime eye
    pygame.draw.line(s, _dark(DARK, 75), (39,9), (43,7), 2)             # eyelashes
    pygame.draw.line(s, _dark(DARK, 75), (38,11), (40,10), 1)
    blush = pygame.Surface((7,4), pygame.SRCALPHA); pygame.draw.ellipse(blush, (255,110,140,150), (0,0,7,4))
    s.blit(blush, (38,19))
    return s

class Fox(pygame.sprite.Sprite):
    def __init__(self, colors=None, keyset=None, start=None):
        super().__init__()
        self.colors = tuple(colors or ((255,130,20), (200,85,0)))
        self.frames = [make_fox(*self.colors, pose=k) for k in range(7)]
        self.happy_t = 0; self.moving_art = False; self.fast_art = False   # looks only (mood eyes, speed lines)
        self.base_image = self.frames[0]
        self.step = 0; self.throw_t = 0; self.face_left = False   # for the walking legs / axe throw (looks only)
        self.keyset = keyset or (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN)
        self.start = start or (int(600*WS), WORLD_H - int(800*WS))
        self.leash = None   # in two-player mode: the other fox (stay on the same screen)
        self.image = self.base_image
        self.rect = self.image.get_rect()
        self.direction = pygame.math.Vector2(1,0)
        self.speed_boost = 0
        self.boost_frames = 0   # golden berry boost countdown (60 = 1 second)
        self.inventory = load_items()   # items carry over between rounds (and games)
        self.sprint_keys = SPRINT_KEYS   # Nov 8: SHIFT = sprint (fox 2 gets U)
        self.reset()

    def reset(self):
        self.rect.centerx, self.rect.centery = self.start
        self.health = 100
        self.hearts = 4      # a troll touch takes one heart (4 hearts, Faroe Oct 31)
        self.invuln = 0      # safe frames right after getting hit
        self.dizzy = 0; self.dz_t = 0; self.dz_side = 1; self.dz_steer = 0.0   # mushroom: zigzag running
        self.meat_t = 0      # meat: double speed
        self.cold = 0; self.speed_boost = 0; self.boost_frames = 0
        self.sprint_e, self.sprint_rest, self.sprinting = SPRINT_MAX, 0, False   # full sprint meter every new game
        self.sub = (0.0, 0.0)   # left-over part-pixels of movement
        self.swimming = False; self.swim_acc = (0.0, 0.0)   # paddling in the Frog Pond
        self.out = False; self.ko_t = 0   # 2 players: out of hearts -> a little ghost that sits out

    def update(self, keys, throw):
        speed = FOX_WALK + self.speed_boost   # Nov 8: faster fox (was 6.2)
        if self.meat_t > 0: speed = MEAT_SPEED   # MEAT POWER: the top boost (never more, even with a golden berry)
        speed += self.sprint_tick(keys)   # SPRINT (Nov 8): +60% of the walk while SHIFT is held (10 s, then a 10 s rest)
        dx = dy = 0
        kl, kr, ku, kd = self.keyset
        if keys[kl]: dx -= speed
        if keys[kr]: dx += speed
        if keys[ku]: dy -= speed
        if keys[kd]: dy += speed
        if dx or dy:
            vec = pygame.math.Vector2(dx,dy)
            if vec.length()>0:
                self.direction = vec.normalize()
        moving = bool(dx or dy)
        self.step = self.step + speed if moving else 0
        if self.throw_t > 0: self.throw_t -= 1
        self.happy_t = max(0, getattr(self, "happy_t", 0) - 1)
        mood = "hit" if self.invuln > 80 else "happy" if self.happy_t > 0 else "run" if moving else "n"   # mood eyes (looks only)
        pi = self.pose_index(moving)
        if pi == 0 and STATUE_RECT.inflate(80, 80).colliderect(self.rect): pi, mood = 7, "happy"   # victory pose at the statue
        self.moving_art = moving; self.fast_art = moving and (self.speed_boost > 0 or self.meat_t > 0 or self.sprinting)
        self.base_image = make_fox(*self.colors, pose=pi, mood=mood)
        if True:
            d = self.direction
            self.face_left = d.x < -0.01
            if d.x < -0.01:   # facing left: flip so the fox isn't upside down
                img = pygame.transform.flip(self.base_image, True, False)
                self.image = pygame.transform.rotate(img, math.degrees(math.atan2(d.y, -d.x)))
            else:
                self.image = pygame.transform.rotate(self.base_image, -math.degrees(math.atan2(d.y, d.x)))
        if dx and dy:
            dx *= 0.707; dy *= 0.707
        if self.dizzy > 0 and (dx or dy):   # DIZZY: she drifts sideways, switching sides, wobbly steering
            self.dz_t += 1
            if self.dz_t % 24 == 0: self.dz_side *= -1
            self.dz_steer = max(-0.35, min(0.35, self.dz_steer + random.uniform(-0.09, 0.09)))
            m = math.hypot(dx, dy); ux, uy = dx/m, dy/m
            c, sn = math.cos(self.dz_steer), math.sin(self.dz_steer)
            ux, uy = ux*c - uy*sn, ux*sn + uy*c
            vx, vy = ux - uy*self.dz_side*0.85, uy + ux*self.dz_side*0.85
            n = math.hypot(vx, vy) or 1
            dx, dy = vx/n*m*0.9, vy/n*m*0.9
            if self.dz_t % 5 == 0: dust.append([self.rect.centerx, self.rect.bottom-4, 16, (230,200,255)])
        if (self.meat_t > 0 or self.sprinting) and (dx or dy) and random.random() < 0.5:   # dust puffs (meat or sprint)
            dust.append([self.rect.centerx - self.direction.x*26, self.rect.bottom - 6, 22, (225,205,170)])
        if THEME[0] == "space" and not indoors():   # level 8: weightless - a SHORT glide after letting go (same top speed)
            if dx or dy: self.glide = (dx, dy)
            else:
                gx, gy = getattr(self, "glide", (0, 0)); gx *= 0.72; gy *= 0.72
                self.glide = (gx, gy) if abs(gx) + abs(gy) > 1.0 else (0, 0)
                dx, dy = int(gx), int(gy)
        # SWIMMING in the Frog Pond: slower (~60%), with a splash going in / coming out
        sw = in_pond(self.rect)
        if sw != self.swimming: splash_puff(self.rect.centerx, self.rect.centery + 8)
        self.swimming = sw
        if sw and (dx or dy):
            ax = dx*SWIM_SPEED + self.swim_acc[0]; ay = dy*SWIM_SPEED + self.swim_acc[1]
            dx, dy = int(ax), int(ay); self.swim_acc = (ax - dx, ay - dy)
        # move one axis at a time so trees and rocks block the fox
        lf = self.leash if two_player else None   # two players: can't walk off the shared screen
        bin = boss_in(self.rect)   # already touching the boss? then she may walk away from him
        vlk = village_locked() and not self.rect.colliderect(VILLAGE_RECT)   # the candy barrier keeps her out
        if dx or dy:   # Nov 8: keep the left-over part-pixels, so she moves at her REAL speed in every direction
            sx_, sy_ = getattr(self, "sub", (0.0, 0.0)); ax_, ay_ = dx + sx_, dy + sy_
            dx, dy = int(round(ax_)), int(round(ay_)); self.sub = (ax_ - dx, ay_ - dy)
        else: self.sub = (0.0, 0.0)
        self.rect.x += dx
        if pygame.sprite.spritecollideany(self, obstacles) or (not bin and boss_in(self.rect)) or (vlk and village_bump(self)) or (lf and abs(self.rect.centerx-lf.rect.centerx) > LEASH_X):
            self.rect.x -= dx; self.sub = (0.0, self.sub[1])
        self.rect.y += dy
        if pygame.sprite.spritecollideany(self, obstacles) or (not bin and boss_in(self.rect)) or (vlk and village_bump(self)) or (lf and abs(self.rect.centery-lf.rect.centery) > LEASH_Y):
            self.rect.y -= dy; self.sub = (self.sub[0], 0.0)
        # stay inside the map
        self.rect.clamp_ip(pygame.Rect(0, 0, WORLD_W, WORLD_H))

        if throw and self.inventory["axes"] > 0:
            axes.add(Axe(self.rect.centerx, self.rect.centery, self.direction))
            self.inventory["axes"] -= 1
            self.throw_t = 18   # throwing paw animation (~0.3 s)

        if self.boost_frames > 0:
            self.boost_frames -= 1
            if self.boost_frames == 0: self.speed_boost = 0
        if self.dizzy > 0: self.dizzy -= 1
        if self.meat_t > 0: self.meat_t -= 1

    def sprint_tick(self, keys):   # SPRINT (Nov 8): the extra speed this frame, and the meter
        if not hasattr(self, "sprint_e"): self.sprint_e, self.sprint_rest, self.sprinting = SPRINT_MAX, 0, False
        if self.sprint_rest > 0:   # tired: a little rest before she can sprint again
            self.sprint_rest -= 1; self.sprinting = False
            if self.sprint_rest == 0: self.sprint_e = SPRINT_MAX
            return 0.0
        kl, kr, ku, kd = self.keyset
        held = any(keys[k] for k in getattr(self, "sprint_keys", SPRINT_KEYS)) and (keys[kl] or keys[kr] or keys[ku] or keys[kd])
        if held and self.sprint_e > 0:
            self.sprint_e -= 1; self.sprinting = True
            if self.sprint_e == 0: self.sprint_rest = SPRINT_REST   # 10 s of sprinting used up: rest 10 s
            return SPRINT_BONUS
        self.sprinting = False
        self.sprint_e = min(SPRINT_MAX, self.sprint_e + 1)   # not sprinting: the meter fills back up
        return 0.0
    def pose_index(self, moving):
        if self.throw_t > 12: return 5          # paw up with the axe
        if self.throw_t > 0: return 6           # paw swung forward
        if moving: return 1 + int(self.step / 16) % 4
        return 0
    def pose(self, dx, dy):
        # indoors (houses / caves): legs walk, fox faces left or right
        if dx < 0: self.face_left = True
        elif dx > 0: self.face_left = False
        moving = bool(dx or dy)
        self.step = self.step + 6 if moving else 0
        if self.throw_t > 0: self.throw_t -= 1
        img = self.frames[self.pose_index(moving)]
        self.image = pygame.transform.flip(img, True, False) if self.face_left else img

_AXE_ART = []
def axe_art():   # axe pointing right: light brown wooden handle + steel head
    if not _AXE_ART:
        a = pygame.Surface((40,26), pygame.SRCALPHA)
        pygame.draw.rect(a, (150,105,60), (1,10,33,7), border_radius=3)     # darker wood edge
        pygame.draw.rect(a, (200,155,100), (2,11,31,5), border_radius=2)    # light brown wood
        pygame.draw.line(a, (225,185,135), (4,12), (29,12), 1)              # wood shine
        pygame.draw.polygon(a, (120,125,140), [(24,7),(31,7),(39,1),(39,25),(31,19),(24,19)])
        pygame.draw.polygon(a, (190,195,210), [(25,8),(31,8),(38,3),(38,23),(31,18),(25,18)])   # steel head
        pygame.draw.line(a, WHITE, (37,4), (37,22), 1)                      # sharp shiny edge
        _AXE_ART.append(a)
    return _AXE_ART[0]
class Axe(pygame.sprite.Sprite):
    def __init__(self,x,y,dir):
        super().__init__()
        angle = dir.angle_to(pygame.math.Vector2(1,0))
        self.image = pygame.transform.rotate(axe_art(), -angle)
        self.rect = pygame.transform.rotate(pygame.Surface((34,12)), -angle).get_rect(center=(x,y))   # same hit box as before
        self.vel = dir * 16
    def update(self):
        self.rect.x += self.vel.x
        self.rect.y += self.vel.y
        # disappear once it flies far away from the fox
        if abs(self.rect.centerx-fox.rect.centerx) > 1500 or abs(self.rect.centery-fox.rect.centery) > 1500:
            self.kill()

class BerryBomb(pygame.sprite.Sprite):
    def __init__(self,x,y,dir):
        super().__init__()
        self.image = pygame.Surface((26,26), pygame.SRCALPHA)
        pygame.draw.circle(self.image,(170,0,200),(13,14),11)
        pygame.draw.circle(self.image,(230,120,255),(9,10),4)
        pygame.draw.rect(self.image,BROWN,(11,0,4,6))
        self.rect = self.image.get_rect(center=(x,y))
        self.vel = dir * 12
        self.life = 45
    def update(self):
        self.rect.x += self.vel.x; self.rect.y += self.vel.y
        self.life -= 1
        if self.life <= 0 or pygame.sprite.spritecollideany(self, trolls):
            burst(self.rect.center)
            self.kill()

splats = []   # [x, y, frames_left]
GREEN_CANDY_HP = 3   # green candy trolls (Candyland) take 3 hits (was 2, Faroe Oct 31); everyone else still goes down in 1
def hit_troll(t):   # one hit on a troll: True when it's defeated
    t.hp = getattr(t, "hp", 1) - 1
    if t.hp <= 0: t.kill(); return True
    t.hit_flash = 30   # not yet! it wobbles and flashes for half a second
    return False
def burst(pos):
    # purple berry splash: trolls nearby run away (removed)
    for t in list(trolls):
        if math.hypot(t.rect.centerx-pos[0], t.rect.centery-pos[1]) < 170:
            hit_troll(t)   # one hit (green candy trolls need three)
    splats.append([pos[0], pos[1], 40])

def _art_mushroom():   # cartoon red cap with white spots
    s = pygame.Surface((40,40), pygame.SRCALPHA)
    pygame.draw.rect(s, (250,238,212), (14,20,13,17), border_radius=6)                  # cream stem
    pygame.draw.ellipse(s, (245,228,200), (8,20,25,7))                                   # gills
    pygame.draw.ellipse(s, (232,45,50), (2,3,36,24))                                     # big red cap
    pygame.draw.ellipse(s, (245,228,200), (8,20,25,6))
    _shade(s, 175)
    for cx, cy, r in ((11,12,4),(21,8,3),(29,14,4),(19,18,2),(32,9,2)):
        pygame.draw.circle(s, WHITE, (cx, cy), r)                                        # white spots
    pygame.draw.ellipse(s, (255,150,150), (7,6,7,3))                                     # shine
    pygame.draw.circle(s, (205,120,110), (17,30), 1); pygame.draw.circle(s, (205,120,110), (23,30), 1)   # tiny face
    pygame.draw.arc(s, (205,120,110), (17,30,6,4), math.pi, 2*math.pi, 1)
    return _outline(s)
def _art_steak():     # cartoon T-bone steak
    s = pygame.Surface((40,40), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (250,232,205), (2,6,36,29))                                   # fat rim
    pygame.draw.ellipse(s, (200,75,65), (5,9,30,23))                                     # meat
    pygame.draw.ellipse(s, (225,105,90), (9,12,14,8))
    pygame.draw.rect(s, (250,248,238), (18,10,5,22), border_radius=2)                    # the T bone
    pygame.draw.rect(s, (250,248,238), (12,10,17,5), border_radius=2)
    _shade(s, 185)
    pygame.draw.line(s, (255,200,190), (9,15), (15,12), 2)                               # shine
    pygame.draw.circle(s, WHITE, (30,15), 2)
    return _outline(s)
def _art_drumstick():  # Faroe Nov 2: classic cartoon MEAT DRUMSTICK (chicken leg) with a big obvious white bone
    s = pygame.Surface((40,40), pygame.SRCALPHA)
    BONE, BSH = (255,253,246), (222,215,202)
    pygame.draw.ellipse(s, (150,62,30), (1,1,26,24))                                      # dark roasted edge
    pygame.draw.ellipse(s, (192,92,42), (2,1,24,22))                                      # reddish golden-brown meat
    pygame.draw.ellipse(s, (225,140,70), (5,3,15,10))                                     # golden roasted top
    pygame.draw.ellipse(s, (255,205,140), (8,5,7,4))                                      # highlight
    for a, b in (((9,15),(13,12)), ((14,18),(19,14)), ((6,19),(9,17))):                    # darker sear marks
        pygame.draw.line(s, (125,50,25), a, b, 2)
    _shade(s, 185)
    pygame.draw.line(s, BSH, (19,20), (30,31), 8)                                         # bone shaft (shadow side) - drawn after the shading so it stays WHITE
    pygame.draw.line(s, BONE, (19,19), (29,29), 6)                                        # bone shaft
    for bx, by in ((29,35), (35,29)):                                                     # knobby double-bump end
        pygame.draw.circle(s, BSH, (bx, by), 5); pygame.draw.circle(s, BONE, (bx - 1, by - 1), 4)
    pygame.draw.circle(s, BONE, (31,31), 4)
    pygame.draw.circle(s, WHITE, (27,33), 1); pygame.draw.circle(s, WHITE, (33,27), 1)    # shiny bone tips
    pygame.draw.polygon(s, (165,75,35), [(15,22), (20,16), (23,19), (19,23)])             # meat wraps around where the bone comes out
    pygame.draw.circle(s, WHITE, (11,7), 1)
    return _outline(s)
def _mini_gumdrop():   # stones turn into little sugary gumdrops in Candyland
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (120,215,140), (5,8,22,22)); pygame.draw.rect(s, (120,215,140), (5,19,22,10), border_radius=4)
    _shade(s, 180)
    for x, y in ((11,15),(19,13),(15,22),(22,22)): pygame.draw.circle(s, (235,255,240), (x,y), 1)
    pygame.draw.ellipse(s, WHITE, (10,10,6,4))
    return _outline(s)
def _art_ruby():   # Ruby Berry shaped like a HEART (Faroe, Oct 31)
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    red, deep, lite = (220,20,60), (165,10,45), (255,95,120)
    pygame.draw.circle(s, red, (11,13), 7); pygame.draw.circle(s, red, (21,13), 7)
    pygame.draw.polygon(s, red, [(4,15),(28,15),(16,29)])                                  # heart body
    pygame.draw.polygon(s, deep, [(16,17),(28,15),(16,29)])                                 # cel shadow on the right
    pygame.draw.circle(s, lite, (10,11), 3)                                                 # bright top
    pygame.draw.ellipse(s, (90,200,90), (14,1,9,6))                                         # little leaf
    s = _outline(s)
    pygame.draw.ellipse(s, WHITE, (7,9,5,3)); pygame.draw.circle(s, WHITE, (22,20), 1)    # shine
    return s
def _candy_ball(col):
    def f():
        s = pygame.Surface((32,32), pygame.SRCALPHA)
        pygame.draw.circle(s, col, (16,17), 12)
        _shade(s, 185)
        pygame.draw.ellipse(s, WHITE, (9,9,8,5)); pygame.draw.circle(s, WHITE, (22,23), 1)
        return _outline(s)
    return f
def _candy_wrap(col):
    def f():
        s = pygame.Surface((32,32), pygame.SRCALPHA)
        pygame.draw.polygon(s, _light(col, 40), [(1,8),(9,16),(1,24)]); pygame.draw.polygon(s, _light(col, 40), [(31,8),(23,16),(31,24)])
        pygame.draw.ellipse(s, col, (6,8,20,16))
        for k in range(3): pygame.draw.line(s, WHITE, (10+k*5, 9), (8+k*5, 23), 2)       # stripes
        _shade(s, 190)
        pygame.draw.ellipse(s, WHITE, (10,10,6,3))
        return _outline(s)
    return f
def _candy_cane(sz=32):
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    pts = [(12,30),(12,10)] + [(17 + 5*math.cos(a), 10 - 5*math.sin(a)) for a in [k*math.pi/6 for k in range(7)]]
    pygame.draw.lines(s, WHITE, False, pts, 6)
    for y in (27, 21, 15): pygame.draw.line(s, (235,45,60), (10,y+2), (14,y-1), 3)       # red stripes
    pygame.draw.line(s, (235,45,60), (19,6), (21,9), 3); pygame.draw.line(s, (235,45,60), (13,6), (15,4), 3)
    return _outline(s)
def _art_cupcake():   # frosted cupcake (Candyland mushroom)
    s = pygame.Surface((40,40), pygame.SRCALPHA)
    pygame.draw.polygon(s, (255,140,180), [(8,22),(32,22),(28,38),(12,38)])               # pink wrapper
    for x in (13,18,23,28): pygame.draw.line(s, (240,110,160), (x,23), (x-1 if x < 20 else x+1-2,37), 2)
    for cx, cy, r in ((13,20,7),(27,20,7),(20,18,8),(20,11,7)):
        pygame.draw.circle(s, (255,245,250), (cx,cy), r)                                 # frosting swirl
    _shade(s, 190)
    pygame.draw.circle(s, (230,40,60), (20,4), 4); pygame.draw.circle(s, WHITE, (19,3), 1)   # cherry
    for k, (x, y) in enumerate(((12,17),(17,12),(24,15),(28,20),(16,22),(23,21))):
        pygame.draw.line(s, [(255,90,150),(90,200,255),(255,220,60),(120,220,120)][k % 4], (x,y), (x+2,y+1), 2)   # sprinkles
    return _outline(s)
def _art_golden_ball():
    s = _candy_ball(GOLD)()
    pygame.draw.polygon(s, WHITE, [(24,4),(25,8),(29,9),(25,10),(24,14),(23,10),(19,9),(23,8)])
    return s
CUP_FROST = [(255,170,205), (205,175,250), (150,205,255)]    # pink, lavender, blue frosting
CUP_LINER = [((255,190,215), (255,140,185)), ((175,240,215), (110,210,170))]   # pink or mint striped liner
def _art_dizzy_cupcake(frost, liner):   # the DIZZY mushroom, dressed up as a cupcake (same 40x40 size)
    def f():
        s = pygame.Surface((40,40), pygame.SRCALPHA)
        lc, ls = liner
        top = [(7 + k*26/8, 22 + (2 if k % 2 else 0)) for k in range(9)]           # wavy liner rim
        pygame.draw.polygon(s, lc, top + [(29,38), (11,38)])
        for k in range(6):                                                       # stripes
            x0 = 9 + k*4.4; pygame.draw.line(s, ls, (x0, 23), (11 + k*3.6, 37), 2)
        fc = frost; fd = _dark(fc, 30); fl = _light(fc, 45)
        for cx, cy, r in ((12,20,7), (28,20,7), (20,20,8)):                      # bottom ring of the swirl
            pygame.draw.circle(s, fd, (cx, cy+1), r); pygame.draw.circle(s, fc, (cx, cy), r)
        pygame.draw.circle(s, fd, (20,14), 7); pygame.draw.circle(s, fc, (20,13), 7)   # middle
        pygame.draw.circle(s, fd, (20,8), 5); pygame.draw.circle(s, fc, (20,7), 5)     # little top curl
        pygame.draw.arc(s, fd, (9,12,22,12), 0.3, 2.8, 2); pygame.draw.arc(s, fd, (13,6,14,9), 0.4, 2.7, 2)   # swirl lines
        _shade(s, 190)
        pygame.draw.ellipse(s, fl, (11,14,7,4)); pygame.draw.ellipse(s, fl, (16,5,5,3))  # shine
        for k, (x, y) in enumerate(((11,19),(16,12),(24,11),(27,18),(15,21),(22,16),(19,22),(30,22),(9,22))):
            col = [(255,80,120),(255,200,60),(90,200,255),(120,220,120),(190,120,255),(255,140,60)][k % 6]
            pygame.draw.line(s, col, (x, y), (x+2, y+(1 if k % 2 else -1)), 2)    # rainbow sprinkles
        s = _outline(s)
        pygame.draw.line(s, (90,170,90), (21,1), (24,-2), 2)                     # cherry stem
        pygame.draw.circle(s, (205,30,55), (20,3), 4); pygame.draw.circle(s, (240,60,80), (20,3), 3)
        pygame.draw.circle(s, WHITE, (19,2), 1)                                   # cherry shine
        pygame.draw.polygon(s, WHITE, [(33,8),(34,11),(37,12),(34,13),(33,16),(32,13),(29,12),(32,11)])   # sparkle
        return s
    return f
SPECIAL_ART = {"mushroom": _art_mushroom, "meat_steak": _art_drumstick, "meat_drum": _art_drumstick,   # all meat is the drumstick now (Faroe Nov 2)
               "c_ball0": _candy_ball((255,100,170)), "c_ball1": _candy_ball((110,200,255)), "c_ball2": _candy_ball((150,230,120)),
               "c_wrap0": _candy_wrap((255,170,60)), "c_wrap1": _candy_wrap((190,120,255)),
               "c_cane": _candy_cane, "c_cupcake": _art_cupcake, "c_golden": _art_golden_ball, "c_drop": _mini_gumdrop, "ruby": _art_ruby}
for _i in range(6): SPECIAL_ART[f"cup{_i}"] = _art_dizzy_cupcake(CUP_FROST[_i % 3], CUP_LINER[_i // 3])
# ---- LEVEL 8 (Outer Space) pickups: same items, same jobs - only new looks + names (Faroe, Nov 2) ----
def _art_star_crystal():   # 'star crystal' = does what a berry does: a little cluster of glowing gems
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (90,70,150), (4,27,24,5))
    for (bx, h, w, c) in ((9, 15, 8, (120,225,255)), (23, 17, 8, (190,130,255)), (16, 25, 10, (255,120,215))):
        pts = [(bx - w//2, 29), (bx - w//2, 29 - h + 5), (bx, 29 - h), (bx + w//2, 29 - h + 5), (bx + w//2, 29)]
        pygame.draw.polygon(s, c, pts)
        pygame.draw.polygon(s, _light(c, 70), [(bx - w//2 + 1, 28), (bx - w//2 + 1, 29 - h + 6), (bx, 29 - h + 1), (bx, 28)])
    s.fill((255,255,255), (14, 9, 2, 2))
    return _outline(s, (70,40,120), 1)
def _art_gold_dust():   # 'golden star dust' = does what a golden berry does (speed boost)
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    for (x, y, r) in ((16,15,9), (8,24,4), (25,24,5), (24,7,3), (7,9,3)):
        q = r*0.3
        pygame.draw.polygon(s, (255,200,40), [(x, y-r), (x+q, y-q), (x+r, y), (x+q, y+q), (x, y+r), (x-q, y+q), (x-r, y), (x-q, y-q)])
        pygame.draw.circle(s, (255,245,170), (x, y), max(1, r//3))
    for (x, y) in ((12,28), (20,29), (28,14), (3,17), (17,3)): s.fill((255,225,110), (x, y, 2, 2))
    return _outline(s, (170,110,10), 1)
def _art_space_rock():   # 'space rock' = a meteor chunk (crafting, does what a stone does)
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    pygame.draw.polygon(s, (70,58,72), [(4,14), (10,5), (19,3), (28,9), (29,18), (24,27), (13,29), (4,23)])
    pygame.draw.polygon(s, (104,90,104), [(7,14), (11,7), (19,5), (25,10), (16,14)])
    for a, b in (((8,19),(15,15)), ((15,15),(20,21)), ((20,21),(27,17)), ((15,15),(17,8)), ((11,25),(20,21))):
        pygame.draw.line(s, (255,120,40), a, b, 2)
    for p in ((15,15), (20,21)): s.fill((255,225,120), (p[0]-1, p[1]-1, 3, 3))
    return _outline(s, (40,30,44), 1)
def _art_space_dust():   # 'space dust' = a twinkly bundle of blue-violet dust (crafting, does what a stick does)
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    pygame.draw.circle(s, (80,110,215,165), (16,18), 12)
    rr = random.Random(9)
    for _ in range(36):
        a = rr.uniform(0, 6.283); r = rr.uniform(0, 10)
        s.fill(rr.choice(((140,200,255), (190,150,255), (230,240,255), (120,160,255))), (int(16 + r*math.cos(a)), int(18 + r*math.sin(a)), 2, 2))
    pygame.draw.circle(s, (205,232,255), (16,18), 12, 2)
    pygame.draw.polygon(s, (200,160,255), [(11,3), (16,7), (21,3), (19,8), (13,8)])   # little bow tying the bundle
    s.fill((150,110,230), (14,5,4,3))
    return s
SPECIAL_ART["s_crystal"] = _art_star_crystal; SPECIAL_ART["s_gold"] = _art_gold_dust
SPECIAL_ART["s_rock"] = _art_space_rock; SPECIAL_ART["s_dust"] = _art_space_dust
SPACE_ITEM = {"berry": "s_crystal", "golden_berry": "s_gold", "stone": "s_rock", "stick": "s_dust"}
def is_space(): return THEME[0] == "space"
def berry_word(n=2):   # 'berry/berries' - or 'star crystal(s)' on level 8
    if is_space(): return "star crystal" if n == 1 else "star crystals"
    return "berry" if n == 1 else "berries"
def mat_word(key):     # 'sticks'/'stones' - or 'space dust'/'space rocks' on level 8
    return {"sticks": "space dust", "stones": "space rocks"}.get(key, key) if is_space() else key
def shop_name(name): return {"Stick": "Space Dust", "Stone": "Space Rock"}.get(name, name) if is_space() else name
CANDY = [False]   # True on the Candyland finale
def candy_type(typ):
    if typ == "berry": return random.choice(("c_ball0", "c_ball1", "c_ball2", "c_wrap0", "c_wrap1"))
    return {"stick": "c_cane", "stone": "c_drop", "mushroom": "c_cupcake", "golden_berry": "c_golden"}.get(typ, typ)

# ---------- REAL-LOOKING CARTOON BERRIES (every regular berry is one of these 4) ----------
REAL_BERRIES = ["blueberry", "blackberry", "raspberry", "strawberry"]
def _drupes(s, base, cx, cy, rows):   # a bumpy cluster of little round drupelets
    for ry, n in rows:
        for k in range(n):
            x = cx + (k - (n-1)/2.0)*6.4; y = cy + ry
            pygame.draw.circle(s, _dark(base, 40), (int(x), int(y)+1), 4)
            pygame.draw.circle(s, base, (int(x), int(y)), 4)
            pygame.draw.circle(s, _light(base, 80), (int(x)-1, int(y)-1), 1)
def _calyx(s, cx, cy, n=5, r=6, col=(70,160,60)):   # little green leaves on top
    for k in range(n):
        a = math.pi + k*math.pi/(n-1)
        pygame.draw.polygon(s, col, [(cx, cy), (cx + math.cos(a-0.25)*r, cy + math.sin(a-0.25)*r*0.7 + 2), (cx + math.cos(a)*r*1.2, cy + math.sin(a)*r*0.8 + 3), (cx + math.cos(a+0.25)*r, cy + math.sin(a+0.25)*r*0.7 + 2)])
def _art_real_berry(kind):
    def f():
        s = pygame.Surface((32,32), pygame.SRCALPHA)
        if kind == "blueberry":
            pygame.draw.circle(s, (55,70,170), (16,18), 12)
            pygame.draw.circle(s, (85,105,215), (15,17), 10)
            pygame.draw.circle(s, (130,150,235), (12,14), 4)                     # soft dusty bloom
            _shade(s, 175); s = _outline(s)
            pts = [(16 + math.cos(-math.pi/2 + k*math.pi/5)*(5 if k % 2 == 0 else 2), 9 + math.sin(-math.pi/2 + k*math.pi/5)*(5 if k % 2 == 0 else 2)) for k in range(10)]
            pygame.draw.polygon(s, (35,35,95), pts); pygame.draw.circle(s, (70,60,130), (16,9), 2)   # the little star crown
            pygame.draw.ellipse(s, WHITE, (9,13,5,4))
        elif kind in ("blackberry", "raspberry"):
            base = (70,25,95) if kind == "blackberry" else (235,60,105)
            _drupes(s, base, 16, 12, ((0,4), (6,4), (12,3), (17,2)))
            _shade(s, 180); s = _outline(s)
            _calyx(s, 16, 7, 5, 6, (80,170,70) if kind == "raspberry" else (70,150,60))
            pygame.draw.line(s, (70,140,55), (16, 6), (17, 1), 2)
        else:   # strawberry: red heart with yellow seeds and a leafy green top
            pygame.draw.circle(s, (225,35,55), (11,14), 7); pygame.draw.circle(s, (225,35,55), (21,14), 7)
            pygame.draw.polygon(s, (225,35,55), [(4,15), (28,15), (19,27), (16,30), (13,27)])
            pygame.draw.circle(s, (250,90,100), (10,14), 3)
            _shade(s, 170); s = _outline(s)
            for sx, sy in ((10,13),(16,12),(22,13),(13,18),(19,18),(16,23),(9,17),(23,17)):
                pygame.draw.ellipse(s, (255,225,90), (sx-1, sy-1, 2, 3))
            for k in range(6):   # leafy star top
                a = math.pi + k*math.pi/5
                pygame.draw.polygon(s, (60,160,60), [(16, 8), (16 + math.cos(a-0.3)*5, 8 + math.sin(a-0.3)*3 + 1), (16 + math.cos(a)*9, 8 + math.sin(a)*4 + 3), (16 + math.cos(a+0.3)*5, 8 + math.sin(a+0.3)*3 + 1)])
            pygame.draw.line(s, (60,130,45), (16, 7), (18, 1), 2)
            pygame.draw.ellipse(s, WHITE, (7,10,4,3))
        return s
    return f
for _i, _k in enumerate(REAL_BERRIES): SPECIAL_ART[f"rb{_i}"] = _art_real_berry(_k)
def real_berry_key(x, y): return f"rb{(x*7 + y*13 + (x//20)*3 + y//20) % 4}"   # each berry picks one of the 4, by where it is (a mix even on one tree)
_RB_SMALL = {}
def real_berry_small(kind, size):   # a real berry scaled to any size (for shelves, bowls, jars and icons)
    key = (kind, size)
    if key not in _RB_SMALL:
        _RB_SMALL[key] = pygame.transform.smoothscale(collectible_image(f"rb{REAL_BERRIES.index(kind)}"), (size, size))
    return _RB_SMALL[key]
dust = []   # [x, y, life, color]: little puffs behind a dizzy / meat-powered fox
_COLLECT_CACHE = {}
def collectible_image(typ):
    if typ in _COLLECT_CACHE: return _COLLECT_CACHE[typ]
    s = pygame.Surface((32,32), pygame.SRCALPHA)
    if typ == "berry":   # the plain berry icon is a strawberry (world berries pick one of the 4 real kinds)
        s = SPECIAL_ART["rb3"]()
    elif typ == "golden_berry":   # shiny anime GOLDEN berry: bumpy gold drupelets, green leaves, big sparkle
        pygame.draw.circle(s, (240,175,20), (16,18), 12)
        for bx, by in ((11,13),(16,11),(21,13),(9,18),(15,17),(22,18),(12,23),(18,24),(16,20)):
            pygame.draw.circle(s, (255,215,40), (bx,by), 4); pygame.draw.circle(s, (255,240,150), (bx-1,by-1), 1)
        for a in (-0.9, 0, 0.9):
            pygame.draw.ellipse(s, (90,180,70), (13 + int(6*math.sin(a)), 3, 7, 6))
        _shade(s, 175); s = _outline(s, (170,110,10), 1)
        pygame.draw.ellipse(s, WHITE, (9,11,6,4))
        pygame.draw.polygon(s, WHITE, [(25,3),(26,7),(30,8),(26,9),(25,13),(24,9),(20,8),(24,7)])
    elif typ == "stick":
        pygame.draw.rect(s, BROWN, (11,2,10,28), border_radius=5)
        pygame.draw.line(s, BROWN, (16,12), (25,6), 4)
        pygame.draw.ellipse(s, (110,200,90), (22,1,8,6))
        _shade(s, 190)
        pygame.draw.line(s, _light(BROWN, 60), (14,5), (14,26), 2)
        s = _outline(s)
    elif typ == "stone":   # Faroe Nov 2: an AXE-HEAD stone (block back, eye hole, flaring crescent blade, silver edge) - not like the big round rocks
        arc = [(22 + 7*math.cos(a/10.0), 16 + 13*math.sin(a/10.0)) for a in range(-12, 13)]   # the curved sharp edge
        body = [(3,10), (11,10), (14,12), (19,7)] + arc + [(19,25), (14,20), (11,22), (3,22)]
        pygame.draw.polygon(s, (122,126,140), body)                                          # gray stone body
        pygame.draw.polygon(s, (162,167,182), [(4,11), (11,11), (14,13), (19,8), (24,5), (22,10), (15,15), (4,15)])   # lit top facet
        pygame.draw.ellipse(s, (60,60,72), (6,13,4,7))                                        # the eye hole for the handle
        _shade(s, 170)
        pygame.draw.lines(s, (205,212,228), False, arc, 3)                                    # bright silver sharpened edge
        pygame.draw.lines(s, (250,252,255), False, [(x - 1, y) for x, y in arc[4:21]], 1)     # metal shine line
        s = _outline(s)
    elif typ in SPECIAL_ART:
        s = SPECIAL_ART[typ]()
    else:
        pygame.draw.circle(s,(255,170,200),(16,16),12); pygame.draw.circle(s,WHITE,(12,11),4)
    if s.get_width() <= 48 and s.get_height() <= 48:   # anime pass: bold dark ink + a little shine star
        s = _ink(s, (70,30,60), 1); _glint4(s, s.get_width()-7, 6, 3)
    s = _ready(s); _COLLECT_CACHE[typ] = s
    return s

def _swirl_pop(s, cx, cy, r, c1, c2):
    pygame.draw.circle(s, c1, (cx, cy), r)
    pts = [(cx + math.cos(a*0.35)*a*r/30.0, cy + math.sin(a*0.35)*a*r/30.0) for a in range(0, 31)]
    pygame.draw.lines(s, c2, False, pts, max(3, r//4))
def _candy_obstacle(typ, v):
    if typ == "c_tree":   # lollipop / candy-cane trees (same size = same blocking box)
        s = pygame.Surface((70,90), pygame.SRCALPHA)
        if v == 1:        # big candy cane
            pts = [(30,88),(30,30)] + [(42 + 12*math.cos(a), 30 - 12*math.sin(a)) for a in [k*math.pi/8 for k in range(9)]]
            pygame.draw.lines(s, WHITE, False, pts, 13)
            for y in range(80, 30, -12): pygame.draw.line(s, (235,45,60), (24,y+4), (36,y-4), 5)
            for a in (0.6, 1.5, 2.4): pygame.draw.circle(s, (235,45,60), (int(42 + 12*math.cos(a)), int(30 - 12*math.sin(a))), 4)
            _shade(s, 185)
        else:             # lollipop on a white stick
            pygame.draw.rect(s, (250,245,240), (32,46,7,43), border_radius=3)
            _swirl_pop(s, 35, 30, 27, (255,110,175) if v == 0 else (120,215,190), (255,235,245))
            _shade(s, 180)
            pygame.draw.ellipse(s, WHITE, (18,12,12,7))
        s = _outline(s)
    else:                 # gumdrop rocks
        s = pygame.Surface((55,55), pygame.SRCALPHA)
        col = ((120,210,110), (255,150,70), (190,120,240))[v % 3]
        pygame.draw.ellipse(s, col, (4,4,47,58))
        pygame.draw.rect(s, (0,0,0,0), (0,46,55,9))
        pygame.draw.ellipse(s, _dark(col, 25), (4,38,47,13))
        pygame.draw.ellipse(s, col, (4,34,47,12))
        _shade(s, 185)
        for x, y in ((14,16),(26,10),(36,20),(20,28),(32,32),(42,30)): pygame.draw.circle(s, (255,255,250), (x,y), 2)   # sugar
        pygame.draw.ellipse(s, _light(col, 90), (12,9,12,7))
        s = _outline(s)
    return s
_OBST_CACHE = {}
def obstacle_image(typ, v):
    key = (typ, v)
    if key in _OBST_CACHE: return _OBST_CACHE[key]
    if typ.startswith("c_"):
        s = _candy_obstacle(typ, v)
    elif typ[:2] in ("s_", "d_", "g_", "y_"):   # space / desert / dungeon / snow looks (same sizes)
        s = _theme_obstacle(typ, v)
    elif typ == "tree":   # GHIBLI tree (same 70x90): big round leaf clumps, hard cel, rim light, flowers + petals
        s = pygame.Surface((70,90), pygame.SRCALPHA)
        leaf = _vivid([(60,190,80), (40,170,90), (90,200,70)][v], 1.3); dk = _dark(leaf, 60); lt = _light(leaf, 60)
        pygame.draw.polygon(s, (110,64,30), [(26,89),(30,55),(41,55),(45,89)]); pygame.draw.polygon(s, (150,92,46), [(29,88),(32,55),(39,55),(40,88)])
        pygame.draw.polygon(s, (150,92,46), [(27,89),(21,89),(30,82)]); pygame.draw.polygon(s, (150,92,46), [(43,89),(50,89),(41,82)])   # roots
        clumps = ((35,28,21),(17,40,13),(53,40,13),(26,51,13),(44,51,13),(22,19,12),(48,19,12),(35,11,11))
        for cx, cy, r in clumps: pygame.draw.circle(s, dk, (cx+2, cy+3), r)
        for cx, cy, r in clumps: pygame.draw.circle(s, leaf, (cx, cy), r)
        for cx, cy, r in clumps: pygame.draw.circle(s, lt, (cx - r//4, cy - r//4), max(3, r*3//5))
        for cx, cy, r in clumps: pygame.draw.circle(s, leaf, (cx + r//3, cy + r//3), max(2, r//2))
        _hard_cel(s, 0.66, (170,165,215)); _rim(s, (255,255,205), 230)
        s = _ink(s, _dark(leaf, 115), 2)
        for cx, cy, r in ((27,15,5),(44,10,4),(15,35,3),(32,26,3)): pygame.draw.ellipse(s, _light(lt, 70), (cx-r, cy-r//2, 2*r, r))
        pygame.draw.line(s, (200,140,80), (33,60), (33,85), 2)
        for k, (fx, fy) in enumerate(((20,30),(50,28),(38,44),(28,8),(56,46))):   # little flowers in the leaves
            c = ((255,190,215), WHITE, (255,235,140))[k % 3]
            for a in range(5): pygame.draw.circle(s, c, (int(fx + 2.5*math.cos(a*1.2566)), int(fy + 2.5*math.sin(a*1.2566))), 2)
            pygame.draw.circle(s, (255,200,60), (fx, fy), 1)
        for px, py in ((14,86),(55,85),(20,80)): pygame.draw.ellipse(s, (255,185,210), (px, py, 5, 3))   # fallen petals
        _glint4(s, 57, 12, 4)
        s = _ready(s); _OBST_CACHE[key] = s
        return s
    elif typ == "tree_old":
        s = pygame.Surface((70,90), pygame.SRCALPHA)
        leaf = [(60,190,80), (40,170,90), (90,200,70)][v]
        pygame.draw.rect(s, (130,80,40), (28,58,14,31), border_radius=4)
        for cx, cy, r in ((35,30,26),(17,40,15),(53,40,15),(35,50,17),(23,20,14),(47,20,14)):
            pygame.draw.circle(s, leaf, (cx,cy), r)
        _shade(s, 165)
        for cx, cy, r in ((17,40,15),(53,40,15),(35,50,17),(23,20,14),(47,20,14)):   # clumpy anime leaf lines
            pygame.draw.arc(s, _dark(leaf, 45), (cx-r+3, cy-r+3, 2*r-6, 2*r-6), 3.6, 5.8, 2)
        for cx, cy, r in ((26,17,7),(42,13,5),(15,36,4)):
            pygame.draw.circle(s, _light(leaf, 70), (cx,cy), r)
        pygame.draw.circle(s, (255,255,240), (24,15), 2)                                    # sunny sparkle
        pygame.draw.line(s, (170,110,60), (31,62), (31,86), 2)
        s = _outline(s)
    else:
        s = pygame.Surface((55,55), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (130,128,145) if v == 0 else (120,125,140), (2,6,51,46))
        pygame.draw.ellipse(s, (110,190,100), (10,5,24,9))                                   # moss
        _shade(s, 165)
        pygame.draw.ellipse(s, (205,205,220), (12,15,14,8))
        pygame.draw.lines(s, (80,80,95), False, [(36,22),(32,30),(37,36)], 2)              # little crack
        s = _outline(s)
    s = _ready(s); _OBST_CACHE[key] = s
    return s

class Collectible(pygame.sprite.Sprite):
    def __init__(self,x,y,typ):
        super().__init__()
        self.type = typ
        self.image = collectible_image(candy_type(typ) if CANDY[0] else typ)
        if typ == "mushroom": self.image = collectible_image(f"cup{(x*7 + y*13) % 6}" if CANDY[0] else "mushroom")
        if THEME[0] == "space" and typ in SPACE_ITEM: self.image = collectible_image(SPACE_ITEM[typ])   # level 8 looks (same item, same job)
        if typ == "berry" and not CANDY[0] and THEME[0] != "space": self.image = collectible_image(real_berry_key(x, y))   # blueberry / blackberry / raspberry / strawberry   # cupcakes ONLY on the golden finale level; red mushrooms everywhere else
        self.rect = self.image.get_rect(center=(x,y))

class Obstacle(pygame.sprite.Sprite):
    def __init__(self,x,y,typ):
        super().__init__()
        self.image = obstacle_image(obst_prefix() + ("tree" if typ=="tree" else "rock"), (x*7+y*3) % (3 if typ=="tree" else 2))
        self.kind = "tree" if typ == "tree" else "rock"
        self.rect=self.image.get_rect(center=(x,y))

def can_see(a, b):
    # True if no tree or big rock is between point a and point b
    box = pygame.Rect(min(a[0],b[0]), min(a[1],b[1]), abs(a[0]-b[0])+1, abs(a[1]-b[1])+1)
    for o in obstacles:
        r = o.rect
        if not r.colliderect(box): continue
        if r.collidepoint(a) or r.collidepoint(b): continue
        if r.clipline(a, b): return False
    return True

_TROLL_BASE = []
def troll_base():
    if not _TROLL_BASE:
        s = pygame.Surface((64,64), pygame.SRCALPHA)
        BODY, HEAD = (135,142,160), (165,172,190)
        pygame.draw.circle(s, BODY, (32,45), 18)                                            # body
        pygame.draw.ellipse(s, _light(BODY,40), (24,40,16,14))                             # tummy
        pygame.draw.polygon(s, (240,225,190), [(20,9),(15,0),(25,5)])                      # little horns
        pygame.draw.polygon(s, (240,225,190), [(44,9),(49,0),(39,5)])
        pygame.draw.polygon(s, HEAD, [(18,16),(8,11),(18,24)]); pygame.draw.polygon(s, HEAD, [(46,16),(56,11),(46,24)])  # ears
        pygame.draw.circle(s, HEAD, (32,18), 16)                                            # head
        _shade(s, 185)
        pygame.draw.ellipse(s, _light(HEAD,50), (22,5,12,5))                               # shiny head
        s = _outline(s)
        bl = pygame.Surface((8,5), pygame.SRCALPHA); pygame.draw.ellipse(bl, (255,120,140,140), (0,0,8,5))
        s.blit(bl, (17,22)); s.blit(bl, (39,22))                                           # blush
        pygame.draw.arc(s, OUTLINE, (26,25,12,8), 0.3, math.pi-0.3, 2)                     # pouty frown
        pygame.draw.polygon(s, WHITE, [(27,30),(29,26),(30,30)])                           # tiny tusks
        pygame.draw.polygon(s, WHITE, [(34,30),(35,26),(37,30)])
        _TROLL_BASE.append(_ready(s))
    return _TROLL_BASE[0]

# ---------- CANDYLAND: PEPPERMINT TROLLS (level 11 only, looks only) ----------
_PEPPER = {}
def peppermint_troll_image(green, ang, eye_dx):
    """a peppermint troll in the Oct 29 classic troll style: flat red-and-white (or green spearmint) pinwheel body,
    a plain white mint head, 2px dark edges and the same plain orange troll eyes"""
    key = (green, ang, eye_dx)
    if key in _PEPPER: return _PEPPER[key]
    s = pygame.Surface((64,64), pygame.SRCALPHA)
    stripe = (40,170,95) if green else (230,40,60)
    line = _dark(stripe, 80)
    pygame.draw.circle(s, WHITE, (32,45), 18)                                 # peppermint body
    a0 = ang * 2*math.pi/24
    for k in range(6):   # curved pinwheel stripes
        a = a0 + k*math.pi/3; pts = [(32,45)]
        for j in range(1, 7): r = 16*j/6; t = a + 0.55*j/6; pts.append((32 + r*math.cos(t), 45 + r*math.sin(t)))
        for j in range(6, 0, -1): r = 16*j/6; t = a + 0.45 + 0.55*j/6; pts.append((32 + r*math.cos(t), 45 + r*math.sin(t)))
        pygame.draw.polygon(s, stripe, pts)
    pygame.draw.circle(s, line, (32,45), 18, 2)
    pygame.draw.circle(s, WHITE, (32,18), 16)                                 # plain white mint head
    pygame.draw.circle(s, line, (32,18), 16, 2)
    pygame.draw.circle(s, (255,140,0), (26+eye_dx,17), 4)                     # the same orange troll eyes
    pygame.draw.circle(s, (255,140,0), (38+eye_dx,17), 4)
    _PEPPER[key] = _ready(s)
    return _PEPPER[key]
def candy_troll_image(t):
    ang = (t.step // 4) % 24   # the swirl turns slowly while it walks
    eye = int(5*math.sin(pygame.time.get_ticks()/180)) if t.searching else 0
    return peppermint_troll_image(isinstance(t, GreenTroll), ang, eye)
def candy_stick(p0, p1, w, stripe, rim):   # a red-and-white striped peppermint stick (arms and legs)
    pygame.draw.line(screen, rim, p0, p1, w+2)
    pygame.draw.line(screen, WHITE, p0, p1, w)
    L = math.hypot(p1[0]-p0[0], p1[1]-p0[1]); n = max(2, int(L/5))
    for i in range(1, n, 2):
        a = (p0[0]+(p1[0]-p0[0])*i/n, p0[1]+(p1[1]-p0[1])*i/n); b = (p0[0]+(p1[0]-p0[0])*(i+1)/n, p0[1]+(p1[1]-p0[1])*(i+1)/n)
        pygame.draw.line(screen, stripe, a, b, w)
def mint_cols(t):
    return ((40,170,95), (190,225,205)) if isinstance(t, GreenTroll) else ((230,40,60), (240,195,205))

_TFACE = {}
def troll_face_img(cols, eye_dx):
    """cel-shaded cute-scary troll (body + head, same size), outlined, with the same orange eyes"""
    key = (cols, eye_dx)
    if key not in _TFACE:
        _TFACE[key] = _classic_troll(cols, eye_dx)
    return _TFACE[key]
def _classic_troll(cols, eye_dx):   # the Oct 29 pre-anime troll (same 64x64): one circle body, one circle head, orange eyes
    line, body, head = cols
    s = pygame.Surface((64,64), pygame.SRCALPHA)
    pygame.draw.circle(s, body, (32,45), 18)   # body
    pygame.draw.circle(s, line, (32,45), 18, 2)
    pygame.draw.circle(s, head, (32,18), 16)   # head
    pygame.draw.circle(s, line, (32,18), 16, 2)
    pygame.draw.circle(s, (255,140,0), (26+eye_dx,17), 4)
    pygame.draw.circle(s, (255,140,0), (38+eye_dx,17), 4)
    return s
def _chibi_troll(cols, eye_dx):   # CHIBI troll (same 64x64): big head, angry anime brows + lids, hard cel, bold ink
    line, body, head = cols; body = _vivid(body, 1.3); head = _vivid(head, 1.3)
    s = pygame.Surface((64,64), pygame.SRCALPHA)
    pygame.draw.circle(s, body, (32,49), 14); pygame.draw.ellipse(s, _light(body, 35), (25,47,14,10))   # small round body + tummy
    pygame.draw.polygon(s, (245,230,195), [(21,8),(16,0),(26,4)]); pygame.draw.polygon(s, (245,230,195), [(43,8),(48,0),(38,4)])   # horns
    pygame.draw.polygon(s, head, [(16,19),(4,12),(17,28)]); pygame.draw.polygon(s, head, [(48,19),(60,12),(47,28)])   # pointy ears
    pygame.draw.circle(s, head, (32,21), 17)                                                         # BIG head
    _hard_cel(s, 0.55, (180,165,220)); _rim(s, _light(head, 95), 210)
    pygame.draw.ellipse(s, _light(head, 75), (21,7,14,5))                                            # highlight band
    s = _ink(s, _vivid(_dark(line, 25), 1.2), 2)
    lash = (40,15,25)
    for k, ex in enumerate((25+eye_dx, 39+eye_dx)):                                                  # big angry anime eyes (same orange)
        pygame.draw.ellipse(s, lash, (ex-6, 14, 12, 12)); pygame.draw.ellipse(s, (255,250,240), (ex-5, 15, 10, 10))
        pygame.draw.circle(s, (255,140,0), (ex, 21), 4); pygame.draw.circle(s, (255,210,100), (ex, 23), 2)
        pygame.draw.ellipse(s, (60,20,10), (ex-1, 18, 2, 6)); pygame.draw.circle(s, WHITE, (ex-2, 19), 1); s.set_at((ex+2, 23), WHITE)
        lidp = [(ex-7,13),(ex+7,13),(ex+7,20)] if k == 0 else [(ex-7,13),(ex+7,13),(ex-7,20)]       # angry lid slanting to the middle
        pygame.draw.polygon(s, head, lidp)
        if k == 0: _taper(s, lash, (ex-8, 11), (ex+7, 18), 5)                                       # bold tapered angry brows
        else: _taper(s, lash, (ex+8, 11), (ex-7, 18), 5)
    pygame.draw.polygon(s, (90,20,35), [(26,30),(38,30),(36,34),(28,34)])                            # grumpy mouth
    pygame.draw.polygon(s, WHITE, [(27,30),(29,30),(28,33)]); pygame.draw.polygon(s, WHITE, [(35,30),(37,30),(36,33)])   # fangs
    bl = pygame.Surface((7,4), pygame.SRCALPHA); pygame.draw.ellipse(bl, (255,110,140,130), (0,0,7,4)); s.blit(bl, (13,27)); s.blit(bl, (44,27))
    return s
def _old_troll_face(cols, eye_dx, _TFACE={}):
    key = (cols, eye_dx)
    if key not in _TFACE:
        line, body, head = cols
        s = pygame.Surface((64,64), pygame.SRCALPHA)
        pygame.draw.circle(s, body, (32,45), 17)                                            # body
        pygame.draw.ellipse(s, _light(body, 30), (24,42,16,13))                            # tummy
        pygame.draw.circle(s, head, (32,18), 15)                                            # head
        _shade(s, 170)                                                                       # 2-tone cel shadow
        pygame.draw.ellipse(s, _light(head, 55), (21,6,12,6))                              # shiny head
        pygame.draw.ellipse(s, _light(body, 45), (20,33,9,5))
        s = _outline(s, _dark(line, 15), 2)                                                  # clean outline
        bl = pygame.Surface((7,4), pygame.SRCALPHA); pygame.draw.ellipse(bl, (255,120,140,120), (0,0,7,4))
        s.blit(bl, (18,21)); s.blit(bl, (39,21))                                             # blush
        for ex in (26+eye_dx, 38+eye_dx):                                                   # the SAME orange eyes, now shiny
            pygame.draw.circle(s, (160,70,0), (ex,17), 5)
            pygame.draw.circle(s, (255,140,0), (ex,17), 4)
            pygame.draw.circle(s, (255,200,90), (ex,18), 2)
            pygame.draw.ellipse(s, (70,25,10), (ex-1,14,2,6))                              # little slit pupil
            pygame.draw.circle(s, WHITE, (ex-2,15), 1)                                      # sparkle
        pygame.draw.line(s, _dark(line, 10), (20+eye_dx,10), (29+eye_dx,13), 2)            # grumpy brows
        pygame.draw.line(s, _dark(line, 10), (44+eye_dx,10), (35+eye_dx,13), 2)
        pygame.draw.arc(s, _dark(line, 10), (26,24,12,7), 0.3, math.pi-0.3, 2)            # pouty frown
        pygame.draw.polygon(s, WHITE, [(28,27),(29,24),(30,27)]); pygame.draw.polygon(s, WHITE, [(34,27),(35,24),(36,27)])   # tiny fangs
        _TFACE[key] = s
    return _TFACE[key]

class Troll(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()
        self.image=pygame.Surface((64,64), pygame.SRCALPHA)
        self.searching=False
        self.step = 0; self.moving = False   # for the stepping legs (looks only)
        self.bounce = 0; self.bvec = (0, 0)   # bouncing away from the pond
        self.draw_face(0)
        self.rect=self.image.get_rect(center=(x,y))
    def draw_face(self, eye_dx):
        # gray troll: one circle body, one circle head (the classic look)
        self.image.fill((0,0,0,0))   # anime look, same size + same orange eyes
        self.image.blit(troll_face_img(((70,70,70), (120,120,120), (150,150,150)), eye_dx), (0, 0))
    def update(self,fox):
        if CANDY[0]:   # peppermint trolls (Candyland) are the MEAN kind now
            return mean_chase(self, fox, min(MEAN_CAP, MEAN_SPEEDUP*troll_speed(None, False)*(2 if storm_on else 1)))
        if not hasattr(self, "fx") or (round(self.fx), round(self.fy)) != self.rect.center:   # got pushed: follow the new spot
            self.fx, self.fy = map(float, self.rect.center)
        sp = troll_speed()   # Nov 8: smooth px-per-frame speed (Speedy Trolls + lightning included) - always slower than the fox
        self.moving = False
        if self.bounce > 0:   # still bouncing away from the water (same gentle bounce distance as before)
            self.bounce -= 1
            self.fx += self.bvec[0]*BOUNCE_SPEED; self.fy += self.bvec[1]*BOUNCE_SPEED
            self.rect.center = (round(self.fx), round(self.fy)); self.moving = True; self.step += 1
            return
        # fox hiding behind a tree or rock? freeze and look around
        if not can_see(self.rect.center, fox.rect.center):
            self.searching=True
            self.draw_face(int(5*math.sin(pygame.time.get_ticks()/180)))
            hole_wander(self)   # desert: scorpions stroll near their holes
            return
        if self.searching:
            self.searching=False
            self.draw_face(0)
        dx=fox.rect.centerx-self.fx
        dy=fox.rect.centery-self.fy
        d=math.hypot(dx,dy)
        if d>5:
            st = min(sp, d - 4)   # never steps past the fox (no jiggling on top of her)
            nx, ny = self.fx + dx/d*st, self.fy + dy/d*st
            test = self.rect.copy(); test.center = (round(nx), round(ny))
            if test.colliderect(POND_SAFE): troll_bounce(self); return   # about to reach the water: BOUNCE away
            self.fx, self.fy = nx, ny; self.rect.center = (round(nx), round(ny))
            self.moving = True; self.step += 1

_HOUSE_CACHE = {}
ROOF_COLS = {(255,230,150): (250,150,170), (180,220,255): (150,170,240), (255,190,210): (190,150,230),
             (200,255,200): (120,200,170), (240,240,240): (250,180,120), (205,140,80): (150,95,65)}
def _roof_y(x, w=120, base=52, h=46):   # the curved roof line of a cottage
    u = (x - w/2) / (w/2 - 2)
    return base - h * max(0.0, 1 - u*u) ** 0.7
def _round_window(s, cx, cy, r):   # round window with warm glowing light and a shine glint
    gl = pygame.Surface((r*4, r*4), pygame.SRCALPHA)
    for k in range(6): pygame.draw.circle(gl, (255,210,120, 14 + k*8), (r*2, r*2), r*2 - k*r//6)
    s.blit(gl, (cx - r*2, cy - r*2))
    pygame.draw.circle(s, (170,115,75), (cx, cy), r + 3); pygame.draw.circle(s, (215,160,105), (cx, cy), r + 2)
    pygame.draw.circle(s, (255,190,100), (cx, cy), r); pygame.draw.circle(s, (255,225,150), (cx-1, cy-1), r - 3)
    pygame.draw.line(s, (215,160,105), (cx - r, cy), (cx + r, cy), 2); pygame.draw.line(s, (215,160,105), (cx, cy - r), (cx, cy + r), 2)
    pygame.draw.line(s, WHITE, (cx - r//2 - 1, cy - 2), (cx - 2, cy - r//2 - 1), 2)
def _flower_box(s, x, y, w):
    pygame.draw.rect(s, (175,120,80), (x, y + 2, w, 6), border_radius=3); pygame.draw.rect(s, (205,150,100), (x, y, w, 5), border_radius=3)
    for k, fx in enumerate(range(x + 3, x + w - 1, 5)):
        pygame.draw.circle(s, (100,175,95), (fx, y - 1), 3)
        pygame.draw.circle(s, ((255,150,190), (255,240,130), (255,255,255), (190,160,255))[k % 4], (fx, y - 3), 2)
def _cottage(w, h, wall, roof, base=52, roof_h=46, chimney_x=None):
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    if chimney_x is not None:   # little brick chimney behind the roof
        cx = chimney_x; top = int(_roof_y(cx, w, base, roof_h)) - 14
        pygame.draw.rect(s, (205,125,110), (cx, top, 14, 26), border_radius=3); pygame.draw.rect(s, (230,155,135), (cx, top, 6, 26), border_radius=3)
        pygame.draw.rect(s, (180,105,95), (cx - 2, top - 2, 18, 6), border_radius=3)
    # walls: soft cel-shading (light band left, shade band right)
    wr = pygame.Rect(8, base - 6, w - 16, h - base + 4)
    pygame.draw.rect(s, _dark(wall, 28), wr, border_radius=14)
    pygame.draw.rect(s, wall, wr.inflate(-14, -2).move(-6, -1), border_radius=12)
    pygame.draw.rect(s, _light(wall, 35), (wr.x + 4, wr.y + 6, 10, wr.h - 14), border_radius=5)
    pygame.draw.rect(s, _dark(wall, 15), (wr.x + 4, wr.bottom - 7, wr.w - 8, 5), border_radius=3)   # soft ground shade
    # curved shingled roof
    m = pygame.Surface((w, h), pygame.SRCALPHA)
    pts = [(x, _roof_y(x, w, base, roof_h)) for x in range(0, w + 1, 3)]
    pygame.draw.polygon(m, (255,255,255,255), pts + [(w, base + 2), (0, base + 2)])
    lay = pygame.Surface((w, h), pygame.SRCALPHA); lay.fill(roof + (255,))
    for row, y in enumerate(range(int(base - roof_h) + 6, base + 4, 8)):   # rows of scalloped shingles
        for x in range(-6 + (5 if row % 2 else 0), w + 6, 10):
            pygame.draw.circle(lay, _dark(roof, 22), (x, y + 1), 6); pygame.draw.circle(lay, roof, (x, y - 1), 5)
    pygame.draw.ellipse(lay, _light(roof, 45), (w*0.18, base - roof_h*0.8, w*0.32, roof_h*0.35))   # highlight band
    pygame.draw.rect(lay, _dark(roof, 25), (w*0.62, 0, w, h))   # shade band on the right
    for row, y in enumerate(range(int(base - roof_h) + 6, base + 4, 8)):
        for x in range(-6 + (5 if row % 2 else 0), w + 6, 10):
            if x > w*0.62: pygame.draw.circle(lay, _dark(roof, 40), (x, y + 1), 6, 1)
    lay.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    s.blit(lay, (0, 0))
    pygame.draw.lines(s, _dark(roof, 35), False, pts, 2)
    pygame.draw.rect(s, _dark(roof, 30), (2, base - 2, w - 4, 7), border_radius=4)   # rounded eave
    pygame.draw.rect(s, _light(roof, 20), (4, base - 2, w - 8, 3), border_radius=3)
    return s
def _cottage_door(s, x, y, w, h, wood=(175,115,70)):
    pygame.draw.rect(s, _dark(wood, 25), (x - 2, y - 2, w + 4, h + 2), border_top_left_radius=w//2 + 2, border_top_right_radius=w//2 + 2)
    pygame.draw.rect(s, wood, (x, y, w, h), border_top_left_radius=w//2, border_top_right_radius=w//2)
    for k in range(1, 3): pygame.draw.line(s, _dark(wood, 18), (x + k*w//3, y + 4), (x + k*w//3, y + h - 2), 1)   # planks
    pygame.draw.rect(s, _light(wood, 40), (x + 3, y + 6, 3, h - 10), border_radius=2)
    pygame.draw.circle(s, (255,215,90), (x + w - 6, y + h//2 + 3), 2)
def _lantern(s, x, y):
    gl = pygame.Surface((24, 24), pygame.SRCALPHA)
    for k in range(5): pygame.draw.circle(gl, (255,220,120, 20 + k*14), (12, 12), 12 - k*2)
    s.blit(gl, (x - 12, y - 10))
    pygame.draw.line(s, (150,110,80), (x, y - 8), (x, y - 4), 2)
    pygame.draw.rect(s, (160,120,90), (x - 4, y - 5, 8, 3), border_radius=1)
    pygame.draw.rect(s, (255,215,110), (x - 3, y - 2, 6, 7), border_radius=2); pygame.draw.rect(s, (255,245,200), (x - 1, y, 2, 3))
def house_image(wall):
    if wall not in _HOUSE_CACHE:
        roof = ROOF_COLS.get(tuple(wall), (250,160,170))
        s = _cottage(120, 110, wall, roof, chimney_x=84)
        for wx in (28, 92): _round_window(s, wx, 76, 10); _flower_box(s, wx - 12, 88, 24)
        _cottage_door(s, 46, 74, 28, 36)
        _lantern(s, 80, 80)
        pygame.draw.ellipse(s, (215,205,195), (40, 104, 40, 6)); pygame.draw.ellipse(s, (235,228,220), (44, 104, 32, 3))   # door step
        _HOUSE_CACHE[wall] = _ready(_ink(_rim(s, (255,255,235), 170), (95,50,80), 2))   # bold anime ink + rim light (same size)
    return _HOUSE_CACHE[wall]
_SMOKE = []
def draw_chimney_smoke(screen_, x, y, seed):   # a soft puff of smoke drifting from a chimney
    if not _SMOKE:
        p = pygame.Surface((24, 24), pygame.SRCALPHA)
        pygame.draw.circle(p, (255,255,255,150), (12, 12), 10); pygame.draw.circle(p, (255,255,255,200), (9, 9), 5)
        _SMOKE.append(p)
    t = pygame.time.get_ticks()
    for k in range(3):
        ph = ((t / 2200.0) + k / 3.0 + seed * 0.13) % 1.0
        im = pygame.transform.smoothscale(_SMOKE[0], (int(10 + 16*ph), int(10 + 16*ph)))
        im.set_alpha(int(200 * (1 - ph)))
        screen_.blit(im, (x - im.get_width()//2 + int((8 + 18*wind_at(x, t))*_ease(ph) + 4*math.sin(ph*5 + k)), y - int(46*ph) - im.get_height()//2))   # curls and drifts with the wind

class House(pygame.sprite.Sprite):
    def __init__(self, x, y, wall):
        super().__init__()
        self.image = house_image(wall)
        self.rect = self.image.get_rect(center=(x,y))
        # walk up into the door to go inside
        self.door = pygame.Rect(self.rect.x+44, self.rect.bottom-20, 32, 30)

# ---------- THE VILLAGE SHOP ----------
def _berry(surf, col, x, y, r=5):   # a little real berry (the old color picks which kind)
    rr_, gg_, bb_ = col[:3]
    kind = "blueberry" if bb_ > rr_ else ("blackberry" if bb_ > 120 and r < 6 else ("strawberry" if r >= 6 or (x + y) % 2 else "raspberry"))
    if bb_ > 120 and rr_ > 150 and r >= 6: kind = REAL_BERRIES[(x + y) % 4]   # bowls on tables: a mix
    sz = max(6, int(r*2.6)); im = real_berry_small(kind, sz)
    surf.blit(im, (x - sz//2, y - sz//2))
def _make_shop_front():
    im = _cottage(160, 120, (255,228,190), (130,205,175), base=46, roof_h=42, chimney_x=122)
    for i in range(8):   # candy-striped awning under the roof
        col = (250,120,150) if i % 2 == 0 else (255,246,236)
        pygame.draw.rect(im, col, (8 + i*18, 46, 18, 10))
        pygame.draw.circle(im, col, (8 + i*18 + 9, 56), 9, draw_top_left=False, draw_top_right=False)
    pygame.draw.rect(im, (230,165,110), (38, 10, 84, 22), border_radius=10)        # rounded sign board on the roof
    pygame.draw.rect(im, (250,200,140), (40, 12, 80, 8), border_radius=8)
    _round_window(im, 36, 84, 13)
    for bx, by, c in ((28,98,(200,40,190)), (36,96,(80,110,235)), (44,98,(230,50,70))):   # berry basket in the window
        pygame.draw.ellipse(im, (205,145,85), (22, 98, 30, 9)); _berry(im, c, bx, by, 4)
    _round_window(im, 124, 84, 13); _flower_box(im, 110, 100, 28)
    _cottage_door(im, 64, 76, 32, 44, (235,120,160))
    _berry(im, (190,40,170), 80, 100, 4)
    _lantern(im, 104, 82)
    for xx in (2, 148):   # little berry bushes in pots
        pygame.draw.rect(im, (225,140,100), (xx, 104, 10, 14), border_radius=3)
        pygame.draw.circle(im, (100,180,100), (xx + 5, 100), 8)
        _berry(im, (200,40,190), xx + 2, 98, 2); _berry(im, (230,50,70), xx + 8, 102, 2)
    t = otext(tinyfont, "BERRY SHOP", (255,240,200), (150,80,40), 1); im.blit(t, (80 - t.get_width()//2, 12))
    return im
class Shop(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = _make_shop_front()
        self.rect = self.image.get_rect(center=(x,y))
        self.door = pygame.Rect(self.rect.x+64, self.rect.bottom-20, 32, 30)

SHOP_ITEMS = [  # (key, name, price in berries, what it is)
    ("sticks",  "Stick",        1,  "for crafting"),
    ("stones",  "Stone",        1,  "for crafting"),
    ("axes",    "Axe",          4,  "ready to throw (X)"),
    ("acorn",   "Shiny Acorn",  3,  "collectible"),
    ("feather", "Blue Feather", 5,  "collectible"),
    ("crystal", "Pink Crystal", 8,  "collectible"),
    ("bell",    "Golden Bell",  12, "collectible"),
    ("badge",   "Fox Badge",    20, "collectible - the rarest!"),
]
shop = None
shop_msg = ""; shop_msg_frames = 0
shop_sel = 0   # which item is picked in the shop

def draw_treasure(surf, kind, x, y):
    # little pictures of each collectible, centered on x,y
    if kind == "acorn":
        pygame.draw.ellipse(surf,(190,120,40),(x-8,y-6,16,18)); pygame.draw.ellipse(surf,(110,70,30),(x-10,y-10,20,9))
        pygame.draw.circle(surf,(255,240,200),(x-3,y+1),2)
    elif kind == "feather":
        pygame.draw.ellipse(surf,(70,140,255),(x-5,y-12,10,24)); pygame.draw.line(surf,WHITE,(x,y-12),(x,y+12),1)
    elif kind == "crystal":
        pygame.draw.polygon(surf,(255,120,210),[(x,y-12),(x+8,y-2),(x,y+12),(x-8,y-2)])
        pygame.draw.polygon(surf,(255,200,240),[(x,y-12),(x+3,y-2),(x,y+4),(x-3,y-2)])
    elif kind == "bell":
        pygame.draw.polygon(surf,GOLD,[(x-9,y+7),(x-6,y-6),(x,y-10),(x+6,y-6),(x+9,y+7)])
        pygame.draw.circle(surf,(200,150,0),(x,y+9),3)
    elif kind == "badge":
        pygame.draw.circle(surf,GOLD,(x,y),11); pygame.draw.circle(surf,(255,130,20),(x,y),7)
        pygame.draw.polygon(surf,(255,130,20),[(x-7,y-3),(x-6,y-12),(x-1,y-6)])
        pygame.draw.polygon(surf,(255,130,20),[(x+7,y-3),(x+6,y-12),(x+1,y-6)])

def buy(i):
    global shop_msg, shop_msg_frames
    key, name, price, _ = SHOP_ITEMS[i]
    inv = fox.inventory
    if inv["berries"] >= price:
        inv["berries"] -= price
        inv[key] = inv.get(key,0) + 1
        shop_msg = f"You bought a {shop_name(name)} for {price} {berry_word(price)}! Thank you!"
        save_items(inv)
    else:
        need = price - inv["berries"]
        shop_msg = f"You need {need} more {berry_word(need)} for the {shop_name(name)}."
    shop_msg_frames = 180

def leave_shop():
    global state, start_ticks
    start_ticks += pygame.time.get_ticks() - pause_start   # timer was paused in the shop
    fox.rect.midtop = (shop.rect.centerx, shop.rect.bottom + 30)
    if two_player: fox2.rect.topleft = (fox.rect.x + 70, fox.rect.y)
    state = "playing"

_SHOP_TXT = {}
def shop_txt(fnt, txt, aa, col):   # readable shop words: dark brown (or the given color) + soft light shadow
    col = {(0,0,0): (60,35,15), (110,50,20): (60,35,15), (40,110,40): (25,95,25), (120,90,70): (95,70,50), (150,0,150): (125,0,125)}.get(tuple(col), tuple(col))
    key = (id(fnt), txt, col)
    if key not in _SHOP_TXT:
        base = fnt.render(txt, True, col); sh = fnt.render(txt, True, (255,248,230))
        out = pygame.Surface((base.get_width()+2, base.get_height()+2), pygame.SRCALPHA)
        out.blit(sh, (1, 1)); out.blit(sh, (2, 2)); out.blit(base, (0, 0))
        if len(_SHOP_TXT) > 400: _SHOP_TXT.clear()
        _SHOP_TXT[key] = out
    return _SHOP_TXT[key]
_SHOP_CARD = {}
def shop_card(size, can):   # rounded gradient card with a darker edge of its own color (no black)
    key = (size, can)
    if key not in _SHOP_CARD:
        top, bot = ((255,246,226), (246,222,186)) if can else ((228,208,182), (208,184,154))
        c = pygame.Surface(size, pygame.SRCALPHA)
        pygame.draw.rect(c, _dark(bot, 40), (0,0)+size, border_radius=10)
        inner = pygame.Surface((size[0]-4, size[1]-4), pygame.SRCALPHA)
        pygame.draw.rect(inner, (255,255,255), (0,0)+inner.get_size(), border_radius=9)
        inner.blit(_vgrad(*inner.get_size(), top, bot), (0,0), special_flags=pygame.BLEND_RGB_MULT)
        c.blit(inner, (2,2))
        pygame.draw.line(c, _light(top, 30), (12,4), (size[0]-12,4), 2)
        _SHOP_CARD[key] = c
    return _SHOP_CARD[key]
_SHOP_BG = []
def draw_shop():
    panel = pygame.Rect(120, 20, 960, 660)
    if not _SHOP_BG:
        bg = _vgrad(WIDTH, HEIGHT, (255,226,205), (248,196,170))          # warm pastel shop wall
        for xx in range(0, WIDTH, 44): pygame.draw.rect(bg, (255,214,196), (xx, 0, 16, HEIGHT - 120))   # wallpaper stripes
        for yy in range(30, HEIGHT - 130, 44):
            for xx in range(22 + (22 if (yy//44) % 2 else 0), WIDTH, 44):
                pygame.draw.circle(bg, (250,185,190), (xx-2, yy), 3); pygame.draw.circle(bg, (250,185,190), (xx+2, yy), 3)
                pygame.draw.polygon(bg, (250,185,190), [(xx-5, yy+1), (xx+5, yy+1), (xx, yy+6)])
        fl = pygame.Rect(0, HEIGHT - 120, WIDTH, 120)
        bg.blit(_vgrad(fl.w, fl.h, (225,165,110), (190,128,80)), fl.topleft)   # plank floor
        for k, yy in enumerate(range(fl.y, fl.bottom, 28)):
            pygame.draw.line(bg, (175,115,70), (0, yy), (WIDTH, yy), 2); pygame.draw.line(bg, (245,195,140), (0, yy+3), (WIDTH, yy+3), 1)
            for xx in range(40 + (70 if k % 2 else 0), WIDTH, 140): pygame.draw.line(bg, (180,120,75), (xx, yy), (xx, yy+28), 2)
        for sx in (14, panel.right + 20):   # round windows on both sides with curtains
            wc = (sx + 46, 600 - 470); wr = 34
            sky = pygame.Surface((wr*2, wr*2), pygame.SRCALPHA); sky.blit(_vgrad(wr*2, wr*2, (130,200,255), (215,240,255)), (0, 0))
            pygame.draw.ellipse(sky, WHITE, (8, wr + 4, 30, 12))
            mk = pygame.Surface((wr*2, wr*2), pygame.SRCALPHA); pygame.draw.circle(mk, (255,255,255,255), (wr, wr), wr); sky.blit(mk, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            bg.blit(sky, (wc[0]-wr, wc[1]-wr)); pygame.draw.circle(bg, (200,140,95), wc, wr + 5, 6)
            pygame.draw.line(bg, (215,160,110), (wc[0]-wr, wc[1]), (wc[0]+wr, wc[1]), 3); pygame.draw.line(bg, WHITE, (wc[0]-18, wc[1]-6), (wc[0]-6, wc[1]-20), 2)
        for sx in (8, panel.right+14):                                       # side shelves with berry jars
            for sy in (170, 330, 490):
                pygame.draw.rect(bg, (150,95,55), (sx, sy, 98, 10), border_radius=4)
                pygame.draw.rect(bg, (190,130,80), (sx, sy, 98, 4), border_radius=3)
                for j, c in enumerate(((200,40,190), (80,110,235), (230,50,70))):
                    jx = sx + 6 + j*31
                    pygame.draw.rect(bg, (205,230,245), (jx, sy-40, 26, 40), border_radius=7)
                    for bb in range(5): _berry(bg, c, jx+6+(bb%3)*7, sy-10-(bb//3)*9, 4)
                    pygame.draw.rect(bg, (240,120,150), (jx-1, sy-46, 28, 8), border_radius=3)
                    pygame.draw.line(bg, WHITE, (jx+4, sy-34), (jx+4, sy-20), 2)
        pn = pygame.Surface(panel.size, pygame.SRCALPHA)
        pygame.draw.rect(pn, (255,255,255), (0,0)+panel.size, border_radius=16)
        pn.blit(_vgrad(panel.w, panel.h, (255,240,210), (235,205,165)), (0,0), special_flags=pygame.BLEND_RGB_MULT)
        bg.blit(pn, panel.topleft)
        for i in range(12):   # scalloped awning across the top
            col = (240,60,90) if i%2==0 else WHITE
            pygame.draw.rect(bg, col, (panel.x+i*80, panel.y, 80, 26))
            pygame.draw.circle(bg, col, (panel.x+i*80+40, panel.y+26), 40, draw_top_right=False, draw_top_left=False)
            pygame.draw.circle(bg, (225,120,140) if col != WHITE else (240,200,205), (panel.x+i*80+40, panel.y+26), 40, 2, draw_top_right=False, draw_top_left=False)
        pygame.draw.rect(bg, GOLD, panel, 5, border_radius=16)
        pygame.draw.rect(bg, (230,170,120), panel.inflate(6,6), 2, border_radius=18)
        pygame.draw.circle(bg, (255,225,200), (panel.x+96, 92), 52)                     # soft spotlight behind Hazel
        bg.blit(pygame.transform.smoothscale(shopkeeper_img, (112,84)), (panel.x+40, 50))   # Hazel the shopkeeper
        pygame.draw.circle(bg, (255,120,160), (panel.x+128, 66), 7); pygame.draw.circle(bg, (255,200,220), (panel.x+126, 64), 3)   # flower clip
        pygame.draw.rect(bg, (200,135,80), (panel.x+30, 116, 140, 22), border_radius=8)   # her little counter
        pygame.draw.rect(bg, (230,170,110), (panel.x+30, 116, 140, 7), border_radius=6)
        for j, c in enumerate(((200,40,190), (80,110,235), (230,50,70), (200,40,190))): _berry(bg, c, panel.x+60+j*26, 112, 6)
        _SHOP_BG.append(bg)
    screen.blit(_SHOP_BG[0], (0,0))
    draw_fairy_lights([(x, 6 + int(6*math.sin(x/40))) for x in range(20, WIDTH, 46)])   # twinkly fairy lights along the top
    t = otext(font, "BERRY SHOP", (255,215,90), (110,50,20), 3); screen.blit(t, (WIDTH//2-t.get_width()//2, 51))
    screen.blit(shop_txt(tinyfont, f'Hazel says: "Welcome! Everything costs {berry_word()}!"', True, (110,50,20)), (panel.x+170, 100))
    inv = fox.inventory
    bt = shop_txt(font, (f"Crystals: {inv['berries']}" if is_space() else f"Your berries: {inv['berries']}"), True, (150,0,150)); screen.blit(bt, (panel.right-bt.get_width()-30, 54))
    for i, (key, name, price, what) in enumerate(SHOP_ITEMS):
        y = 150 + i*48
        can = inv["berries"] >= price
        row = pygame.Rect(panel.x+30, y, panel.w-60, 42)
        screen.blit(shop_card(row.size, can), row.topleft)                              # soft cartoon item card
        pygame.draw.circle(screen, (255,240,220) if can else (225,205,180), (row.x+28, row.centery), 18)   # icon plate
        if i == shop_sel:   # the item she picked glows gold with an arrow
            pygame.draw.rect(screen, GOLD, row, 4, border_radius=8)
            pygame.draw.polygon(screen, (200,0,120), [(row.x-22,row.centery-10),(row.x-6,row.centery),(row.x-22,row.centery+10)])
        if key in TREASURES: draw_treasure(screen, key, row.x+28, row.centery)
        elif key in ("sticks", "stones") and is_space():   # level 8 shop shows the space look
            si = collectible_image(SPACE_ITEM["stick" if key == "sticks" else "stone"]); screen.blit(si, si.get_rect(center=(row.x+28, row.centery)))
        elif key == "sticks":
            pygame.draw.line(screen, (120,75,35), (row.x+20, row.y+34), (row.x+36, row.y+8), 7)
            pygame.draw.line(screen, (175,115,60), (row.x+20, row.y+34), (row.x+36, row.y+8), 4)
            pygame.draw.ellipse(screen, (90,170,70), (row.x+30, row.y+14, 12, 7))
        elif key == "stones":   # the same axe-head stone as on the map
            si = collectible_image("stone"); screen.blit(si, si.get_rect(center=(row.x+28, row.centery)))
        elif key == "axes":
            ai = pygame.transform.rotate(axe_art(), 90); screen.blit(ai, ai.get_rect(center=(row.x+28, row.centery)))
        col = (40,110,40) if can else (120,90,70)
        screen.blit(shop_txt(tinyfont, f"{i+1}:  {shop_name(name)}  ({what})", True, col), (row.x+60, row.y+12))
        pt = shop_txt(tinyfont, f"{price} {berry_word(price)}", True, (150,0,150))
        screen.blit(pt, (row.right-pt.get_width()-20, row.y+12))
    # the collection shelf
    sy = 545
    screen.blit(shop_txt(tinyfont, "Your collection:", True, (110,50,20)), (panel.x+40, sy))
    if inv.get("dagger", 0):   # the wizard's glowing dagger sits on the shelf too
        draw_dagger(screen, panel.x+260 + len(TREASURES)*130 - 20, sy+10)
        screen.blit(shop_txt(tinyfont, f"x{inv['dagger']}", True, (110,50,20)), (panel.x+260 + len(TREASURES)*130, sy))
    for j, k in enumerate(TREASURES):
        x = panel.x+260 + j*130
        draw_treasure(screen, k, x, sy+10)
        screen.blit(shop_txt(tinyfont, f"x{inv.get(k,0)}", True, (110,50,20)), (x+16, sy))
    screen.blit(shop_txt(tinyfont, f"You have: {inv['sticks']} {mat_word('sticks')}, {inv['stones']} {mat_word('stones')}, {inv['axes']} axes  (press C outside to craft)", True, (110,50,20)), (panel.x+40, sy+40))
    if shop_msg_frames > 0:
        m = shop_txt(tinyfont, shop_msg, True, (200,0,120)); screen.blit(m, (WIDTH//2-m.get_width()//2, sy+75))
    e = shop_txt(tinyfont, "UP/DOWN or 1-8 to pick   B = buy (or ENTER/SPACE)   E to leave  (timer paused)", True, (110,50,20))
    screen.blit(e, (WIDTH//2-e.get_width()//2, panel.bottom-32))

# ---------- LITTLE FOXES WHO LIVE IN THE VILLAGE ----------
VILLAGER_INFO = [  # name, fur, darker fur, what they say (all about their own life and hobbies)
    ("Pip",     (175,125,235), (120,80,185),   "I paint sunsets every evening. Tonight I'll use extra pink!"),
    ("Maple",   (190,70,30),   (140,45,15),  "I collect shiny pebbles. My best one sparkles like a star!"),
    ("Snowy",   (245,245,250), (190,190,205),"Why did the fox sing to the moon? It wanted a howl-o-gram! Hee hee!"),
    ("Ember",   (230,60,30),   (170,35,15),  "I'm learning to bake at the new Fox Cafe. My muffins are so fluffy!"),
    ("Ash",     (150,150,160), (100,100,110),"Last night I counted 100 stars. Then I fell asleep at 101!"),
    ("Honey",   (240,190,60),  (190,140,30), "Meet my pet ladybug, Dot! She has seven spots and loves daisies."),
]
VILLAGE_WALK = pygame.Rect(VILLAGE_RECT.x+60, VILLAGE_RECT.centery-110, VILLAGE_RECT.w-120, 220)

class VillageFox:
    def __init__(self, name, fur, dark, line):
        self.name, self.line = name, line; self.cols = (tuple(fur), tuple(dark))
        self.base = make_fox(fur, dark)   # same size as the player's fox
        self.frames = [make_fox(fur, dark, pose=k) for k in range(5)]
        self.step = 0; self.left = False
        self.image = self.base
        self.rect = self.image.get_rect(center=self.pick_spot())
        self.x, self.y = float(self.rect.centerx), float(self.rect.centery)
        self.target = self.pick_spot(); self.wait = random.randint(0,120)
        self.talk_frames = 0
    def pick_spot(self):
        while True:
            p = (random.randint(VILLAGE_WALK.left, VILLAGE_WALK.right), random.randint(VILLAGE_WALK.top, VILLAGE_WALK.bottom))
            if not STATUE_RECT.inflate(90,90).collidepoint(p) and not (shop and shop.rect.inflate(40,40).collidepoint(p)) \
               and not (globals().get('cafe') and cafe.rect.inflate(40,40).collidepoint(p)):
                return p
    def update(self):
        if self.talk_frames > 0 or self.wait > 0:   # standing still: legs rest
            self.image = pygame.transform.flip(self.base, True, False) if self.left else self.base
        if self.talk_frames > 0:   # stand still while chatting
            self.talk_frames -= 1; return
        if self.wait > 0:
            self.wait -= 1; return
        dx, dy = self.target[0]-self.x, self.target[1]-self.y
        d = math.hypot(dx, dy)
        if d < 3:
            self.target = self.pick_spot(); self.wait = random.randint(60,240); return
        self.x += dx/d*1.3; self.y += dy/d*1.3
        self.left = dx <= 0; self.step += 1
        img = self.frames[1 + (self.step // 6) % 4]   # walking legs
        self.image = img if dx > 0 else pygame.transform.flip(img, True, False)
        self.rect.center = (int(self.x), int(self.y))
    def draw(self, surf, cx, cy):
        hop = -int(8*abs(math.sin(self.talk_frames/8))) if self.talk_frames > 0 else idle_breath(self, 1.3)
        img = self.image
        if self.talk_frames > 0 and getattr(self, "cols", None):   # chatting: happy ^ ^ eyes
            img = make_fox(*self.cols, pose=0, mood=toon_talk_mood(self.talk_frames)); img = pygame.transform.flip(img, True, False) if self.left else img
        v_ = clay_vel(self); sx_, sy_ = clay_squash(self, abs(v_[0]) + abs(v_[1]) > 0.3, math.pi*self.step/12.0)   # clay squash & stretch on her steps
        im_ = clay_scaled(img, sx_, sy_)
        blit_fox(surf, im_, (self.rect.x-cx + (img.get_width() - im_.get_width())//2, self.rect.y-cy+hop + img.get_height() - im_.get_height()), self.left, len(self.name) + ord(self.name[0]), vel=v_)   # tail swish
        n = otext(tinyfont, self.name, WHITE, (90,50,20))
        surf.blit(n, (self.rect.centerx-cx-n.get_width()//2, self.rect.y-cy-20+hop))
        if self.talk_frames > 0:   # speech bubble
            t = shop_txt(tinyfont, self.line, True, BLACK)
            b = pygame.Rect(0,0,t.get_width()+20,t.get_height()+14)
            b.midbottom = (self.rect.centerx-cx, self.rect.y-cy-24)
            anime_bubble(surf, b, b.centerx, (110,60,40))   # anime speech bubble
            surf.blit(t, (b.x+10, b.y+7))

_VTREE_CACHE = {}
def village_tree_image(shade):   # bold anime village tree: fluffy clumped canopy, cel shading, outlined trunk (village only)
    if shade not in _VTREE_CACHE:
        s = pygame.Surface((80,110), pygame.SRCALPHA)
        leaf = _light(shade, 25); dark = _dark(leaf, 45); lite = _light(leaf, 55)
        bark, bark_d = (150,92,48), (110,62,30)
        pygame.draw.polygon(s, bark_d, [(31,108),(33,62),(47,62),(50,108)])                  # trunk (a little flared)
        pygame.draw.polygon(s, bark, [(33,106),(35,62),(45,62),(46,106)])
        pygame.draw.line(s, (200,140,85), (37,68), (37,102), 3)                              # shine stripe
        pygame.draw.polygon(s, bark, [(32,108),(26,109),(34,100)]); pygame.draw.polygon(s, bark, [(48,108),(55,109),(46,100)])   # little roots
        clumps = ((40,30,24),(20,44,17),(60,44,17),(28,58,17),(52,58,17),(40,52,20),(26,24,14),(55,24,14))
        for cx, cy, r in clumps: pygame.draw.circle(s, dark, (cx+2, cy+4), r)               # shadow tone
        for cx, cy, r in clumps: pygame.draw.circle(s, leaf, (cx, cy), r)                   # main tone
        for cx, cy, r in clumps:                                                            # light tone on the top-left of each puff
            pygame.draw.circle(s, lite, (cx - r//4, cy - r//4), max(3, r*2//3))
        for cx, cy, r in clumps:                                                            # keep a bit of mid tone so puffs read as round
            pygame.draw.circle(s, leaf, (cx + r//3, cy + r//3), max(2, r//2))
        s = _outline(s, _dark(leaf, 95), 2)                                                 # bold dark outline around everything
        for cx, cy, r in ((32,18,6),(48,28,4),(20,38,4),(58,38,3)):                         # bright highlight blobs
            pygame.draw.ellipse(s, _light(lite, 70), (cx - r, cy - r//2, 2*r, r))
        for ax, ay in ((24,46),(54,40),(44,60),(34,34)):                                    # shiny red apples
            pygame.draw.circle(s, (120,15,25), (ax,ay), 5); pygame.draw.circle(s, (235,40,55), (ax,ay), 4)
            pygame.draw.circle(s, WHITE, (ax-1,ay-2), 1); pygame.draw.line(s, (90,60,30), (ax, ay-5), (ax+1, ay-7), 1)
        for bx, by in ((16,30),(62,52),(40,14),(30,62)):                                    # tiny pink blossoms
            for k in range(5):
                a_ = k*2*math.pi/5; pygame.draw.circle(s, (255,190,215), (int(bx + 2.5*math.cos(a_)), int(by + 2.5*math.sin(a_))), 2)
            pygame.draw.circle(s, (255,230,120), (bx, by), 1)
        _star_glint(s, 64, 20, 4)
        _VTREE_CACHE[shade] = _ready(s)
    return _VTREE_CACHE[shade]

class VillageTree(pygame.sprite.Sprite):
    # a round leafy tree for between the village houses
    def __init__(self, x, y, shade):
        super().__init__()
        self.image = village_tree_image(shade)
        self.rect = pygame.Rect(0,0,30,40); self.rect.midbottom = (x, y+50)               # only the trunk bumps the fox
        self.draw_pos = (x-40, y-60)

villagers = []
shopkeeper_img = make_fox((200,120,60), (150,80,30))

# ---------- THE SECRET CAVE (you can walk inside!) ----------
CAVE_RECT = pygame.Rect(0, 0, 240, 170); CAVE_RECT.center = (int(4500*WS), WORLD_H-int(2000*WS))
CAVE_DOOR = pygame.Rect(CAVE_RECT.centerx-50, CAVE_RECT.bottom-30, 100, 34)
CAVE_ROOM = pygame.Rect(150, 110, 900, 520)
CAVE_EXIT = pygame.Rect(CAVE_ROOM.centerx-50, CAVE_ROOM.bottom-22, 100, 22)
cave_fox = pygame.Rect(0, 0, 56, 42)
cave_sparkles = [(random.randint(CAVE_ROOM.x+40, CAVE_ROOM.right-40), random.randint(CAVE_ROOM.y+30, CAVE_ROOM.y+200)) for _ in range(40)]

# ---------- cartoon / anime cave art (outside mounds + insides) ----------
def _mask_layer(layer, mask):   # keep layer only where mask is opaque
    out = layer.copy(); out.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN); return out
def _soft_glow(w, h, col, a, steps=8):
    g = pygame.Surface((w, h), pygame.SRCALPHA)
    for k in range(steps):
        f = k/steps; pygame.draw.ellipse(g, col + (int(a*(k+1)/steps),), (int(w*f/2), int(h*f/2), max(1, int(w*(1-f))), max(1, int(h*(1-f)))))
    return g
def _star_glint(surf, x, y, r, col=(255,255,255)):   # anime 4-point sparkle
    pygame.draw.polygon(surf, col, [(x, y-r), (x+r*0.22, y-r*0.22), (x+r, y), (x+r*0.22, y+r*0.22), (x, y+r), (x-r*0.22, y+r*0.22), (x-r, y), (x-r*0.22, y-r*0.22)])
def _flower(surf, x, y, col):
    for a in range(5):
        pygame.draw.circle(surf, col, (int(x+3*math.cos(a*1.2566)), int(y+3*math.sin(a*1.2566))), 2)
    pygame.draw.circle(surf, (255,235,120), (x, y), 1)
def _cave_mound(pal, seed):
    """the outside of a cave: a soft round cel-shaded rock hill with moss, vines, flowers and a cozy glowing doorway"""
    w, h = CAVE_RECT.w, CAVE_RECT.h; rr = random.Random(seed)
    base, light, shade, deep = pal["base"], pal["light"], pal["shade"], pal["deep"]
    mask = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.ellipse(mask, (255,255,255,255), (4, 6, w-8, (h-6)*2 - 20))           # round hill, flat bottom
    for bx, by, br in ((46,50,26), (w-48,56,24), (88,26,20), (w-92,30,18)):            # rounded boulders on the hill
        pygame.draw.circle(mask, (255,255,255,255), (bx, by), br)
    lay = pygame.Surface((w, h), pygame.SRCALPHA); lay.fill(shade + (255,))
    pygame.draw.ellipse(lay, base, (-6, 0, w-18, (h-6)*2 - 34))                      # cel-shading: shade band on the right/bottom
    pygame.draw.ellipse(lay, light, (24, 8, w*0.55, 44))                                # highlight band top-left
    for bx, by, br in ((46,50,26), (w-48,56,24), (88,26,20), (w-92,30,18)):
        pygame.draw.circle(lay, shade, (bx+3, by+3), br)
        pygame.draw.circle(lay, base, (bx-2, by-2), br-3)
        pygame.draw.ellipse(lay, light, (bx-br*0.6, by-br*0.75, br*0.9, br*0.5))
    for _ in range(9):   # soft rock specks
        pygame.draw.ellipse(lay, deep, (rr.randint(20, w-40), rr.randint(60, h-20), rr.randint(6, 12), rr.randint(3, 6)))
    s = _mask_layer(lay, mask)
    rim = pygame.mask.from_surface(mask, 10).outline()
    if len(rim) > 2: pygame.draw.lines(s, deep, True, rim, 2)                          # soft edge in the rock's own darker color
    # moss cap with drips
    for mx, my, mw in ((40,10,70), (95,2,60), (140,8,66), (68,22,40), (150,26,44)):
        pygame.draw.ellipse(s, pal["moss2"], (mx, my+3, mw, 20)); pygame.draw.ellipse(s, pal["moss"], (mx, my, mw, 17))
        pygame.draw.ellipse(s, _light(pal["moss"], 45), (mx+8, my+3, mw//3, 5))
    for dx in (52, 78, 112, 150, 176):
        pygame.draw.line(s, pal["moss"], (dx, 20), (dx, 30 + (dx*7) % 14), 5); pygame.draw.circle(s, pal["moss"], (dx, 31 + (dx*7) % 14), 3)
    # cozy rounded doorway (warm inside, no black)
    door = pygame.Rect(w//2-54, 64, 108, h-64)
    pygame.draw.rect(s, pal["arch2"], door.inflate(18, 10).move(0, 5), border_top_left_radius=60, border_top_right_radius=60)
    pygame.draw.rect(s, pal["arch"], door.inflate(12, 6).move(0, 3), border_top_left_radius=58, border_top_right_radius=58)
    for k in range(7):   # stone blocks around the arch
        a = math.pi + k*math.pi/6; cx_, cy_ = door.centerx + 59*math.cos(a), door.y + 55 + 59*math.sin(a)
        pygame.draw.circle(s, _light(pal["arch"], 25), (int(cx_), int(cy_)), 7); pygame.draw.circle(s, pal["arch"], (int(cx_)+1, int(cy_)+1), 5)
    inside = _vgrad(door.w, door.h, pal["in_top"], pal["in_bot"]); m = pygame.Surface(door.size, pygame.SRCALPHA)
    pygame.draw.rect(m, (255,255,255,255), (0, 0) + door.size, border_top_left_radius=54, border_top_right_radius=54)
    ins = pygame.Surface(door.size, pygame.SRCALPHA); ins.blit(inside, (0, 0)); ins.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    s.blit(ins, door.topleft)
    s.blit(_soft_glow(110, 60, pal["glow"], 150), (door.centerx-55, h-58))              # warm glow spilling out
    # vines with leaves and little flowers
    for vx, side in ((door.x-4, -1), (door.right+4, 1), (34, -1), (w-30, 1)):
        pts = [(vx + side*int(5*math.sin(t*0.9)), 34 + t*12) for t in range(0, 10) if 34 + t*12 < h-6]
        if len(pts) > 1: pygame.draw.lines(s, pal["vine"], False, pts, 3)
        for i, (px, py) in enumerate(pts[1::2]):
            pygame.draw.ellipse(s, pal["moss"], (px + (2 if i % 2 else -10), py-3, 9, 6))
    for fx, fy, fc in ((30,104,(255,170,200)), (52,128,(255,255,255)), (w-38,110,(255,200,120)), (w-58,134,(255,170,200)),
                       (door.x-12,96,(255,255,255)), (door.right+12,120,(255,170,200)), (70,150,(255,220,120)), (w-74,152,(255,255,255))):
        _flower(s, fx, fy, fc)
    for gx in range(6, w-6, 14):   # grass tufts along the bottom
        pygame.draw.polygon(s, pal["moss"], [(gx, h), (gx+4, h-9 - (gx*3) % 5), (gx+8, h)])
    _star_glint(s, 64, 20, 5); _star_glint(s, w-70, 40, 4)
    return _ready(s)
CAVE_PAL = dict(base=(172,162,222), light=(222,214,250), shade=(132,120,195), deep=(108,96,170), moss=(110,210,120), moss2=(80,170,100),
                vine=(80,160,90), arch=(160,150,198), arch2=(128,118,172), in_top=(150,95,120), in_bot=(255,175,105), glow=(255,180,90))
BCAVE_PAL = dict(base=(214,165,215), light=(240,205,240), shade=(180,128,190), deep=(155,105,170), moss=(130,205,130), moss2=(95,170,105),
                 vine=(85,165,95), arch=(196,150,205), arch2=(165,118,180), in_top=(165,90,150), in_bot=(255,165,215), glow=(255,140,220))
_CAVE_OUT = []
def draw_cave_outside(cx, cy):
    r = CAVE_RECT.move(-cx, -cy)
    if not _CAVE_OUT: _CAVE_OUT.append(_cave_mound(CAVE_PAL, 11))
    screen.blit(_CAVE_OUT[0], r.topleft)
    t = pygame.time.get_ticks()   # a little cartoon campfire flickers deep inside
    fx, fy = r.centerx + 18, r.bottom - 20; f = 1 + 0.18*math.sin(t/90)
    pygame.draw.circle(screen, (255,120,50), (fx, fy-5), 7); pygame.draw.polygon(screen, (255,120,50), [(fx-7, fy-6), (fx, fy-int(20*f)), (fx+7, fy-6)])
    pygame.draw.circle(screen, (255,220,110), (fx, fy-4), 4); pygame.draw.polygon(screen, (255,220,110), [(fx-4, fy-5), (fx, fy-int(12*f)), (fx+4, fy-5)])
    t2 = otext(tinyfont, "Secret Cave", WHITE); screen.blit(t2, (r.centerx-t2.get_width()//2, r.y-26))

def enter_cave():
    global state, pause_start
    state = "cave"; pause_start = pygame.time.get_ticks()
    cave_fox.center = (CAVE_ROOM.centerx, CAVE_ROOM.bottom-80)
    cave_fox2.center = (CAVE_ROOM.centerx+80, CAVE_ROOM.bottom-80)

def leave_cave():
    global state, start_ticks
    start_ticks += pygame.time.get_ticks() - pause_start   # timer was paused in the cave
    fox.rect.midtop = (CAVE_RECT.centerx, CAVE_RECT.bottom + 30)
    if two_player: fox2.rect.topleft = (fox.rect.x + 70, fox.rect.y)
    state = "playing"

def _cave_room_bg(pal, seed, crystals=True, pool=True):
    """the inside of a cave, cartoon style: rounded walls, cel-shaded floor, rounded stalactites"""
    rr = random.Random(seed)
    bg = _vgrad(WIDTH, HEIGHT, pal["out_top"], pal["out_bot"])
    R = CAVE_ROOM
    room = pygame.Surface(R.size, pygame.SRCALPHA)
    pygame.draw.rect(room, (255,255,255), (0, 0) + R.size, border_radius=40)
    room.blit(_vgrad(R.w, R.h, pal["wall_top"], pal["wall_bot"]), (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    for _ in range(16):   # soft rounded rock bumps on the back wall (lighter on top, shade below)
        bx, by, bw = rr.randint(20, R.w-120), rr.randint(60, 190), rr.randint(60, 130)
        pygame.draw.ellipse(room, pal["bump_shade"], (bx, by+6, bw, bw*0.45))
        pygame.draw.ellipse(room, pal["bump"], (bx, by, bw, bw*0.42))
        pygame.draw.ellipse(room, pal["bump_light"], (bx+bw*0.15, by+4, bw*0.4, bw*0.1))
    bg.blit(room, R.topleft)
    floor = pygame.Rect(R.x, R.y+230, R.w, R.h-230)
    fl = pygame.Surface(floor.size, pygame.SRCALPHA)
    pygame.draw.rect(fl, (255,255,255), (0, 0) + floor.size, border_radius=30)
    fl.blit(_vgrad(floor.w, floor.h, pal["floor_top"], pal["floor_bot"]), (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    bg.blit(fl, floor.topleft)
    pygame.draw.line(bg, pal["floor_edge"], (floor.x+28, floor.y+2), (floor.right-28, floor.y+2), 4)   # lit floor edge
    for _ in range(30):   # rounded pebbles with a highlight
        px, py = rr.randint(floor.x+30, floor.right-30), rr.randint(floor.y+20, floor.bottom-20); pw = rr.randint(8, 16)
        pygame.draw.ellipse(bg, pal["pebble_shade"], (px, py+2, pw, pw*0.55))
        pygame.draw.ellipse(bg, pal["pebble"], (px, py, pw, pw*0.5))
        pygame.draw.ellipse(bg, pal["bump_light"], (px+2, py+1, pw*0.4, 2))
    pygame.draw.rect(bg, pal["frame"], R, 5, border_radius=40)
    for i in range(14):   # rounded stalactites with a shine stripe and a drip
        x = R.x+40+i*62; tip = R.y+40+(i*37) % 50
        body = [(x, R.y), (x+30, R.y), (x+19, tip-8), (x+11, tip-8)]
        pygame.draw.polygon(bg, pal["stal_shade"], body); pygame.draw.circle(bg, pal["stal_shade"], (x+15, tip-8), 5)
        pygame.draw.polygon(bg, pal["stal"], [(x, R.y), (x+22, R.y), (x+15, tip-9), (x+11, tip-9)])
        pygame.draw.circle(bg, pal["stal"], (x+14, tip-9), 4)
        pygame.draw.line(bg, pal["stal_light"], (x+6, R.y+3), (x+12, tip-14), 3)
        if i % 3 == 0: pygame.draw.circle(bg, (190,225,255), (x+15, tip+2), 3); pygame.draw.circle(bg, WHITE, (x+14, tip+1), 1)
    if pool:   # a shimmering pool (same spot as before)
        pr = pygame.Rect(R.centerx-130, R.y+250, 260, 70)
        pygame.draw.ellipse(bg, pal["pool_rim2"], pr.inflate(22, 16).move(0, 4))
        pygame.draw.ellipse(bg, pal["pool_rim"], pr.inflate(16, 12))
        pygame.draw.ellipse(bg, (70,135,225), pr)
        pygame.draw.ellipse(bg, (100,170,240), pr.inflate(-26, -18).move(0, 3))
        pygame.draw.ellipse(bg, (150,210,255), (R.centerx-95, R.y+260, 120, 18))
    if crystals:   # sparkly crystal clusters with their own soft glow
        for cx, cy, col in ((R.x+120, R.y+300, (120,200,255)), (R.right-140, R.y+280, (255,130,215)),
                            (R.x+260, R.bottom-60, (185,145,255)), (R.right-280, R.bottom-50, (120,240,185))):
            bg.blit(_soft_glow(110, 110, col, 70), (cx-55, cy-65))
            for ox, sc in ((-14, 0.62), (14, 0.7), (0, 1.0)):
                hgt, wid = int(44*sc), int(15*sc); x0 = cx + ox
                pts = [(x0, cy-hgt), (x0+wid, cy-hgt+wid), (x0+wid, cy+4), (x0, cy+10), (x0-wid, cy+4), (x0-wid, cy-hgt+wid)]
                pygame.draw.polygon(bg, _dark(col, 45), pts)
                pygame.draw.polygon(bg, col, [(x0, cy-hgt), (x0, cy+10), (x0-wid, cy+4), (x0-wid, cy-hgt+wid)])
                pygame.draw.polygon(bg, _light(col, 70), [(x0, cy-hgt), (x0-wid, cy-hgt+wid), (x0-wid+4, cy-hgt+wid+3), (x0-1, cy-hgt+6)])
                pygame.draw.line(bg, WHITE, (x0-wid+4, cy-hgt+wid+6), (x0-wid+4, cy-4), 2)
            pygame.draw.ellipse(bg, pal["pebble_shade"], (cx-28, cy+4, 56, 12))
    ex = pygame.Surface((CAVE_EXIT.w+40, 60), pygame.SRCALPHA)
    for k in range(6): pygame.draw.ellipse(ex, (255,230,150,20), (k*4, k*5, ex.get_width()-k*8, 60-k*5))
    bg.blit(ex, (CAVE_EXIT.x-20, CAVE_EXIT.y-40))
    pygame.draw.rect(bg, (255,225,140), CAVE_EXIT, border_radius=6)                       # light from the way out
    pygame.draw.rect(bg, (255,250,215), CAVE_EXIT.inflate(-30,-10), border_radius=4)
    return bg
CAVE_IN_PAL = dict(out_top=(80,60,120), out_bot=(50,38,85), wall_top=(120,98,170), wall_bot=(92,76,138), bump=(136,114,186), bump_light=(170,152,215),
                   bump_shade=(100,84,148), floor_top=(158,128,150), floor_bot=(122,98,124), floor_edge=(190,165,190), pebble=(150,128,150),
                   pebble_shade=(112,92,118), frame=(105,88,150), stal=(150,135,195), stal_light=(200,190,235), stal_shade=(118,104,165),
                   pool_rim=(175,160,205), pool_rim2=(130,118,170))
BCAVE_IN_PAL = dict(out_top=(110,55,110), out_bot=(70,38,85), wall_top=(150,85,150), wall_bot=(112,62,120), bump=(168,100,165), bump_light=(205,145,205),
                    bump_shade=(125,72,130), floor_top=(160,112,140), floor_bot=(125,85,112), floor_edge=(200,150,190), pebble=(150,108,140),
                    pebble_shade=(115,80,110), frame=(130,75,135), stal=(185,125,185), stal_light=(230,180,230), stal_shade=(145,92,150),
                    pool_rim=(200,150,205), pool_rim2=(160,110,170))
_WORM_GLOW = []
_CRYS_GLOW = []
def draw_cave_magic(crystal_pts):   # twinkling anime star glints on the crystals + soft glowing worms
    t = pygame.time.get_ticks()
    if not _WORM_GLOW: _WORM_GLOW.append(_soft_glow(26, 26, (120,255,190), 120, 6))
    for i, (x, y) in enumerate(cave_sparkles):   # soft glowing worms gently bobbing
        b = math.sin(t/500 + i*1.7); yy = int(y + 3*b)
        if 0.35 + 0.65*(0.5 + 0.5*math.sin(t/350 + i)) > 0.45:
            screen.blit(_WORM_GLOW[0], (x-13, yy-13))
            pygame.draw.circle(screen, (150,255,210), (x, yy), 3); pygame.draw.circle(screen, (235,255,245), (x-1, yy-1), 1)
    if not _CRYS_GLOW: _CRYS_GLOW.extend([_soft_glow(56, 56, (90,160,255), 120, 7), _soft_glow(56, 56, (200,110,255), 120, 7)])
    for i, (x, y) in enumerate(crystal_pts):
        k = (math.sin(t/260 + i*2.3) + 1) / 2
        g = _CRYS_GLOW[i % 2]; g.set_alpha(int(110 + 130*k)); screen.blit(g, (x-28, y-28), special_flags=pygame.BLEND_RGB_ADD)   # glowing crystals
        if k > 0.35: _star_glint(screen, x, y, int(3 + 7*k))
def draw_pool_shimmer():
    t = pygame.time.get_ticks(); R = CAVE_ROOM
    for k in range(3):
        x = R.centerx - 80 + int(70*math.sin(t/900 + k*2.1)) + k*40; y = R.y + 274 + k*10
        pygame.draw.ellipse(screen, (215,240,255), (x, y, 34 - k*6, 4))
    ph = (t % 2000) / 2000.0   # a ripple ring growing out
    rw = int(40 + 140*ph); rh = int(10 + 34*ph)
    rip = pygame.Surface((rw, rh), pygame.SRCALPHA); pygame.draw.ellipse(rip, (230,245,255, int(160*(1-ph))), (0, 0, rw, rh), 2)
    screen.blit(rip, (R.centerx - rw//2 + 30, R.y + 288 - rh//2))
def draw_cartoon_fire(fx, fy):   # anime campfire: rounded stones, logs with rings, outlined cel-shaded teardrop flames
    t = pygame.time.get_ticks()
    for sx in (-30, -14, 2, 18, 34):
        pygame.draw.ellipse(screen, (125,115,140), (fx+sx-9, fy+16, 18, 13)); pygame.draw.ellipse(screen, (165,155,180), (fx+sx-7, fy+16, 13, 7))
    for a, b, c in (((fx-28, fy+18), (fx+26, fy+6), (150,90,50)), ((fx-26, fy+6), (fx+28, fy+18), (170,105,60))):
        pygame.draw.line(screen, _dark(c, 30), a, b, 11); pygame.draw.line(screen, c, a, b, 7)
        for e in (a, b): pygame.draw.circle(screen, (230,190,130), e, 5); pygame.draw.circle(screen, (190,140,90), e, 2)
    # ---- bold anime flames: dark outline, cel-shaded layers, curly swaying teardrop tips, sparkly embers, soft glow ----
    if not _FIRE_GLOW: _FIRE_GLOW.append(_soft_glow(120, 120, (255,170,80), 70, 8))
    _FIRE_GLOW[0].set_alpha(int(200 + 55*math.sin(t/140.0)*math.sin(t/57.0 + 1)))
    screen.blit(_FIRE_GLOW[0], (fx-60, fy-50))          # soft warm glow behind the flames
    draw_embers(fx, fy - 20)   # glowing embers drifting up
    def tear(cx_, base, w, hgt, curl):   # teardrop flame with a rounded bottom and a curly tip that leans by `curl`
        right, left = [], []
        for i in range(9):
            u = i / 8.0; hw = w * (1 - u)**0.85 * min(1.0, 0.55 + u*1.6)
            x0 = cx_ + curl * u*u; y0 = base - hgt*u
            right.append((x0 + hw, y0)); left.append((x0 - hw, y0))
        return right + left[::-1] + [(cx_ - w*0.75, base + w*0.25), (cx_, base + w*0.5), (cx_ + w*0.75, base + w*0.25)]
    OUT = (120,30,35)
    sw = math.sin(t/170); sw2 = math.sin(t/130 + 1.3)
    f1 = 1 + 0.12*math.sin(t/80); f2 = 1 + 0.15*math.sin(t/65 + 1)
    for side, k in ((-1, sw), (1, sw2)):   # two little curly side tips that flicker and sway
        tx = fx + side*15; th = (24 + 6*k) * f2
        pts = tear(tx, fy+4, 7, th, side*(6 + 5*k))
        pygame.draw.polygon(screen, OUT, pts); pygame.draw.polygon(screen, (235,75,45), tear(tx, fy+4, 5, th-4, side*(6 + 5*k)))
        pygame.draw.polygon(screen, (255,160,50), tear(tx, fy+4, 2.5, th*0.55, side*(3 + 3*k)))
    outer = tear(fx, fy+10, 22, 58*f1, 7*sw)
    pygame.draw.polygon(screen, OUT, outer); pygame.draw.lines(screen, OUT, True, outer, 4)        # bold dark outline
    pygame.draw.polygon(screen, (235,75,45), tear(fx, fy+10, 19, 54*f1, 7*sw))                     # deep red-orange outer
    pygame.draw.polygon(screen, (205,55,40), tear(fx+7, fy+10, 10, 40*f1, 6*sw))                  # cel-shade band on the right
    pygame.draw.polygon(screen, (255,150,45), tear(fx-2, fy+10, 14, 42*f2, 5*sw2))                # bright orange middle
    pygame.draw.polygon(screen, (255,236,150), tear(fx-1, fy+10, 8, 26*f1, 3*sw))                 # yellow core
    pygame.draw.polygon(screen, (255,252,230), tear(fx-2, fy+11, 4, 13*f2, 2*sw2))                # white-hot heart
    pygame.draw.ellipse(screen, (255,205,120), (fx-12, fy-30*f1, 5, 12))                          # glossy anime highlight
    for k in range(5):   # sparkly embers drifting up
        ph = ((t/900.0) + k/5.0) % 1.0
        ex, ey = int(fx + 16*math.sin(ph*9 + k*1.7)), int(fy - 30 - 55*ph)
        if k % 2 == 0 and ph < 0.7: pygame.draw.circle(screen, (255,200,90), (ex, ey), max(1, int(4 - 3*ph)))
        else:
            pygame.draw.circle(screen, (255,150,60), (ex, ey), 3 if ph < 0.5 else 2); pygame.draw.circle(screen, (255,240,170), (ex, ey), 1)
_FIRE_GLOW = []
CAVE_CRYSTAL_GLINTS = [(CAVE_ROOM.x+114, CAVE_ROOM.y+262), (CAVE_ROOM.right-146, CAVE_ROOM.y+242), (CAVE_ROOM.x+254, CAVE_ROOM.bottom-98), (CAVE_ROOM.right-286, CAVE_ROOM.bottom-88)]
_CAVE_BG = []
def cave_background():
    if not _CAVE_BG: _CAVE_BG.append(_cave_room_bg(CAVE_IN_PAL, 3))
    return _CAVE_BG[0]

# ---------- SHOO BALL: a little green ball friend in the Secret Cave (levels 1-10) ----------
SHOO_POS = (CAVE_ROOM.right-110, CAVE_ROOM.y+420)   # right side: below the pink crystal, right of the green one, away from fire/exit
SHOO_R = 11   # small: about 22 px across
SHOO_NAME = "Shoo Ball"
SHOO_LINE = "You found me! Now I will come with you and shoo trolls away."
shoo_talk = 0
shoo_follow = False; shoo_xy = list(SHOO_POS); shoo_room = None; shoo_shout = False   # after you talk to her she comes along
SHOO_ROOMS = {"cave": "cave", "berry_cave": "berry_cave", "inside": "inside", "cafe": "cafe"}
def shoo_room_key():   # which room we're seeing now ("world" outside, None = shop/menu where she hides)
    if state in ("menu", "shop"): return None
    return SHOO_ROOMS.get(state, "world")
def shoo_leader(rk):   # the fox she follows (player 1, or player 2 if player 1 is a little ghost)
    p2 = two_player and fox.out and not fox2.out
    if rk == "world": return (fox2 if p2 else fox).rect, (fox2 if p2 else fox).face_left
    if rk in ("cave", "berry_cave"): return (cave_fox2 if p2 else cave_fox), (fox2 if p2 else fox).face_left
    return (inside_fox2 if p2 else inside_fox), (fox2 if p2 else fox).face_left
def update_shoo_ball():   # once a frame: trail behind the fox and shoo trolls away from HER
    global shoo_room, shoo_shout
    shoo_shout = False
    if level == 11 or not shoo_follow: return
    rk = shoo_room_key()
    if rk is None: return
    r, fl = shoo_leader(rk)
    tx, ty = r.centerx + (42 if fl else -42), r.centery + 8   # just behind her
    if rk != shoo_room: shoo_xy[0], shoo_xy[1] = tx, ty; shoo_room = rk   # new room: she pops in right behind
    if state in ("playing", "cave", "berry_cave", "inside", "cafe") and not crafting_open:
        shoo_xy[0] += (tx - shoo_xy[0]) * 0.09; shoo_xy[1] += (ty - shoo_xy[1]) * 0.09   # smooth trailing
    if rk != "world": return
    for t in list(trolls) + ([boss] if boss else []):
        dx, dy = t.rect.centerx - shoo_xy[0], t.rect.centery - shoo_xy[1]; d = math.hypot(dx, dy)
        if d < 250:
            shoo_shout = True
            if t is not boss and state == "playing" and not crafting_open and d < 180 and t.bounce == 0:   # gently turn the troll away
                d = d or 1; a = math.atan2(dy, dx) + random.uniform(-0.4, 0.4)
                t.bounce = 40; t.bvec = (math.cos(a), math.sin(a))
_SHOO_IMG = {}
def _make_shoo_ball(shoo):
    """round bright-green ball with a cute anime face; shoo=True -> mouth wide open"""
    S = 4; R = 22*S; W = R*2 + 8*S;   # drawn big, then shrunk smoothly so the face stays crisp
    s = pygame.Surface((W, W), pygame.SRCALPHA); c = W//2
    pygame.draw.circle(s, (40,120,50), (c, c), R + 5*S)                           # bold dark-green outline (thick so it survives shrinking)
    pygame.draw.circle(s, (70,200,80), (c, c), R)                                 # cel shade (lower right)
    pygame.draw.circle(s, (110,235,110), (c - 4*S, c - 4*S), R - 4*S)             # bright green body
    pygame.draw.ellipse(s, (190,255,180), (c - R*0.62, c - R*0.78, R*0.7, R*0.38))  # glossy highlight
    pygame.draw.circle(s, WHITE, (int(c - R*0.48), int(c - R*0.5)), 3*S)
    ey = c - 3*S
    for ex in (c - 9*S, c + 9*S):                                                 # big shiny anime eyes
        pygame.draw.ellipse(s, (30,40,60), (ex - 5*S, ey - 7*S, 10*S, 14*S))
        pygame.draw.ellipse(s, (60,110,170), (ex - 4*S, ey - 1*S, 8*S, 6*S))
        pygame.draw.circle(s, WHITE, (ex - 2*S, ey - 3*S), 2*S + 1)
        pygame.draw.circle(s, WHITE, (ex + 2*S, ey + 3*S), S)
    blush = pygame.Surface((10*S, 5*S), pygame.SRCALPHA); pygame.draw.ellipse(blush, (255,120,150,170), blush.get_rect())
    s.blit(blush, (c - 19*S, c + 4*S)); s.blit(blush, (c + 9*S, c + 4*S))       # rosy cheeks
    my = c + 7*S
    if shoo:   # mouth wide open: "Shoo!"
        pygame.draw.ellipse(s, (120,30,50), (c - 5*S, my - 3*S, 10*S, 10*S))
        pygame.draw.ellipse(s, (255,120,140), (c - 3*S, my + 2*S, 6*S, 4*S))
        pygame.draw.ellipse(s, (40,120,50), (c - 5*S, my - 3*S, 10*S, 10*S), S)
    else:      # small happy smile
        pygame.draw.arc(s, (40,90,45), (c - 4*S, my - 4*S, 8*S, 6*S), math.pi, 2*math.pi, 2*S)
    k = SHOO_R / (22*S); s = pygame.transform.smoothscale(s, (max(1, int(W*k)), max(1, int(W*k))))
    return _ready(s)
def trolls_near_cave(dist=250):   # any troll (regular, green or the boss) within ~250 px of the Secret Cave?
    for t in list(trolls) + ([boss] if boss else []):
        x = max(CAVE_RECT.left, min(t.rect.centerx, CAVE_RECT.right)); y = max(CAVE_RECT.top, min(t.rect.centery, CAVE_RECT.bottom))
        if math.hypot(t.rect.centerx - x, t.rect.centery - y) < dist: return True
    return False
def shoo_bubble(x, y):   # bold outlined "Shoo!" in a white bubble
    txt = otext(font, "Shoo!", (60,170,70), th=2)
    b = pygame.Rect(0, 0, txt.get_width() + 22, txt.get_height() + 10); b.midbottom = (x, y)
    anime_bubble(screen, b, x, (40,120,50))
    screen.blit(txt, (b.x + 11, b.y + 5))
GRR_FRAMES, GRR_COOLDOWN = 72, 180   # "Grr!" shows ~1.2 s; each troll waits ~3 s before it can grr again
_VEIN = {}
def anger_vein(ph, k=1.0):   # the anime "angry cross" vein mark
    key = (ph, k)
    if key not in _VEIN:
        n = int(22*k); s = pygame.Surface((n, n), pygame.SRCALPHA); c = n/2; r = n*(0.36 if ph else 0.42)
        for a in (0.785, 2.356, 3.927, 5.498):
            ox, oy = c + math.cos(a)*r*0.75, c + math.sin(a)*r*0.75
            rect = pygame.Rect(0, 0, int(r*1.1), int(r*1.1)); rect.center = (int(ox), int(oy))
            pygame.draw.arc(s, (240,40,60), rect, a + 2.1, a + 4.2, max(2, int(3*k)))
        _VEIN[key] = s
    return _VEIN[key]
def grr_step(players):   # a troll that reached for a fox and MISSED says "Grr!" (just for fun, no gameplay change)
    who = [t for t in trolls] + ([boss] if boss else [])
    for t in who:
        r = 400 if t is boss else (MEAN_NOTICE if is_mean(t) else TROLL_REACH)   # same distances the arms use to reach out
        if getattr(t, "grr_t", 0) > 0: t.grr_t -= 1
        if getattr(t, "grr_cd", 0) > 0: t.grr_cd -= 1
        live = [pf for pf in players if not pf.out]
        near = [pf for pf in live if math.hypot(pf.rect.centerx-t.rect.centerx, pf.rect.centery-t.rect.centery) < r]
        seen = getattr(t, "reach_seen", None)
        if near:   # reaching: remember each fox's hearts when it first got close
            if seen is None: seen = t.reach_seen = {}
            for pf in near: seen.setdefault(id(pf), (pf, pf.hearts))
        elif seen is not None:   # everyone got away: escaped if no fox it reached for lost a heart
            if all(pf.hearts >= h and not pf.out for pf, h in seen.values()) and getattr(t, "grr_cd", 0) == 0:
                t.grr_t, t.grr_cd = GRR_FRAMES, GRR_COOLDOWN
            t.reach_seen = None
def draw_grr(cx, cy):   # red "Grr!" bubble over a grumpy troll
    for t in [t for t in trolls] + ([boss] if boss else []):
        if getattr(t, "grr_t", 0) <= 0: continue
        x = t.rect.centerx - cx + int(2*math.sin(t.grr_t*1.3)); y = t.rect.top - cy - 6
        txt = font.render("Grr!", True, (220,50,40))
        b = pygame.Rect(0, 0, txt.get_width() + 22, txt.get_height() + 10); b.midbottom = (x, y)
        pygame.draw.rect(screen, WHITE, b, border_radius=10); pygame.draw.rect(screen, (150,30,20), b, 2, border_radius=10)   # plain Oct 29 bubble
        pygame.draw.polygon(screen, WHITE, [(b.centerx-8,b.bottom-2),(b.centerx+8,b.bottom-2),(b.centerx,b.bottom+10)])
        screen.blit(txt, (b.x + 11, b.y + 5))
def shoo_ball_near():   # a fox close enough to chat (same 100 px as the village foxes)
    if level == 11 or shoo_follow: return False
    foxes = [cave_fox] + ([cave_fox2] if two_player else [])
    return any(math.hypot(r.centerx-SHOO_POS[0], r.centery-SHOO_POS[1]) < 100 for r in foxes)
def talk_shoo_ball():
    global shoo_talk, shoo_follow, shoo_room
    if shoo_ball_near():
        shoo_talk = 240   # same 4 seconds as the village foxes
        shoo_follow = True; shoo_xy[0], shoo_xy[1] = SHOO_POS; shoo_room = "cave"   # now she comes along!
def draw_shoo_ball(cx=0, cy=0):
    global shoo_talk
    if level == 11: shoo_talk = 0; return   # not on the golden finale (Dorfghan's level)
    rk = shoo_room_key()
    if shoo_follow:
        if rk is None or rk != shoo_room: return     # she's drawn in the room where the fox is
    elif state != "cave": return                     # waiting at home in the Secret Cave
    if not _SHOO_IMG: _SHOO_IMG[False] = _make_shoo_ball(False); _SHOO_IMG[True] = _make_shoo_ball(True)
    t = pygame.time.get_ticks(); shoo = shoo_shout if shoo_follow else trolls_near_cave()
    talking = shoo_talk > 0
    if talking: bob = abs(math.sin(shoo_talk/8)) * 6                                 # happy hop while chatting (like the village foxes)
    else: bob = abs(math.sin(t/(160 if shoo else 380))) * (6 if shoo else 3)          # gentle bounce (bouncier when shooing)
    x, y = (int(shoo_xy[0]) - cx, int(shoo_xy[1]) - cy) if shoo_follow else SHOO_POS
    sh = pygame.Surface((20, 6), pygame.SRCALPHA); pygame.draw.ellipse(sh, (0,0,0,60), sh.get_rect())
    screen.blit(sh, (x - 10, y + SHOO_R - 2))
    toon_draw_shoo(shoo and not talking, talking, x, y, bob)   # cartoon eyes, blinks, talks, squashes when she lands
    n = otext(tinyfont, SHOO_NAME, WHITE, (90,50,20)); top = int(y - SHOO_R - bob)
    if talking:   # speech bubble in the same style as the Fox Village foxes
        screen.blit(n, (x - n.get_width()//2, top - 20))
        tt = shop_txt(tinyfont, SHOO_LINE, True, BLACK)
        b = pygame.Rect(0,0,tt.get_width()+20,tt.get_height()+14); b.midbottom = (x, top - 24)
        b.clamp_ip(pygame.Rect(10, 10, WIDTH-20, HEIGHT-20))
        pygame.draw.rect(screen, WHITE, b, border_radius=10); pygame.draw.rect(screen, (90,50,20), b, 2, border_radius=10)
        pygame.draw.polygon(screen, WHITE, [(x-8,b.bottom-2),(x+8,b.bottom-2),(x,b.bottom+10)])
        screen.blit(tt, (b.x+10, b.y+7))
        if state in ("cave", "playing", "berry_cave", "inside", "cafe"): shoo_talk -= 1
    elif shoo: shoo_bubble(x, top - 12)
    else: screen.blit(n, (x - n.get_width()//2, top - 20))
    if not talking and not shoo_follow and shoo_ball_near() and state == "cave":
        h = tinyfont.render(f"Press T to talk to {SHOO_NAME}", True, YELLOW)
        screen.blit(h, (cave_fox.centerx-h.get_width()//2, cave_fox.bottom+6))

def draw_cave():
    screen.blit(cave_background(), (0,0))
    t = pygame.time.get_ticks()
    draw_pool_shimmer()
    draw_cave_magic(CAVE_CRYSTAL_GLINTS)
    # a little crackling campfire
    fx, fy = CAVE_ROOM.right-330, CAVE_ROOM.y+370
    glow = pygame.Surface((240,160), 0, 32); glow.fill((0,0,0))
    g = random.randint(0,8)
    for k in range(8):   # soft warm firelight, brighter toward the middle
        w, h = 240-k*26, 160-k*17
        pygame.draw.ellipse(glow, (6+k*4+g//2, 3+k*2, 0), (120-w//2, 80-h//2, w, h))
        screen.blit(glow, (fx-120, fy-90), special_flags=pygame.BLEND_RGB_ADD); glow.fill((0,0,0))
    draw_cartoon_fire(fx, fy)
    if (t//450) % 4 == 0:
        c = otext(tinyfont, "crackle!", (255,210,110), (150,70,40)); screen.blit(c, (fx+34, fy-64))
    draw_wizard()
    draw_shoo_ball()
    blit_fox(screen, fox.image, cave_fox.topleft, fox.face_left, 1); draw_held_dagger(cave_fox, fox.face_left)
    screen.blit(otext(bigfont, "Secret Cave", (150,255,200), th=3), (WIDTH//2-213, 17))
    h = otext(tinyfont, "Walk out the bright exit or press E to leave   (timer paused)", WHITE)
    screen.blit(h, (WIDTH//2-h.get_width()//2, CAVE_ROOM.bottom+30))

# Inside a house
ROOM = pygame.Rect(200, 120, 800, 500)
INSIDE_DOOR = pygame.Rect(ROOM.centerx-40, ROOM.bottom-20, 80, 20)
inside_fox = pygame.Rect(0, 0, 56, 42)
houses = []
current_house = None
pause_start = 0

def leave_house():
    global state, start_ticks
    start_ticks += pygame.time.get_ticks() - pause_start   # timer was paused inside
    fox.rect.midtop = (current_house.rect.centerx, current_house.rect.bottom + 30)
    if two_player: fox2.rect.topleft = (fox.rect.x + 70, fox.rect.y)
    state = "playing"

ROOM_PALS = [{'wt': (255, 232, 205), 'wb': (250, 208, 180), 'wp': (255, 205, 190), 'rug': ((235, 120, 160), (255, 175, 200), (255, 225, 150)), 'quilt': ((130, 185, 250), (180, 215, 255)), 'acc': (255, 150, 180)}, {'wt': (225, 240, 255), 'wb': (200, 222, 250), 'wp': (185, 210, 245), 'rug': ((120, 170, 235), (170, 205, 250), (255, 240, 200)), 'quilt': ((255, 160, 180), (255, 205, 215)), 'acc': (150, 190, 255)}, {'wt': (240, 230, 255), 'wb': (220, 205, 250), 'wp': (210, 190, 245), 'rug': ((175, 130, 225), (215, 180, 250), (255, 220, 240)), 'quilt': ((140, 215, 185), (190, 240, 215)), 'acc': (200, 160, 250)}, {'wt': (228, 250, 232), 'wb': (205, 238, 212), 'wp': (190, 230, 200), 'rug': ((100, 190, 140), (160, 225, 180), (255, 245, 200)), 'quilt': ((255, 195, 120), (255, 225, 170)), 'acc': (130, 210, 160)}, {'wt': (255, 244, 215), 'wb': (250, 225, 180), 'wp': (250, 215, 165), 'rug': ((240, 160, 90), (255, 200, 140), (255, 245, 215)), 'quilt': ((175, 150, 240), (215, 195, 255)), 'acc': (255, 190, 110)}, {'wt': (255, 228, 235), 'wb': (250, 200, 215), 'wp': (250, 185, 205), 'rug': ((120, 200, 200), (170, 230, 225), (255, 240, 245)), 'quilt': ((255, 140, 170), (255, 190, 205)), 'acc': (255, 140, 175)}, {'wt': (232, 245, 255), 'wb': (210, 232, 248), 'wp': (195, 225, 245), 'rug': ((255, 170, 120), (255, 210, 170), (255, 250, 230)), 'quilt': ((120, 200, 170), (175, 230, 205)), 'acc': (130, 200, 240)}, {'wt': (250, 240, 225), 'wb': (240, 220, 195), 'wp': (235, 205, 175), 'rug': ((205, 120, 170), (240, 170, 205), (255, 235, 180)), 'quilt': ((120, 170, 230), (170, 205, 245)), 'acc': (230, 160, 120)}]
def _room_index():
    return (houses.index(current_house) if current_house in houses else 0) % len(ROOM_PALS)
_ROOM_BG = {}
FAIRY = [(ROOM.x + 30 + k*37, ROOM.y + 14 + int(9*math.sin(k*0.9))) for k in range(21)]   # fairy lights along the top of the wall
def _jar(bg, x, y, col):
    pygame.draw.rect(bg, (215,235,245), (x, y, 20, 26), border_radius=6)
    pygame.draw.rect(bg, col, (x + 2, y + 10, 16, 14), border_radius=5)
    pygame.draw.rect(bg, _light(col, 60), (x + 4, y + 11, 4, 8), border_radius=2)
    pygame.draw.rect(bg, (240,150,170), (x - 1, y - 4, 22, 6), border_radius=3)
    pygame.draw.line(bg, WHITE, (x + 4, y + 3), (x + 4, y + 8), 2)
def room_background():
    i = _room_index()
    if i not in _ROOM_BG:
        P = ROOM_PALS[i]; rr = random.Random(40 + i)
        bg = _vgrad(WIDTH, HEIGHT, _dark(P["wb"], 70), _dark(P["wb"], 105))
        R = ROOM
        mask = pygame.Surface(R.size, pygame.SRCALPHA); pygame.draw.rect(mask, (255,255,255,255), (0, 0) + R.size, border_radius=28)
        room = pygame.Surface(R.size, pygame.SRCALPHA)
        room.blit(_vgrad(R.w, 170, P["wt"], P["wb"]), (0, 0))                                   # warm gradient wall
        for xx in range(0, R.w, 40):                                                             # soft wallpaper stripes + little hearts/flowers
            pygame.draw.rect(room, _light(P["wp"], 10), (xx, 0, 14, 160))
        for yy in range(26, 150, 36):
            for xx in range(20 + (20 if (yy//36) % 2 else 0), R.w - 10, 40):
                c = P["wp"]
                pygame.draw.circle(room, _dark(c, 10), (xx - 2, yy), 3); pygame.draw.circle(room, _dark(c, 10), (xx + 2, yy), 3)
                pygame.draw.polygon(room, _dark(c, 10), [(xx - 5, yy + 1), (xx + 5, yy + 1), (xx, yy + 6)])
        pygame.draw.rect(room, (215,160,110), (0, 150, R.w, 12)); pygame.draw.rect(room, (240,195,140), (0, 150, R.w, 4))   # chair rail
        floor = pygame.Rect(0, 170, R.w, R.h - 170)
        room.blit(_vgrad(floor.w, floor.h, (225,165,110), (190,128,80)), floor.topleft)        # wooden plank floor
        for k, yy in enumerate(range(floor.y, floor.bottom, 30)):
            pygame.draw.line(room, (175,115,70), (0, yy), (R.w, yy), 2)
            pygame.draw.line(room, (245,195,140), (0, yy + 3), (R.w, yy + 3), 1)
            for xx in range(60 + (90 if k % 2 else 0), R.w, 180): pygame.draw.line(room, (180,120,75), (xx, yy), (xx, yy + 30), 2)
        for _ in range(5):   # shiny floor highlights
            hx, hy = rr.randint(40, R.w - 140), rr.randint(floor.y + 20, floor.bottom - 30)
            pygame.draw.ellipse(room, (240,190,135), (hx, hy, rr.randint(60, 110), 5))
        pygame.draw.rect(room, (190,130,85), (0, floor.y - 8, R.w, 10)); pygame.draw.rect(room, (220,160,110), (0, floor.y - 8, R.w, 3))   # baseboard
        room.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        bg.blit(room, R.topleft)
        # round window with sky and curtains (same spot as before)
        wc = (R.x + 145, R.y + 82); wr = 44
        sky = pygame.Surface((wr*2, wr*2), pygame.SRCALPHA); sky.blit(_vgrad(wr*2, wr*2, (130,200,255), (215,240,255)), (0, 0))
        pygame.draw.circle(sky, (255,240,140), (wr + 18, wr - 14), 11); pygame.draw.ellipse(sky, WHITE, (12, wr + 6, 40, 14)); pygame.draw.ellipse(sky, WHITE, (30, wr, 26, 14))
        mk = pygame.Surface((wr*2, wr*2), pygame.SRCALPHA); pygame.draw.circle(mk, (255,255,255,255), (wr, wr), wr); sky.blit(mk, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        bg.blit(sky, (wc[0] - wr, wc[1] - wr))
        pygame.draw.circle(bg, (190,130,85), wc, wr + 6, 7); pygame.draw.circle(bg, (225,170,115), wc, wr + 4, 3)
        pygame.draw.line(bg, (210,155,105), (wc[0] - wr, wc[1]), (wc[0] + wr, wc[1]), 4); pygame.draw.line(bg, (210,155,105), (wc[0], wc[1] - wr), (wc[0], wc[1] + wr), 4)
        pygame.draw.line(bg, WHITE, (wc[0] - 26, wc[1] - 6), (wc[0] - 8, wc[1] - 26), 3)   # glass glint
        cc = P["acc"]
        for side in (-1, 1):   # swoopy curtains with tie-backs
            x0 = wc[0] + side*(wr + 4)
            pts = [(x0 - side*30, wc[1] - wr - 14), (x0 + side*14, wc[1] - wr - 14), (x0 + side*16, wc[1] + wr + 6), (x0 + side*2, wc[1] + wr + 8), (x0 + side*4, wc[1] + 10), (x0 - side*20, wc[1] - wr + 6)]
            pygame.draw.polygon(bg, _dark(cc, 25), pts); pygame.draw.polygon(bg, cc, [(p[0] - side*2, p[1] - 2) for p in pts])
            pygame.draw.line(bg, _light(cc, 50), (x0 + side*6, wc[1] - wr - 8), (x0 + side*8, wc[1] + wr), 2)
            pygame.draw.circle(bg, (255,220,120), (x0 + side*6, wc[1] + 10), 5)
        pygame.draw.rect(bg, (200,140,95), (wc[0] - wr - 50, wc[1] - wr - 20, 2*wr + 100, 8), border_radius=4)   # curtain rod
        # shelves with jars and a little plant
        for sy, items in ((R.y + 72, 4), (R.y + 128, 3)):
            sx = R.x + 270
            pygame.draw.rect(bg, (185,125,80), (sx, sy, 190, 10), border_radius=4); pygame.draw.rect(bg, (225,170,115), (sx, sy, 190, 4), border_radius=3)
            for j in range(items):
                _jar(bg, sx + 12 + j*44, sy - 27, ((200,60,190), (90,140,240), (240,90,90), (255,200,70))[(j + i) % 4])
            px = sx + 12 + items*44
            pygame.draw.rect(bg, (230,150,110), (px, sy - 16, 18, 16), border_radius=4)
            for a in (-0.6, 0, 0.6): pygame.draw.ellipse(bg, (110,190,110), (px + 4 + int(10*a), sy - 34, 10, 20))
        # cartoon fireplace (same spot as before)
        fp = pygame.Rect(R.right-270, R.y+40, 180, 170)
        pygame.draw.rect(bg, (200,175,170), fp, border_top_left_radius=24, border_top_right_radius=24)
        for row, yy in enumerate(range(fp.y + 10, fp.bottom - 6, 22)):   # rounded pastel stones
            for xx in range(fp.x + 6 + (14 if row % 2 else 0), fp.right - 14, 30):
                pygame.draw.rect(bg, (170,145,145), (xx, yy + 2, 26, 18), border_radius=8)
                pygame.draw.rect(bg, (225,205,200), (xx, yy, 26, 17), border_radius=8)
                pygame.draw.rect(bg, (245,232,228), (xx + 4, yy + 3, 10, 4), border_radius=2)
        pygame.draw.rect(bg, (175,115,75), (fp.x - 12, fp.y - 8, fp.w + 24, 16), border_radius=8)   # wooden mantel
        pygame.draw.rect(bg, (215,155,100), (fp.x - 12, fp.y - 8, fp.w + 24, 6), border_radius=6)
        op = pygame.Rect(fp.x + 40, fp.y + 70, 100, 100)
        hole = _vgrad(op.w, op.h, (120,70,95), (230,120,70)); hm = pygame.Surface(op.size, pygame.SRCALPHA)
        pygame.draw.rect(hm, (255,255,255,255), (0, 0) + op.size, border_top_left_radius=46, border_top_right_radius=46)
        hs = pygame.Surface(op.size, pygame.SRCALPHA); hs.blit(hole, (0, 0)); hs.blit(hm, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        bg.blit(hs, op.topleft)
        pygame.draw.rect(bg, (185,160,155), op.inflate(8, 4).move(0, -2), 4, border_top_left_radius=50, border_top_right_radius=50)
        # mantel decorations: a candle and a tiny clock
        pygame.draw.rect(bg, (255,245,230), (fp.x + 10, fp.y - 30, 10, 22), border_radius=3); pygame.draw.ellipse(bg, (255,200,90), (fp.x + 11, fp.y - 42, 8, 13))
        pygame.draw.circle(bg, (240,200,120), (fp.right - 20, fp.y - 22), 14); pygame.draw.circle(bg, (255,250,235), (fp.right - 20, fp.y - 22), 10)
        pygame.draw.line(bg, (180,120,90), (fp.right - 20, fp.y - 22), (fp.right - 20, fp.y - 29), 2); pygame.draw.line(bg, (180,120,90), (fp.right - 20, fp.y - 22), (fp.right - 15, fp.y - 20), 2)
        # cute rug (same spot) with a scalloped border
        rc = P["rug"]; ru = pygame.Rect(R.centerx - 170, R.y + 250, 340, 140)
        pygame.draw.ellipse(bg, _dark(rc[0], 25), ru.inflate(10, 8).move(0, 4))
        for k in range(28):
            a = k * 2*math.pi/28
            pygame.draw.circle(bg, rc[0], (int(ru.centerx + 172*math.cos(a)), int(ru.centery + 71*math.sin(a))), 9)
        pygame.draw.ellipse(bg, rc[0], ru); pygame.draw.ellipse(bg, rc[1], ru.inflate(-36, -26))
        pygame.draw.ellipse(bg, rc[2], ru.inflate(-120, -64), 6)
        for k in range(8):
            a = k*math.pi/4; pygame.draw.circle(bg, rc[2], (int(ru.centerx + 120*math.cos(a)), int(ru.centery + 46*math.sin(a))), 5)
        pygame.draw.ellipse(bg, _light(rc[1], 40), (ru.x + 70, ru.y + 22, 90, 12))
        # little bed (same spot) with a patchwork quilt
        bd = pygame.Rect(R.x+40, R.y+210, 170, 120); q0, q1 = P["quilt"]
        pygame.draw.rect(bg, (165,105,65), (bd.x, bd.y - 12, 34, bd.h + 12), border_radius=14)          # rounded headboard
        pygame.draw.rect(bg, (205,145,95), (bd.x + 4, bd.y - 8, 12, bd.h + 2), border_radius=6)
        pygame.draw.rect(bg, (180,120,75), bd.move(0, 4), border_radius=16); pygame.draw.rect(bg, (215,155,100), bd, border_radius=16)
        pygame.draw.rect(bg, (255,250,245), (bd.x + 14, bd.y + 10, bd.w - 22, bd.h - 22), border_radius=12)   # sheet
        pygame.draw.ellipse(bg, (235,230,240), (bd.x + 22, bd.y + 18, 56, 34)); pygame.draw.ellipse(bg, WHITE, (bd.x + 24, bd.y + 18, 50, 28))   # pillow
        qr = pygame.Rect(bd.x + 70, bd.y + 12, bd.w - 78, bd.h - 26)
        pygame.draw.rect(bg, _dark(q0, 20), qr.move(0, 3), border_radius=12); pygame.draw.rect(bg, q0, qr, border_radius=12)
        for yy in range(2):
            for xx in range(3):
                if (xx + yy) % 2: pygame.draw.rect(bg, q1, (qr.x + 6 + xx*28, qr.y + 8 + yy*40, 24, 34), border_radius=6)
        pygame.draw.line(bg, _light(q0, 50), (qr.x + 6, qr.y + 4), (qr.right - 10, qr.y + 4), 2)
        # round table with a berry bowl (same spot) + a little chair
        tb = pygame.Rect(R.right-230, R.y+320, 150, 70)
        pygame.draw.rect(bg, (175,115,70), (R.right - 92, R.y + 300, 40, 60), border_radius=12)               # chair back
        pygame.draw.rect(bg, (215,155,100), (R.right - 88, R.y + 304, 10, 50), border_radius=5)
        pygame.draw.rect(bg, (170,110,65), (tb.x + 20, tb.y + 30, 12, 40), border_radius=4); pygame.draw.rect(bg, (170,110,65), (tb.right - 32, tb.y + 30, 12, 40), border_radius=4)
        pygame.draw.ellipse(bg, (180,120,75), tb.inflate(0, -20).move(0, -2)); pygame.draw.ellipse(bg, (220,160,105), tb.inflate(-6, -28).move(0, -6))
        pygame.draw.ellipse(bg, (245,195,140), (tb.x + 20, tb.y + 12, 50, 8))
        # (the berry plate on this table is drawn live in draw_inside: it can be eaten!)
        # door with a welcome mat
        pygame.draw.rect(bg, (175,115,70), INSIDE_DOOR, border_top_left_radius=12, border_top_right_radius=12)
        pygame.draw.rect(bg, (215,155,100), INSIDE_DOOR.inflate(-12, -8), border_top_left_radius=10, border_top_right_radius=10)
        pygame.draw.ellipse(bg, P["acc"], (INSIDE_DOOR.x - 14, INSIDE_DOOR.y - 22, INSIDE_DOOR.w + 28, 18))
        pygame.draw.rect(bg, _dark(P["wb"], 40), R, 5, border_radius=28)                                     # soft room edge (no black)
        # fairy light string (the bulbs twinkle in draw_inside)
        pygame.draw.lines(bg, (150,180,130), False, FAIRY, 2)
        _ROOM_BG[i] = bg
    return _ROOM_BG[i]
FAIRY_COLS = [(255,170,200), (255,235,140), (170,220,255), (190,255,190), (220,180,255)]
def draw_fairy_lights(pts):
    t = pygame.time.get_ticks()
    for k, (x, y) in enumerate(pts):
        tw = (math.sin(t/260 + k*1.7) + 1) / 2; c = FAIRY_COLS[k % 5]
        g = pygame.Surface((24, 24), pygame.SRCALPHA)
        pygame.draw.circle(g, c + (int(40 + 70*tw),), (12, 12), 10); pygame.draw.circle(g, c + (int(80 + 100*tw),), (12, 12), 6)
        screen.blit(g, (x - 12, y - 6))
        pygame.draw.circle(screen, c, (x, y + 6), 4); pygame.draw.circle(screen, WHITE, (x - 1, y + 5), 1)
        if tw > 0.85: _star_glint(screen, x + 6, y - 2, 5)

def draw_inside():
    screen.blit(room_background(), (0,0))
    fp = pygame.Rect(ROOM.right-270, ROOM.y+40, 180, 170)
    glow = pygame.Surface((220,140), 0, 32); glow.fill((0,0,0))
    for k in range(7):   # warm firelight on the floor
        w, h = 220-k*28, 140-k*18
        pygame.draw.ellipse(glow, (5+k*3, 3+k*2, 0), (110-w//2, 70-h//2, w, h))
        screen.blit(glow, (fp.centerx-110, fp.bottom-60), special_flags=pygame.BLEND_RGB_ADD); glow.fill((0,0,0))
    draw_cartoon_fire(fp.centerx, fp.y + 140)   # the same layered cartoon flames as the Secret Cave
    draw_fairy_lights(FAIRY)
    draw_kettle()
    draw_plate()
    for hf in house_folks: hf.draw(screen, 0, 0)
    near = [hf for hf in house_folks if hf.talk_frames == 0 and math.hypot(hf.rect.centerx-inside_fox.centerx, hf.rect.centery-inside_fox.centery) < 100]
    if near and not any(hf.talk_frames for hf in house_folks):
        h = otext(tinyfont, f"Press T to talk to {near[0].name}", YELLOW); screen.blit(h, (inside_fox.centerx-h.get_width()//2, inside_fox.bottom+6))
    draw_shoo_ball()
    blit_fox(screen, fox.image, inside_fox.topleft, fox.face_left, 1); draw_held_dagger(inside_fox, fox.face_left)
    if energize_t > 0:
        er = inside_fox2 if energize_who == 2 and two_player else inside_fox
        draw_energize(er.centerx, er.centery, er.top)
    screen.blit(otext(bigfont, "Cozy Fox House", YELLOW, th=3), (WIDTH//2-273, 22))
    t = otext(tinyfont, "The fire warms you up!  Walk out the door or press E to leave", WHITE)
    screen.blit(t, (WIDTH//2 - t.get_width()//2, ROOM.bottom+25))
    screen.blit(tinyfont.render(f"Berries: {fox.inventory['berries']}   (timer paused)", True, WHITE), (ROOM.x, ROOM.bottom+55))

# ================= EDIBLE BERRY PLATES in the village houses (one per house, refills every new level) =================
PLATE_SPOT = pygame.Rect(0, 0, 76, 40); PLATE_SPOT.center = (ROOM.right-155, ROOM.y+312)   # on the round table
PLATE_BERRIES = 3                 # each plate gives +3 berries
house_plates_eaten = set()        # which houses' plates are empty this level
plate_msg = ""; plate_msg_t = 0
_PLATE_IMG = {}
def plate_image(full):   # bold anime plate: cream ceramic, pink rim, cel shadow, shine arc (+ a pile of real berries)
    if full not in _PLATE_IMG:
        W, H = 96, 64; s = pygame.Surface((W, H), pygame.SRCALPHA)
        pr = pygame.Rect(6, 26, 84, 32)
        pygame.draw.ellipse(s, (120,80,90), pr.move(0, 4))                      # soft drop shadow under the plate
        pygame.draw.ellipse(s, (255,150,185), pr)                               # colored rim
        pygame.draw.ellipse(s, (255,250,240), pr.inflate(-12, -8))              # cream ceramic
        pygame.draw.ellipse(s, (240,225,215), pr.inflate(-30, -16).move(0, 2))  # the dip in the middle
        pygame.draw.arc(s, (225,120,160), pr.inflate(-6, -4), math.pi*1.05, math.pi*1.95, 3)   # cel shade along the front rim
        _shade(s, 200); s = _outline(s, (110,60,80), 2)                           # bold anime outline
        pygame.draw.arc(s, WHITE, pr.inflate(-18, -10).move(-4, -1), math.pi*0.55, math.pi*0.95, 3)   # shine arc
        pygame.draw.circle(s, WHITE, (pr.right - 18, pr.y + 8), 2)
        if full:   # a cute pile: strawberries, raspberries, blackberries and blueberries
            for kind, x, y, sz in (("blackberry", 22, 24, 20), ("strawberry", 54, 22, 24), ("blueberry", 36, 30, 18), ("raspberry", 64, 30, 20),
                                   ("blueberry", 48, 36, 16), ("strawberry", 30, 12, 22), ("raspberry", 46, 6, 20)):
                s.blit(real_berry_small(kind, sz), (x - sz//2 + 4, y - sz//2 + 6))
            _star_glint(s, 76, 14, 6); _star_glint(s, 18, 18, 4)
        _PLATE_IMG[full] = _ready(s)
    return _PLATE_IMG[full]
def current_plate_full():
    return (houses.index(current_house) if current_house in houses else -1) not in house_plates_eaten
def draw_plate():
    full = current_plate_full()
    screen.blit(plate_image(full), (PLATE_SPOT.centerx - 48, PLATE_SPOT.centery - 40))
    if full and math.hypot(PLATE_SPOT.centerx - inside_fox.centerx, PLATE_SPOT.centery - inside_fox.centery) < 160:
        h = otext(tinyfont, "Walk to the plate to eat the berries!", YELLOW); screen.blit(h, (PLATE_SPOT.centerx - h.get_width()//2, PLATE_SPOT.y - 56))
    if plate_msg_t > 0:
        m = otext(tinyfont, plate_msg, (255,240,120), (120,50,40))
        screen.blit(m, (PLATE_SPOT.centerx - m.get_width()//2 - 60, PLATE_SPOT.y - 84))
def eat_plate(who):
    global plate_msg, plate_msg_t, energize_t, energize_who
    if heal_fox(who).out: return   # a ghost can't eat
    i = houses.index(current_house) if current_house in houses else -1
    if i in house_plates_eaten: return
    house_plates_eaten.add(i)
    fox.inventory["berries"] += PLATE_BERRIES; picked_order.extend(["berry"] * PLATE_BERRIES)
    plate_msg = f"Yum! Yummy berries! +{PLATE_BERRIES} berries!"; plate_msg_t = 150
    energize_t = 90; energize_who = who          # the little heart + sparkle pop
    save_items(fox.inventory)

# ================= FOX CAFE (in Fox Village, between the first two top-row houses) =================
CAFE_PRICE = 2          # a warm berry muffin costs 2 berries
COCOA_PRICE = 5         # a mug of warm cocoa costs 5 berries
CAFE_MUFFINS = 4        # muffins in the glass case each level
CAFE_STOCK = [CAFE_MUFFINS]   # muffins left (refills every new level / retry)
cafe_pick = [0]               # 0 = Muffin, 1 = Cocoa (picked with 1 / 2 or Tab)
cocoa_steam = [0]             # little steam puff after a cocoa
cafe = None
cafe_msg = ""; cafe_msg_t = 0
def _muffin(surf, x, y, k=1.0):   # a little berry muffin centered on x, bottom at y
    w = int(20*k); h = int(12*k)
    pygame.draw.polygon(surf, (225,150,170), [(x-w//2+2, y-h), (x+w//2-2, y-h), (x+w//2-5, y), (x-w//2+5, y)])   # paper cup
    for j in range(-w//2+5, w//2-3, max(3, int(4*k))): pygame.draw.line(surf, (250,190,205), (x+j, y-h+1), (x+j+1, y-1), 1)
    pygame.draw.ellipse(surf, (190,120,70), (x-w//2, y-h-int(11*k), w, int(15*k)))                           # muffin top
    pygame.draw.ellipse(surf, (225,160,95), (x-w//2+3, y-h-int(10*k), w-8, int(7*k)))
    for bx, by in ((-4, -h-5), (3, -h-7), (6, -h-2), (-1, -h-1)):
        pygame.draw.circle(surf, (110,60,170), (x+int(bx*k), y+int(by*k)), max(1, int(2*k)))                 # berry bits
def _cup(surf, x, y, col):   # a little cup with a handle, bottom at y
    pygame.draw.rect(surf, _dark(col, 30), (x-8, y-13, 16, 14), border_radius=4); pygame.draw.rect(surf, col, (x-7, y-13, 14, 12), border_radius=4)
    pygame.draw.circle(surf, _dark(col, 30), (x+9, y-7), 4, 2)
    pygame.draw.ellipse(surf, (150,95,60), (x-6, y-15, 12, 5))
    pygame.draw.ellipse(surf, _light(col, 60), (x-5, y-10, 3, 5))
def _make_cafe_front():
    W, H = 150, 112
    im = _cottage(W, H, (255,236,214), (175,120,95), base=48, roof_h=40, chimney_x=112)
    for i in range(8):   # cocoa-and-cream striped awning
        col = (150,95,70) if i % 2 == 0 else (255,246,232)
        pygame.draw.rect(im, col, (3 + i*18, 48, 18, 9))
        pygame.draw.circle(im, col, (3 + i*18 + 9, 57), 9, draw_top_left=False, draw_top_right=False)
    pygame.draw.rect(im, (120,75,55), (31, 7, 88, 24), border_radius=10)          # big sign board on the roof
    pygame.draw.rect(im, (255,232,200), (34, 10, 82, 18), border_radius=8)
    t = otext(tinyfont, "Fox Cafe", (150,75,45), (255,250,240), 1); im.blit(t, (75 - t.get_width()//2, 9))
    _round_window(im, 30, 84, 13); _muffin(im, 30, 92, 0.8)                        # a muffin in the window
    _round_window(im, 120, 84, 13); _cup(im, 120, 92, (255,255,255))               # a cup in the window
    _cottage_door(im, 60, 72, 30, 40, (165,105,70))
    pygame.draw.rect(im, (255,250,235), (63, 80, 24, 10), border_radius=3)           # "OPEN" tag on the door
    o = otext(pygame.font.Font(None, 14), "OPEN", (80,160,90), (255,255,255), 0); im.blit(o, (75 - o.get_width()//2, 81))
    _lantern(im, 100, 80)
    for xx in (2, 140):   # little potted flowers
        pygame.draw.rect(im, (225,140,100), (xx, 98, 9, 13), border_radius=3)
        pygame.draw.circle(im, (100,180,100), (xx + 4, 95), 7)
        pygame.draw.circle(im, (255,200,90), (xx + 4, 93), 3)
    pygame.draw.ellipse(im, (215,205,195), (52, 106, 46, 6))                          # door step
    return _ready(im)
class Cafe(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = _make_cafe_front()
        self.rect = self.image.get_rect(center=(x, y))
        self.door = pygame.Rect(self.rect.x+59, self.rect.bottom-20, 32, 30)   # walk up into the door to go in

CAFE_COUNTER = pygame.Rect(ROOM.x+250, ROOM.y+150, 380, 100)      # the long counter along the back (drawn)
CAFE_TABLE_SPOTS = [(ROOM.x+120, ROOM.y+300), (ROOM.right-120, ROOM.y+300), (ROOM.x+190, ROOM.bottom-90), (ROOM.right-190, ROOM.bottom-90)]
CAFE_BLOCKS = [pygame.Rect(CAFE_COUNTER.x, ROOM.y+180, CAFE_COUNTER.w, CAFE_COUNTER.bottom-(ROOM.y+180))] + \
              [pygame.Rect(tx-40, ty-14, 80, 34) for tx, ty in CAFE_TABLE_SPOTS]
# a few little customer foxes sitting on chairs (the other chairs stay empty): (table, side, fur, dark fur, yum timing offset ms)
CAFE_GUESTS = [(0, -1, (170,170,182), (115,115,130), 0), (1, 1, (250,236,212), (205,178,148), 1800), (3, -1, (150,95,60), (100,58,35), 3600)]
CAFE_BLOCKS += [pygame.Rect(CAFE_TABLE_SPOTS[ti][0] + side*58 - 16, CAFE_TABLE_SPOTS[ti][1] - 12, 32, 26) for ti, side, *_ in CAFE_GUESTS]   # can't walk through a sitting fox
_GUEST_IMG = {}
def draw_cafe_guests(t):
    for ti, side, fur, dark, off in CAFE_GUESTS:
        tx, ty = CAFE_TABLE_SPOTS[ti]; cx = tx + side*58
        key = (fur, side)
        if key not in _GUEST_IMG:
            g = pygame.transform.smoothscale(make_fox(fur, dark), (46, 34))   # a bit smaller than the player fox
            _GUEST_IMG[key] = pygame.transform.flip(g, True, False) if side > 0 else g   # facing the table
        ph = (t + off) % 5400; yum = ph < 1500                              # each one says yum at its own time
        bob = int(abs(math.sin(t/120.0))*3) if yum else int(math.sin((t+off)/600.0))   # happy munching wiggle
        img = _GUEST_IMG[key]; blit_fox(screen, img, (cx - img.get_width()//2, ty - 26 - bob), side > 0, ti*3 + side)
        if yum:
            tt = otext(tinyfont, "Yum yum!", (225,70,120), WHITE, 1)
            b = pygame.Rect(0, 0, tt.get_width() + 16, tt.get_height() + 8); b.midbottom = (cx, ty - 34 - bob)
            anime_bubble(screen, b, cx, (225,110,140))
            screen.blit(tt, (b.x + 8, b.y + 4))
cafe_worker_img = None
_CAFE_BG = []
def cafe_background():
    if not _CAFE_BG:
        bg = _vgrad(WIDTH, HEIGHT, (110,75,60), (80,52,42)); R = ROOM
        mask = pygame.Surface(R.size, pygame.SRCALPHA); pygame.draw.rect(mask, (255,255,255,255), (0, 0) + R.size, border_radius=28)
        room = pygame.Surface(R.size, pygame.SRCALPHA)
        room.blit(_vgrad(R.w, 170, (255,240,220), (250,222,196)), (0, 0))            # warm cream wall
        for xx in range(0, R.w, 40): pygame.draw.rect(room, (252,230,206), (xx, 0, 18, 160))   # soft stripes
        pygame.draw.rect(room, (190,130,95), (0, 150, R.w, 12)); pygame.draw.rect(room, (225,170,125), (0, 150, R.w, 4))
        floor = pygame.Rect(0, 170, R.w, R.h - 170)
        for yy in range(floor.y, floor.bottom, 40):                                   # checkerboard cafe floor
            for xx in range(0, R.w, 40):
                c = (250,238,225) if ((xx + yy)//40) % 2 else (205,150,120)
                pygame.draw.rect(room, c, (xx, yy, 40, 40))
        pygame.draw.rect(room, (170,115,80), (0, floor.y - 8, R.w, 10))
        room.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        bg.blit(room, R.topleft)
        # chalkboard menu on the left wall
        mb = pygame.Rect(R.x+40, R.y+38, 170, 110)
        pygame.draw.rect(bg, (160,105,70), mb.inflate(12, 12), border_radius=10); pygame.draw.rect(bg, (60,85,75), mb, border_radius=8)
        bg.blit(otext(tinyfont, "MENU", (255,240,200), (60,85,75), 1), (mb.centerx-26, mb.y+6))
        _muffin(bg, mb.x+26, mb.y+58, 1.0)
        bg.blit(tinyfont.render("Muffin", True, (255,255,255)), (mb.x+46, mb.y+29))
        bg.blit(tinyfont.render(f"{CAFE_PRICE} berries", True, (255,200,230)), (mb.x+46, mb.y+47))
        _cup(bg, mb.x+26, mb.y+100, (255,190,200))
        bg.blit(tinyfont.render("Cocoa", True, (255,255,255)), (mb.x+46, mb.y+70))
        bg.blit(tinyfont.render(f"{COCOA_PRICE} berries", True, (255,200,230)), (mb.x+46, mb.y+88))
        # round window on the right wall
        wc = (R.right-110, R.y+82); wr = 44
        sky = pygame.Surface((wr*2, wr*2), pygame.SRCALPHA); sky.blit(_vgrad(wr*2, wr*2, (130,200,255), (215,240,255)), (0, 0))
        pygame.draw.ellipse(sky, WHITE, (12, wr + 6, 40, 14)); pygame.draw.circle(sky, (255,240,140), (wr + 18, wr - 14), 11)
        mk = pygame.Surface((wr*2, wr*2), pygame.SRCALPHA); pygame.draw.circle(mk, (255,255,255,255), (wr, wr), wr); sky.blit(mk, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        bg.blit(sky, (wc[0]-wr, wc[1]-wr))
        pygame.draw.circle(bg, (170,115,80), wc, wr + 6, 7)
        pygame.draw.line(bg, (200,145,100), (wc[0]-wr, wc[1]), (wc[0]+wr, wc[1]), 4); pygame.draw.line(bg, (200,145,100), (wc[0], wc[1]-wr), (wc[0], wc[1]+wr), 4)
        # shelf behind the counter with cups
        pygame.draw.rect(bg, (170,115,80), (CAFE_COUNTER.x+40, R.y+70, CAFE_COUNTER.w-80, 10), border_radius=4)
        for j in range(7): _cup(bg, CAFE_COUNTER.x+64 + j*42, R.y+70, ((255,190,200), (190,220,255), (255,240,170), (200,240,200))[j % 4])
        # little tables with chairs
        for tx, ty in CAFE_TABLE_SPOTS:
            for side in (-1, 1):   # a chair on each side
                cx = tx + side*58
                pygame.draw.rect(bg, (150,95,65), (cx-14, ty-34, 28, 40), border_radius=8)
                pygame.draw.rect(bg, (200,140,95), (cx-11, ty-31, 8, 32), border_radius=4)
                pygame.draw.ellipse(bg, (235,130,150), (cx-16, ty, 32, 14))                   # comfy pink cushion
            pygame.draw.rect(bg, (150,95,65), (tx-6, ty, 12, 30), border_radius=4)             # table leg
            pygame.draw.ellipse(bg, (140,90,60), (tx-46, ty+24, 92, 14))
            pygame.draw.ellipse(bg, (165,105,70), (tx-44, ty-12, 88, 28)); pygame.draw.ellipse(bg, (255,250,245), (tx-40, ty-14, 80, 22))   # white tablecloth
            pygame.draw.ellipse(bg, (255,190,205), (tx-40, ty-14, 80, 22), 2)
            _cup(bg, tx-14, ty, (255,255,255)); _muffin(bg, tx+14, ty, 0.7)
        # door with a welcome mat
        pygame.draw.rect(bg, (165,105,70), INSIDE_DOOR, border_top_left_radius=12, border_top_right_radius=12)
        pygame.draw.rect(bg, (205,145,100), INSIDE_DOOR.inflate(-12, -8), border_top_left_radius=10, border_top_right_radius=10)
        pygame.draw.ellipse(bg, (235,130,150), (INSIDE_DOOR.x - 14, INSIDE_DOOR.y - 22, INSIDE_DOOR.w + 28, 18))
        pygame.draw.rect(bg, (150,100,75), R, 5, border_radius=28)
        pygame.draw.lines(bg, (150,180,130), False, FAIRY, 2)
        _CAFE_BG.append(bg)
    return _CAFE_BG[0]
_CAFE_COUNTER_IMG = []
def cafe_counter_image():   # the counter (drawn in front of the cafe worker)
    if not _CAFE_COUNTER_IMG:
        C = CAFE_COUNTER; s = pygame.Surface((C.w, C.h + 40), pygame.SRCALPHA); top = 40
        pygame.draw.rect(s, (140,90,60), (0, top, C.w, C.h), border_radius=10)                   # wooden front
        pygame.draw.rect(s, (185,125,85), (6, top + 22, C.w - 12, C.h - 30), border_radius=8)
        for xx in range(30, C.w - 20, 60): pygame.draw.rect(s, (165,108,72), (xx, top + 32, 36, C.h - 50), border_radius=6)   # panels
        pygame.draw.rect(s, (255,232,210), (0, top, C.w, 20), border_radius=8)                    # cream counter top
        pygame.draw.rect(s, (230,200,175), (0, top + 14, C.w, 6))
        # glass case with a cake and muffins
        g = pygame.Rect(16, top - 34, 120, 40)
        pygame.draw.rect(s, (215,240,255), g, border_radius=8); pygame.draw.rect(s, (160,200,225), g, 2, border_radius=8)
        # (the 4 muffins in the case are drawn live in draw_cafe so they disappear as she buys them)
        # a pink layer cake on a stand
        cx = C.w - 90
        pygame.draw.rect(s, (230,230,240), (cx - 4, top - 8, 8, 10)); pygame.draw.ellipse(s, (230,230,240), (cx - 30, top - 12, 60, 8))
        pygame.draw.rect(s, (255,175,200), (cx - 24, top - 36, 48, 26), border_radius=6)
        pygame.draw.rect(s, (255,250,250), (cx - 24, top - 26, 48, 5))
        pygame.draw.ellipse(s, (255,250,250), (cx - 25, top - 40, 50, 10))
        pygame.draw.circle(s, (220,30,60), (cx, top - 42), 5); pygame.draw.circle(s, WHITE, (cx - 2, top - 44), 1)
        _cup(s, C.w - 30, top + 2, (190,220,255)); _cup(s, 170, top + 2, (255,240,170)); _cup(s, 196, top + 2, (255,190,200))
        _CAFE_COUNTER_IMG.append(_ready(s))
    return _CAFE_COUNTER_IMG[0]

def heal_fox(who):   # the fox who bought / touched it (player 2 has her own hearts)
    return fox2 if (who == 2 and two_player) else fox
def who_tag(who): return (" (P2)" if who == 2 else " (P1)") if two_player else ""
def buy_muffin(who=1):
    global cafe_msg, cafe_msg_t, energize_t, energize_who
    inv = fox.inventory; pf = heal_fox(who)
    if CAFE_STOCK[0] <= 0:
        cafe_msg = "All out of muffins! Try the cocoa!"           # sold out: no charge
    elif hearts_left(pf) <= 0:
        cafe_msg = NO_HEARTS_MSG + who_tag(who)                    # heart limit used up: no charge
    elif pf.hearts >= MAX_HEARTS:
        cafe_msg = "You're already full of hearts! Come back later!" + who_tag(who)
    elif inv["berries"] >= CAFE_PRICE:
        inv["berries"] -= CAFE_PRICE; use_heart(pf); CAFE_STOCK[0] -= 1   # one muffin leaves the glass case
        cafe_msg = "Yum! A warm berry muffin! +1 heart!" + who_tag(who); energize_t = 90; energize_who = who
        save_items(inv)
    else:
        need = CAFE_PRICE - inv["berries"]
        cafe_msg = f"You need {need} more {'berry' if need==1 else 'berries'} for a muffin. Pick some from the trees!"
    cafe_msg_t = 200
def buy_cocoa(who=1):
    global cafe_msg, cafe_msg_t, energize_t, energize_who
    inv = fox.inventory; pf = heal_fox(who)
    if hearts_left(pf) <= 0:
        cafe_msg = NO_HEARTS_MSG + who_tag(who)                    # heart limit used up: no charge
    elif pf.hearts >= MAX_HEARTS:
        cafe_msg = "You're already full of hearts! Come back later!" + who_tag(who)
    elif inv["berries"] >= COCOA_PRICE:
        inv["berries"] -= COCOA_PRICE; use_heart(pf)
        cafe_msg = "Mmm! Warm cocoa! +1 heart!" + who_tag(who); energize_t = 90; energize_who = who; cocoa_steam[0] = 90
        save_items(inv)
    else:
        need = COCOA_PRICE - inv["berries"]
        cafe_msg = f"You need {need} more {'berry' if need==1 else 'berries'} for cocoa"
    cafe_msg_t = 200
def buy_cafe(who=None):   # B / Enter / Space buys whatever is picked on the menu board
    if who is None:   # 2 players: the fox standing closer to the counter is the one buying
        who = 1
        if two_player:
            c = CAFE_COUNTER.midbottom; d = lambda r: math.hypot(r.centerx - c[0], r.centery - c[1])
            if fox.out or (not fox2.out and d(inside_fox2) < d(inside_fox)): who = 2
    if cafe_pick[0] == 1: buy_cocoa(who)
    else: buy_muffin(who)

def enter_cafe():
    global state, crafting_open, pause_start, cafe_msg_t
    state = "cafe"; crafting_open = False; cafe_msg_t = 0; cafe_pick[0] = 0
    pause_start = pygame.time.get_ticks()
    inside_fox.center = (ROOM.centerx, ROOM.bottom - 90)
    inside_fox2.center = (ROOM.centerx + 80, ROOM.bottom - 90)

def leave_cafe():
    global state, start_ticks
    start_ticks += pygame.time.get_ticks() - pause_start   # timer was paused in the cafe
    fox.rect.midtop = (cafe.rect.centerx, cafe.rect.bottom + 30)
    if two_player: fox2.rect.topleft = (fox.rect.x + 70, fox.rect.y)
    state = "playing"

def draw_cafe():
    global cafe_worker_img
    screen.blit(cafe_background(), (0, 0))
    draw_fairy_lights(FAIRY)
    t = pygame.time.get_ticks()
    if cafe_worker_img is None:
        cafe_worker_img = pygame.transform.smoothscale(make_fox((235,150,90), (180,100,50)), (56, 42))   # same size as the player fox
    wx, wy = CAFE_COUNTER.centerx + 20, CAFE_COUNTER.y - 66 + int(2*math.sin(t/400))   # Mocha the cafe fox, peeking over the counter
    blit_fox(screen, toon_live_fox((235,150,90), (180,100,50), 4), (wx - 28, wy), False, 4)
    pygame.draw.rect(screen, WHITE, (wx - 2, wy + 19, 15, 11), border_radius=4)        # white apron
    pygame.draw.circle(screen, (235,130,150), (wx + 5, wy + 24), 2)                      # pink apron button
    screen.blit(cafe_counter_image(), (CAFE_COUNTER.x, CAFE_COUNTER.y - 40))
    for k in range(CAFE_STOCK[0]):   # muffins left in the glass case (the right one goes first)
        _muffin(screen, CAFE_COUNTER.x + 34 + k*28, CAFE_COUNTER.y + 2, 0.75)
    pygame.draw.line(screen, WHITE, (CAFE_COUNTER.x + 22, CAFE_COUNTER.y - 28), (CAFE_COUNTER.x + 36, CAFE_COUNTER.y - 28), 2)   # glass shine
    mb = pygame.Rect(ROOM.x+40, ROOM.y+38, 170, 110)   # the chalkboard: highlight what she picked
    row = pygame.Rect(mb.x + 4, mb.y + (26 if cafe_pick[0] == 0 else 67), mb.w - 8, 41)
    pygame.draw.rect(screen, (255,230,110), row, 2, border_radius=6)
    ay = row.centery; pygame.draw.polygon(screen, (255,230,110), [(mb.x - 16, ay - 7), (mb.x - 4, ay), (mb.x - 16, ay + 7)])
    if cafe_pick[0] == 0 and CAFE_STOCK[0] <= 0:
        so = otext(tinyfont, "SOLD OUT", (255,120,120), (90,30,30), 1); screen.blit(so, (row.right - so.get_width() - 2, row.y + 2))
    for k in range(2):   # steam from the cups on the counter
        ph = ((t / 1400.0) + k*0.5) % 1.0
        pygame.draw.circle(screen, (255,255,255), (CAFE_COUNTER.x + 183 + k*26 + int(4*math.sin(ph*6)), CAFE_COUNTER.y - 14 - int(24*ph)), max(1, int(5*(1 - ph))), 1)
    draw_cafe_guests(t)
    draw_shoo_ball()
    line = 'Mocha: "All out of muffins! Try the cocoa!"' if CAFE_STOCK[0] <= 0 else 'Mocha: "Hi! Pick a muffin or cocoa, then press B!"'
    b = shop_txt(tinyfont, line, True, (110,50,20))
    bb = pygame.Rect(0, 0, b.get_width() + 24, b.get_height() + 14); bb.midbottom = (wx, wy - 8)
    pygame.draw.rect(screen, WHITE, bb, border_radius=10); pygame.draw.rect(screen, (150,95,70), bb, 2, border_radius=10)
    screen.blit(b, (bb.x + 12, bb.y + 7))
    blit_fox(screen, fox.image, inside_fox.topleft, fox.face_left, 1); draw_held_dagger(inside_fox, fox.face_left)
    if energize_t > 0:
        er = inside_fox2 if energize_who == 2 and two_player else inside_fox
        draw_energize(er.centerx, er.centery, er.top)
    if cocoa_steam[0] > 0:   # warm cocoa: a little steam puff rising from her
        cocoa_steam[0] -= 1; ph = 1 - cocoa_steam[0] / 90.0
        er = inside_fox2 if energize_who == 2 and two_player else inside_fox
        for k in range(3):
            r = int(5 + 8*ph) - k; sx = er.centerx - 12 + k*12 + int(5*math.sin(ph*8 + k)); sy = er.top - 8 - int(40*ph) - k*6
            if r > 0: pygame.draw.circle(screen, (255,255,255), (sx, sy), r, 2)
    screen.blit(otext(bigfont, "Fox Cafe", (255,215,150), (110,60,30), 3), (WIDTH//2-150, 22))
    if cafe_msg_t > 0:
        m = otext(font, cafe_msg, (255,240,120), (120,50,40), 2)
        if m.get_width() > WIDTH - 40: m = otext(tinyfont, cafe_msg, (255,240,120), (120,50,40), 2)
        mb_ = pygame.Rect(0, 0, m.get_width() + 30, m.get_height() + 12); mb_.center = (WIDTH//2, ROOM.y + 318)
        pygame.draw.rect(screen, (150,95,70), mb_, border_radius=14); pygame.draw.rect(screen, (255,220,180), mb_, 3, border_radius=14)
        screen.blit(m, (mb_.x + 15, mb_.y + 6))
    h = otext(tinyfont, f"1 = muffin ({CAFE_PRICE})  2 = cocoa ({COCOA_PRICE})  B = buy (+1 heart)    Walk out the door or press E to leave   (timer paused)", WHITE)
    screen.blit(h, (WIDTH//2 - h.get_width()//2, ROOM.bottom + 25))
    p2h = f"    P2 Hearts: {fox2.hearts}/{MAX_HEARTS}" if two_player else ""
    screen.blit(tinyfont.render(f"Berries: {fox.inventory['berries']}    {'P1 ' if two_player else ''}Hearts: {fox.hearts}/{MAX_HEARTS}{p2h}", True, WHITE), (ROOM.x, ROOM.bottom + 55))

class Firework:
    def __init__(self, x, y):
        cx = x + random.randint(-450, 450)
        cy = y + random.randint(-220, 150)
        self.color = random.choice(SPRINKLE_COLS if CANDY[0] else [RED, GOLD, ORANGE, YELLOW, (120,200,255), (255,120,220), WHITE])
        self.delay = random.randint(0, 60)
        self.particles = []
        for _ in range(45):
            ang = random.uniform(0, 2*math.pi)
            sp = random.uniform(2, 7)
            self.particles.append([cx, cy, math.cos(ang)*sp, math.sin(ang)*sp, random.randint(40, 75)])
    def update(self):
        if self.delay > 0:
            self.delay -= 1
            return True
        alive = False
        for pt in self.particles:
            if pt[4] > 0:
                pt[0] += pt[2]; pt[1] += pt[3]; pt[3] += 0.08; pt[4] -= 1
                alive = True
        return alive
    def draw(self, surf):
        if self.delay > 0: return
        for pt in self.particles:
            if pt[4] > 0:
                pygame.draw.circle(surf, self.color, (int(pt[0]), int(pt[1])), 3)

# ---------- cached anime world art ----------
def _make_grass():
    T6 = TILE*6; rr = random.Random(11)
    g = pygame.Surface((T6, T6), 0, 32); g.fill((62,184,80))
    for _ in range(7):   # soft cel shadow patches (cool green)
        blob = pygame.Surface((90,56), pygame.SRCALPHA); pygame.draw.ellipse(blob, (40,130,85,45), (0,0,90,56))
        bx, by = rr.randint(0,T6-1), rr.randint(0,T6-1)
        for ox in (-T6, 0):
            for oy in (-T6, 0): g.blit(blob, (bx+ox, by+oy))   # wraps round so the tiles join with no seams
    for _ in range(9):   # sunny lighter patches
        blob = pygame.Surface((90,60), pygame.SRCALPHA); pygame.draw.ellipse(blob, (150,230,120,50), (0,0,90,60))
        bx, by = rr.randint(0,T6-1), rr.randint(0,T6-1)
        for ox in (-T6, 0):
            for oy in (-T6, 0): g.blit(blob, (bx+ox, by+oy))
    for _ in range(46):  # 2-tone grass tufts (dark blade + light sunny tip)
        x, y = rr.randint(6,T6-6), rr.randint(8,T6-4)
        pygame.draw.line(g, (40,135,70), (x,y), (x-3,y-7), 2); pygame.draw.line(g, (40,135,70), (x,y), (x+3,y-8), 2)
        pygame.draw.line(g, (135,220,110), (x-2,y-5), (x-3,y-7), 2); pygame.draw.line(g, (135,220,110), (x+2,y-6), (x+3,y-8), 2)
    for _ in range(7):   # tiny flowers
        x, y = rr.randint(8,T6-8), rr.randint(8,T6-8); c = rr.choice([(200,160,255),(255,170,210),(255,235,110)])
        for a in range(5): pygame.draw.circle(g, c, (x+int(3*math.cos(a*1.26)), y+int(3*math.sin(a*1.26))), 2)
        pygame.draw.circle(g, (255,200,60), (x,y), 1)
    for _ in range(26):  # anime tapered blades
        x, y = rr.randint(6,T6-6), rr.randint(14,T6-4)
        _taper(g, (35,130,70), (x, y), (x-4, y-11), 3); _taper(g, (35,130,70), (x+2, y), (x+5, y-12), 3); _taper(g, (150,230,120), (x-2, y-6), (x-4, y-11), 2)
    for _ in range(8):   # fallen petals
        x, y = rr.randint(6,T6-10), rr.randint(6,T6-6); pygame.draw.ellipse(g, rr.choice([(255,190,215),(255,240,250)]), (x, y, 5, 3))
    for _ in range(5):   # tiny sparkles in the grass
        x, y = rr.randint(8,T6-8), rr.randint(8,T6-8); _glint4(g, x, y, 3, (235,255,220))
    return g
GRASS_TILE = _make_grass()

def _make_mountain():
    s = pygame.Surface((240,206), pygame.SRCALPHA)
    pygame.draw.polygon(s, (150,160,230), [(0,205),(120,25),(240,205)])
    pygame.draw.polygon(s, (112,115,195), [(120,25),(240,205),(150,205)])              # shady side (cel)
    pygame.draw.polygon(s, (175,185,240), [(0,205),(120,25),(70,205)])                 # sunny side
    snow = [(60,85),(120,5),(180,85),(160,78),(146,94),(128,80),(112,96),(96,80),(80,92)]
    pygame.draw.polygon(s, SNOW, snow)
    pygame.draw.polygon(s, (195,210,245), [(120,5),(180,85),(160,78),(146,94),(128,80)])
    s = _outline(s, th=2)
    pygame.draw.line(s, WHITE, (112,22), (86,62), 3)                                   # snow sparkle
    pygame.draw.line(s, WHITE, (118,14), (114,22), 2)
    return s
MOUNTAIN_IMG = _make_mountain()

def _make_village():
    w, h = VILLAGE_RECT.size; rr = random.Random(5)
    s = _vgrad(w, h, (240,205,150), (220,180,125))
    for _ in range(60):
        pygame.draw.ellipse(s, (228,190,138), (rr.randint(0,w), rr.randint(0,h), rr.randint(20,50), rr.randint(8,16)))
    road = pygame.Rect(0, h//2-70, w, 140)
    s.blit(_vgrad(road.w, road.h, (250,228,185), (235,205,160)), road.topleft)
    for x in range(10, w, 46):          # cobblestones along the road
        for k, yy in enumerate((road.y+18, road.y+70, road.bottom-26)):
            pygame.draw.ellipse(s, (215,180,140), (x+(k*15)%46, yy, 30, 14))
            pygame.draw.ellipse(s, (195,160,120), (x+(k*15)%46, yy, 30, 14), 2)
    pygame.draw.line(s, (200,165,120), road.topleft, road.topright, 3)
    pygame.draw.line(s, (200,165,120), road.bottomleft, road.bottomright, 3)
    pygame.draw.rect(s, (175,125,80), (0,0,w,h), 8, border_radius=6)
    pygame.draw.rect(s, OUTLINE, (0,0,w,h), 2, border_radius=6)
    s.blit(otext(font, "Fox Village", (255,235,170), (110,60,25), 3), (38, h//2-23))
    return s
VILLAGE_IMG = _make_village()

def _make_statue():
    s = pygame.Surface((110,130), pygame.SRCALPHA); ox, oy = 20, 20      # statue rect starts at (20,20)
    w, h = STATUE_RECT.size; cx = ox + w//2
    G1, G2 = (255,215,40), (230,160,20)
    pygame.draw.rect(s, (205,190,225), (ox-6, oy+h-22, w+12, 22), border_radius=8)       # stone base
    pygame.draw.rect(s, (235,225,250), (ox-6, oy+h-22, w+12, 7), border_radius=8)
    pygame.draw.ellipse(s, G1, (ox+w-14, oy+40, 22, 34))                                  # tail
    pygame.draw.ellipse(s, G1, (ox+8, oy+30, w-16, h-50))                                 # body
    pygame.draw.polygon(s, G1, [(cx-16,oy+14),(cx-10,oy-6),(cx-3,oy+10)])                # ears
    pygame.draw.polygon(s, G1, [(cx+16,oy+14),(cx+10,oy-6),(cx+3,oy+10)])
    pygame.draw.circle(s, G1, (cx, oy+24), 18)                                            # head
    _shade(s, 175)
    pygame.draw.ellipse(s, (255,250,190), (cx-12, oy+10, 10, 7))                          # golden shine
    pygame.draw.ellipse(s, (255,245,170), (ox+14, oy+38, 8, 22))
    s = _outline(s, th=2)
    for ex in (cx-7, cx+7):                                                               # two shiny eyes
        pygame.draw.ellipse(s, (90,50,20), (ex-3, oy+19, 6, 8)); pygame.draw.circle(s, WHITE, (ex-1, oy+21), 1)
    pygame.draw.polygon(s, WHITE, [(ox+w+2,oy+6),(ox+w+4,oy+12),(ox+w+10,oy+14),(ox+w+4,oy+16),(ox+w+2,oy+22),(ox+w,oy+16),(ox+w-6,oy+14),(ox+w,oy+12)])
    return s
STATUE_IMG = _ready(_make_statue())

_CANDY_ART = {}
def candy_tile():   # pink / mint cotton-candy ground
    if "tile" not in _CANDY_ART:
        T6 = TILE*6; rr = random.Random(12)
        g = pygame.Surface((T6, T6), 0, 32); g.fill((255,200,225))
        for k in range(5):   # soft mint and light-pink frosting patches (solid colors, no gray mixing)
            w, h = rr.randint(70,110), rr.randint(40,60); x, y = rr.randint(0,T6-w), rr.randint(0,T6-h)
            pygame.draw.ellipse(g, ((185,240,215) if k % 2 == 0 else (255,220,236)), (x, y, w, h))
        for _ in range(12):   # sprinkles on the ground
            x, y = rr.randint(4,T6-8), rr.randint(4,T6-8); c = rr.choice(SPRINKLE_COLS[:-1])
            d = rr.choice((-1, 1)); pygame.draw.line(g, c, (x, y), (x+3*d, y+5), 3)
        _CANDY_ART["tile"] = g
    return _CANDY_ART["tile"]
def choc_pond():    # the pond turns into a chocolate pond
    if "pond" not in _CANDY_ART:
        s = POND_IMG.copy(); W, H = s.get_size()
        pygame.draw.ellipse(s, (255,215,230), (14,14,W-28,H-28), 14)                  # pink sugar bank
        choc = _vgrad(W-72, H-72, (165,100,60), (105,60,35)); m = pygame.Surface(choc.get_size(), pygame.SRCALPHA)
        pygame.draw.ellipse(m, (255,255,255,255), (0,0)+choc.get_size())
        ca = pygame.Surface(choc.get_size(), pygame.SRCALPHA); ca.blit(choc, (0,0)); ca.blit(m, (0,0), special_flags=pygame.BLEND_RGBA_MIN)
        s.blit(ca, (36,36))
        for rx, ry, rw in ((W//2-80, H//2-30, 90), (W//2+40, H//2+30, 70), (W//2-20, H//2+60, 50)):
            pygame.draw.ellipse(s, (205,150,105), (rx, ry, rw, 10), 2)                 # chocolate swirls
        pygame.draw.ellipse(s, (225,180,140), (W//2-120, 70, 80, 14))
        _CANDY_ART["pond"] = _ready(s)
    return _CANDY_ART["pond"]
def ginger_house(i):   # gingerbread cottage: the new storybook house + white icing and gumdrops
    key = ("house", i)
    if key not in _CANDY_ART:
        s = house_image((205,140,80)).copy()
        for x in range(4, 117, 6):   # icing dripping along the curved roof
            y = int(_roof_y(x)) + 2
            pygame.draw.circle(s, (255,250,252), (x, y), 4)
            if x % 12 == 4: pygame.draw.circle(s, (255,250,252), (x, y + 5), 2)
        for k in range(8, 114, 8): pygame.draw.circle(s, (255,250,252), (k, 55), 3)       # icing under the eave
        gum = [(255,90,150), (90,200,255), (255,220,60), (120,220,120)]
        for j, (x, y) in enumerate(((60,16),(40,28),(80,28),(24,42),(96,42))):
            pygame.draw.circle(s, gum[(j + i) % 4], (x, y), 5); pygame.draw.circle(s, WHITE, (x-2, y-2), 1)
        _CANDY_ART[key] = _ready(s)
    return _CANDY_ART[key]
def candy_village_tree(i):   # lollipop trees in the candy village (same size = same blocking)
    key = ("vtree", i)
    if key not in _CANDY_ART:
        s = pygame.Surface((80,110), pygame.SRCALPHA)
        pygame.draw.rect(s, (250,245,240), (36,58,8,51), border_radius=3)
        _swirl_pop(s, 40, 36, 32, ((255,110,175), (120,215,190), (190,140,255))[i], (255,240,248))
        _shade(s, 180)
        pygame.draw.ellipse(s, WHITE, (20,14,14,8))
        _CANDY_ART[key] = _ready(_outline(s))
    return _CANDY_ART[key]
def draw_candy_village(cx, cy):   # candy-cane posts around Fox Village
    if "post" not in _CANDY_ART:
        p = pygame.Surface((28,64), pygame.SRCALPHA)
        pts = [(10,62),(10,16)] + [(16 + 6*math.cos(a), 16 - 6*math.sin(a)) for a in [k*math.pi/6 for k in range(7)]]
        pygame.draw.lines(p, WHITE, False, pts, 7)
        for y in range(56, 18, -9): pygame.draw.line(p, (235,45,60), (7,y+2), (13,y-2), 3)
        pygame.draw.circle(p, (235,45,60), (16,10), 3)
        _CANDY_ART["post"] = _ready(_outline(p))
    p = _CANDY_ART["post"]; V = VILLAGE_RECT
    for x in range(V.left + 20, V.right - 10, 150):
        for y in (V.top - 40, V.bottom - 30):
            if -40 < x - cx < WIDTH + 40 and -80 < y - cy < HEIGHT + 20: screen.blit(p, (x - cx, y - cy))
RAIN_TINT = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); RAIN_TINT.fill((50,80,150,45))

def _make_menu():
    bg = _vgrad(WIDTH, HEIGHT, (110,160,255), (255,200,215)); rr = random.Random(2)   # soft anime sky
    for k in range(6):   # warm sun glow
        g = pygame.Surface((240,240), pygame.SRCALPHA); pygame.draw.circle(g, (255,245,200,30), (120,120), 120 - k*14); bg.blit(g, (860,0))
    pygame.draw.circle(bg, (255,252,225), (980,120), 46); pygame.draw.circle(bg, (255,235,170), (980,120), 46, 4)
    for (x, y, sc) in ((120,90,1.2), (420,150,0.9), (700,70,1.0), (1050,250,0.8), (250,300,0.7), (860,330,0.75)):   # fluffy cel clouds
        cl = pygame.Surface((int(260*sc), int(110*sc)), pygame.SRCALPHA); W_, H_ = cl.get_size()
        for (px, py, pr) in ((0.22,0.62,0.22), (0.42,0.42,0.30), (0.64,0.48,0.25), (0.82,0.66,0.17), (0.5,0.7,0.24)):
            pygame.draw.circle(cl, (205,200,240), (int(px*W_), int(py*H_)+4), int(pr*W_*0.5))   # lavender underside
        for (px, py, pr) in ((0.22,0.6,0.2), (0.42,0.4,0.28), (0.64,0.46,0.23), (0.82,0.64,0.15), (0.5,0.62,0.2)):
            pygame.draw.circle(cl, (255,255,255), (int(px*W_), int(py*H_)), int(pr*W_*0.5))      # white lit top
        bg.blit(cl, (x, y))
    for k, (col, base) in enumerate((((120,200,130), 520), ((80,175,105), 580), ((55,150,90), 640))):
        pts = [(0,HEIGHT)] + [(x, base + int(30*math.sin(x/140 + k*2))) for x in range(0, WIDTH+20, 20)] + [(WIDTH,HEIGHT)]
        pygame.draw.polygon(bg, col, pts)
    for _ in range(14):   # little trees on the hills
        x = rr.randint(0, WIDTH); y = 560 + rr.randint(0, 60)
        r_ = rr.randint(14,22); pygame.draw.circle(bg, (40,120,75), (x, y), r_)
        pygame.draw.circle(bg, (85,170,105), (x-r_//4, y-r_//4), r_*2//3)                   # cel-lit treetop
    shade = pygame.Surface((760, 420), pygame.SRCALPHA); pygame.draw.rect(shade, (90,55,140,95), (0,0,760,420), border_radius=30)
    bg.blit(shade, (WIDTH//2-380, 180))
    return bg
MENU_BG = _make_menu()
MENU_FOX = pygame.transform.smoothscale(make_fox(), (168,126))
MENU_FOX2 = pygame.transform.flip(pygame.transform.smoothscale(make_fox((215,215,225), (140,140,155)), (168,126)), True, False)

# ================= FIRES ARE SOLID (no walking into flames) =================
CAVE_FIRE_BLOCK = pygame.Rect(CAVE_ROOM.right-330-32, CAVE_ROOM.y+370-16, 64, 46)     # cave campfire
HOUSE_FIRE_BLOCK = pygame.Rect(ROOM.right-240, ROOM.y+170, 120, 45)                   # house fireplace
def room_step(r, dx, dy, walls):
    """move a fox inside a room one axis at a time; walls (fires) stop it"""
    r.x += dx
    if r.collidelist(walls) != -1: r.x -= dx
    r.y += dy
    if r.collidelist(walls) != -1: r.y -= dy

# ================= GLOWING DAGGER =================
_DAGGER = []
def draw_dagger(surf, x, y):
    if not _DAGGER:
        d = pygame.Surface((18,40), pygame.SRCALPHA)
        pygame.draw.polygon(d, (80,255,120), [(9,0),(14,8),(13,24),(5,24),(4,8)])          # bright GREEN blade
        pygame.draw.line(d, (200,255,210), (8,3), (8,22), 2)
        pygame.draw.rect(d, GOLD, (1,24,16,4), border_radius=2)                              # guard
        pygame.draw.rect(d, (120,70,160), (7,28,5,9), border_radius=2)                        # handle
        pygame.draw.circle(d, (255,120,200), (9,38), 2)
        _DAGGER.append(_outline(d))
        g = pygame.Surface((60,60), pygame.SRCALPHA)
        for k in range(10): pygame.draw.circle(g, (80,255,120,16), (30,30), 30-k*3)   # green glow halo
        _DAGGER.append(g)
    a = 140 + int(110*math.sin(pygame.time.get_ticks()/250))      # soft pulsing light
    g = _DAGGER[1]; g.set_alpha(a); surf.blit(g, (x-30, y-30))
    surf.blit(_DAGGER[0], (x-9, y-20))

# ================= THE OLD FOX WIZARD (in the Secret Cave) =================
WIZ_POS = (CAVE_ROOM.x+180, CAVE_ROOM.y+360)          # left side: away from the exit, pool and fire
WIZ_GIFT = ("Congratulations on finding my secret cave. I haven't spoken to anyone in many ages. "
            "It's good to see you. Have this dagger for your protection.")
WIZ_AGAIN = "Keep that dagger shining!"
wizard_talk = 0; wizard_line = ""
_WIZ = []
def _make_wizard(blink):
    s = pygame.Surface((90,120), pygame.SRCALPHA)
    ROBE, ROBE2 = (90,80,200), (130,120,235)
    pygame.draw.polygon(s, ROBE, [(45,40),(72,116),(18,116)])                                 # robe
    pygame.draw.polygon(s, ROBE2, [(45,40),(52,116),(30,116)])
    pygame.draw.circle(s, (200,195,205), (45,38), 15)                                         # old gray fox head
    pygame.draw.polygon(s, (200,195,205), [(32,32),(30,18),(40,28)]); pygame.draw.polygon(s, (200,195,205), [(58,32),(60,18),(50,28)])
    pygame.draw.polygon(s, WHITE, [(33,44),(57,44),(45,80)])                                  # long white beard
    pygame.draw.polygon(s, (80,70,190), [(22,30),(68,30),(50,0),(46,0)])                     # pointy hat
    pygame.draw.ellipse(s, (70,60,170), (16,24,58,12))                                        # hat brim
    pygame.draw.rect(s, (130,80,40), (76,30,5,86), border_radius=2)                           # staff
    pygame.draw.circle(s, (225,230,240), (78,80), 6); pygame.draw.circle(s, (225,230,240), (24,80), 6)   # paws
    _shade(s, 190)
    s = _outline(s)
    for sx, sy in ((40,14),(52,22),(33,26)):                                                  # stars on the hat
        pygame.draw.polygon(s, GOLD, [(sx,sy-4),(sx+1,sy-1),(sx+4,sy),(sx+1,sy+1),(sx,sy+4),(sx-1,sy+1),(sx-4,sy),(sx-1,sy-1)])
    for sx, sy in ((34,96),(52,104),(44,84)):
        pygame.draw.circle(s, GOLD, (sx,sy), 2)
    if blink:
        pygame.draw.line(s, (60,100,160), (36,38), (42,38), 2); pygame.draw.line(s, (60,100,160), (48,38), (54,38), 2)
    else:
        _shine_eye(s, 39, 37, 3, 4, (80,140,220)); _shine_eye(s, 51, 37, 3, 4, (80,140,220))
    pygame.draw.circle(s, (40,25,35), (45,44), 2)                                              # nose
    return s
def wrap_text(fnt, text, width):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if fnt.size(t)[0] <= width: cur = t
        else: lines.append(cur); cur = w
    if cur: lines.append(cur)
    return lines
def speech_bubble(surf, lines, midbottom):
    imgs = [tinyfont.render(l, True, (60,35,15)) for l in lines]
    w = max(i.get_width() for i in imgs) + 24; h = sum(i.get_height() for i in imgs) + 16
    b = pygame.Rect(0, 0, w, h); b.midbottom = midbottom
    b.clamp_ip(pygame.Rect(10, 10, WIDTH-20, HEIGHT-20))
    anime_bubble(surf, b, midbottom[0], (110,60,40))
    y = b.y + 8
    for i in imgs: surf.blit(i, (b.x+12, y)); y += i.get_height()
def wizard_here():   # Dorfghan only lives in the Secret Cave on the golden finale level (11)
    return level == 11
def wizard_near():
    if not wizard_here(): return False
    foxes = [cave_fox] + ([cave_fox2] if two_player else [])
    return any(math.hypot(r.centerx-WIZ_POS[0], r.centery-WIZ_POS[1]) < 140 for r in foxes)
def talk_wizard():
    global wizard_talk, wizard_line
    if not wizard_near(): return
    if fox.inventory.get("dagger", 0) < 1:
        fox.inventory["dagger"] = 1                               # once per run (every new game / level / retry starts without it)
        wizard_line = WIZ_GIFT + (" Use it to beat Smog the Dragon!" if THEME[0] == "dungeon" else ""); wizard_talk = 420                     # 7 seconds to read
    else:
        wizard_line = WIZ_AGAIN; wizard_talk = 240
wiz_was_near = False
def draw_wizard():
    global wizard_talk, wiz_was_near
    if not wizard_here():   # levels 1-10: the cave is empty of wizards
        wiz_was_near = False; wizard_talk = 0; return
    near = wizard_near()
    if near and not wiz_was_near and state == "cave" and fox.inventory.get("dagger", 0) < 1:
        talk_wizard()   # walk up to Dorfghan: he hands over the dagger by himself (no T needed)
    wiz_was_near = near
    if not _WIZ: _WIZ.extend([_make_wizard(False), _make_wizard(True)])
    t = pygame.time.get_ticks()
    bob = int(3*math.sin(t/400))
    img = toon_wizard_img(t)                    # blinks now and then
    x, y = WIZ_POS[0]-45, WIZ_POS[1]-60+bob
    g = pygame.Surface((50,50), pygame.SRCALPHA)                       # glowing staff tip
    for k in range(8): pygame.draw.circle(g, (150,220,255,18+int(10*math.sin(t/200))), (25,25), 25-k*3)
    screen.blit(g, (x+78-25, y+30-25))
    toon_breath_blit(img, x, y, _WIZ)
    pygame.draw.circle(screen, (200,240,255), (x+78, y+28), 6); pygame.draw.circle(screen, WHITE, (x+77, y+26), 2)
    n = otext(tinyfont, "Dorfghan", (200,190,255)); screen.blit(n, (WIZ_POS[0]-n.get_width()//2, y-24))
    if wizard_talk > 0:
        if not wizard_near() and wizard_talk < 400: wizard_talk = 0   # she walked away
        else:
            speech_bubble(screen, ["Dorfghan:"] + wrap_text(tinyfont, wizard_line, 420), (WIZ_POS[0]+40, y-28))
            if state == "cave": wizard_talk -= 1
    elif wizard_near():
        h = otext(tinyfont, "Press T to talk to Dorfghan", YELLOW)
        screen.blit(h, (cave_fox.centerx-h.get_width()//2, cave_fox.bottom+6))

# ================= FOXES WHO LIVE IN THE HOUSES =================
HOUSE_RESIDENTS = [   # one list per house: (name, fur, darker fur, what they say, sits still?)
    [("Bramble", (170,110,230), (120,70,180), "Grandpa and I are building a treehouse with a rope swing!", True),
     ("Fern",    (120,200,120), (70,150,80),  "My favorite song is the Moonlight Wiggle. La la la!", False)],
    [("Clover",  (255,150,190), (210,100,150),"I'm knitting a rainbow scarf. It's sooo long now!", False)],
    [("Pepper",  (90,80,85),    (55,45,50),   "I planted sunflowers. One is taller than me already!", False),
     ("Sage",    (150,190,170), (100,140,120),"I write little poems about clouds. That one looks like a bunny!", True)],
    [("Willow",  (120,180,255), (70,120,210), "I'm practicing cartwheels. I can do three in a row!", False)],
    [("Nutmeg",  (190,120,70),  (140,80,40),  "I'm building a tiny castle out of pinecones!", True),
     ("Poppy",   (255,110,90),  (200,70,60),  "A butterfly landed on my nose! I named her Twinkle.", False)],
    [("Biscuit", (240,210,150), (190,160,100),"I'm teaching my little brother to whistle. Fweeet!", False)],
    [("Juniper", (100,150,200), (60,100,150), "I love flying my kite on windy days. It looks like a dragon!", False)],
    [("Cinnamon",(210,90,40),   (160,60,20),  "Knock knock! Who's there? Owl. Owl who? Owl be your friend!", True),
     ("Banana",   (250,240,120), (200,180,60), "I love yellow! Yellow socks, yellow hat, yellow everything!", False)],
]
SIT_SPOTS = [(ROOM.right-310, ROOM.y+215), (ROOM.right-300, ROOM.y+350)]   # by the fire, by the table
house_folks = []
class HouseFox(VillageFox):
    def __init__(self, name, fur, dark, line, sits, k):
        self.sits, self.k = sits, k
        super().__init__(name, fur, dark, line)
        if sits: self.rect.center = SIT_SPOTS[k % 2]; self.x, self.y = map(float, self.rect.center)
    def pick_spot(self):
        if getattr(self, "sits", False): return SIT_SPOTS[self.k % 2]
        while True:
            p = (random.randint(ROOM.x+70, ROOM.right-70), random.randint(ROOM.y+240, ROOM.bottom-115))
            if not HOUSE_FIRE_BLOCK.inflate(90,90).collidepoint(p) and not INSIDE_DOOR.inflate(200,200).collidepoint(p):
                return p
    def update(self):
        if self.sits:   # sitting by the fire or table: just chats
            if self.talk_frames > 0: self.talk_frames -= 1
            self.image = self.base; return
        super().update()
def enter_house_folks(h):
    house_folks.clear()
    i = houses.index(h) if h in houses else 0
    for k, info in enumerate(HOUSE_RESIDENTS[i % len(HOUSE_RESIDENTS)]):
        house_folks.append(HouseFox(*info, k))

# ================= FROG POND (between the start and Fox Village) =================
POND_RECT = pygame.Rect(0, 0, 420, 260); POND_RECT.center = (int(6200*WS), int(4300*WS))
def _pond_blocks():
    cx, cy, a, b = POND_RECT.centerx, POND_RECT.centery, POND_RECT.w//2 - 14, POND_RECT.h//2 - 14
    blocks, n = [], 7
    for k in range(n):   # stacked strips that follow the round edge of the water
        y0 = cy - b + k*2*b//n; ym = y0 + b//n - cy
        half = int(a * math.sqrt(max(0.0, 1 - (ym/b)**2)))
        blocks.append(pygame.Rect(cx-half, y0, 2*half, 2*b//n + 1))
    return blocks
POND_BLOCKS = _pond_blocks()
SWIM_SPEED = 0.6   # swimming is a bit slower than walking
def in_pond(r):   # is the fox's middle in the water (same oval as the pond's edge)?
    a, b = POND_RECT.w//2 - 14, POND_RECT.h//2 - 14
    ux, uy = (r.centerx - POND_RECT.centerx) / a, (r.centery - POND_RECT.centery) / b
    return ux*ux + uy*uy < 1.0
def splash_puff(x, y):   # a little ring of water droplets
    for k in range(8):
        a = k * math.pi / 4
        dust.append([x + int(22*math.cos(a)), y + int(10*math.sin(a)), 22, (200,235,255)])
FX = []                     # looks-only particles: [kind, x, y, vx, vy, life, max, col]
_FXR = random.Random()      # its own dice, so the game's random stays the same
def spawn_sparkles(pos, typ=""):
    col = (255,225,90) if typ == "golden_berry" else (255,160,205) if ("berry" in typ or typ.startswith("rb")) else (170,235,255)
    for k in range(10):
        a = k*0.628 + _FXR.random()*0.4; v = 2 + _FXR.random()*2.5
        FX.append(["spark", pos[0], pos[1], math.cos(a)*v, math.sin(a)*v - 1.2, 26, 26, col])
def fx_hit(pf):
    FX.append(["impact", pf.rect.centerx, pf.rect.centery, 0, 0, 16, 16, (255,240,110)])
def draw_fx(cx, cy):
    for p in FX[:]:
        p[1] += p[3]; p[2] += p[4]; p[5] -= 1
        if p[0] == "spark": p[4] += 0.12
        if p[5] <= 0: FX.remove(p); continue
        k = p[5]/p[6]; x, y = int(p[1]-cx), int(p[2]-cy)
        if p[0] == "spark": _glint4(screen, x, y, int(2 + 5*k), p[7] if k < 0.6 else WHITE)
        else:   # anime impact burst: spiky star + speed rays
            r = 16 + 26*(1-k); pts = []
            for j in range(16):
                a = j*math.pi/8 + 0.2; rr_ = r if j % 2 == 0 else r*0.45; pts.append((x + math.cos(a)*rr_, y + math.sin(a)*rr_))
            pygame.draw.polygon(screen, (255,150,40), pts); pygame.draw.polygon(screen, p[7], [((px_-x)*0.7+x, (py_-y)*0.7+y) for px_, py_ in pts])
            for j in range(8):
                a = j*math.pi/4; _taper(screen, WHITE, (x + math.cos(a)*(r+4), y + math.sin(a)*(r+4)), (x + math.cos(a)*(r+16), y + math.sin(a)*(r+16)), 3)
_SWEAT = []
def _sweat_img():
    if not _SWEAT:
        d = pygame.Surface((12,16), pygame.SRCALPHA)
        pygame.draw.circle(d, (60,120,200), (6,10), 5); pygame.draw.polygon(d, (60,120,200), [(6,0),(1,9),(11,9)])
        pygame.draw.circle(d, (150,210,255), (6,10), 4); pygame.draw.polygon(d, (150,210,255), [(6,2),(2,9),(10,9)])
        pygame.draw.ellipse(d, WHITE, (4,8,3,4)); _SWEAT.append(d)
    return _SWEAT[0]
def draw_fox_world(pf, cx, cy):   # a fox in the world; in the pond only her head and back show above the water
    img = pf.image; x, y = pf.rect.x - cx, pf.rect.y - cy
    if not getattr(pf, "swimming", False):
        w, h = img.get_size(); ht = getattr(pf, "happy_t", 0)
        if getattr(pf, "fast_art", False):   # speed lines + stretch when dashing / boosted
            d = pf.direction; tk = pygame.time.get_ticks()
            toon_dash_puffs(pf, cx, cy)   # cartoon dust clouds behind her
            img = pygame.transform.smoothscale(img, (int(w*1.12), int(h*0.9)))
        elif ht > 24:   # happy squash and stretch hop on pickup
            q = (ht - 24)/12.0; img = pygame.transform.smoothscale(img, (int(w*(1 + 0.14*q)), int(h*(1 - 0.14*q))))
        elif ht > 12:
            q = (ht - 12)/12.0; img = pygame.transform.smoothscale(img, (int(w*(1 - 0.08*q)), int(h*(1 + 0.12*q))))
        if not getattr(pf, "fast_art", False) and ht <= 12: img, _ = fox_breath_img(pf, img)   # soft breathing while standing
        fb, fa = space_float(pf)   # level 8: weightless bob + tilt
        if fa: img = pygame.transform.rotate(img, fa); y += fb
        nw, nh = img.get_size()
        blit_fox(screen, img, (x + (w - nw)//2, y + h - nh), getattr(pf, "face_left", False), 1 if pf is fox else 2, vel=clay_vel(pf))   # tail swish (follow-through)
        if pf.invuln > 50:   # anime sweat drop after a hit
            sx = pf.rect.x - cx + (6 if getattr(pf, "face_left", False) else w - 12); sy = pf.rect.y - cy - 8 + (120 - pf.invuln)//6
            toon_ouch_stars(sx + 6, sy + 4, pf.invuln)   # cartoon stars circling her head
        return
    t = pygame.time.get_ticks(); w, h = img.get_size()
    y += int(2*math.sin(t/260))                                        # gentle bob
    cut = int(h*0.55)                                                  # the water line
    low = img.subsurface((0, cut, w, h - cut)).copy(); low.set_alpha(55)
    screen.blit(low, (x, y + cut))                                     # faint body under the water
    screen.blit(img, (x, y), (0, 0, w, cut))                           # head and back above the water
    wl = y + cut; mx = x + w//2
    for k in range(2):                                                 # ripple rings spreading out
        ph = ((t/1100.0) + k*0.5) % 1.0; rw = int(w*0.8 + 50*ph); rh = int(12 + 10*ph)
        ring = pygame.Surface((rw, rh), pygame.SRCALPHA); pygame.draw.ellipse(ring, (235,248,255, int(200*(1-ph))), ring.get_rect(), 2)
        screen.blit(ring, (mx - rw//2, wl - rh//2))
    band = pygame.Surface((w + 6, 8), pygame.SRCALPHA); pygame.draw.ellipse(band, (210,240,255,190), band.get_rect())
    screen.blit(band, (x - 3, wl - 4))                                 # bright water line around her
def _make_pond():
    W, H = POND_RECT.w + 80, POND_RECT.h + 80; s = pygame.Surface((W, H), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (205,190,140), (14,14,W-28,H-28))                                  # sandy bank
    pygame.draw.ellipse(s, (35,100,170), (34,34,W-68,H-68))
    water = _vgrad(W-72, H-72, (90,190,255), (30,110,210)); m = pygame.Surface(water.get_size(), pygame.SRCALPHA)
    pygame.draw.ellipse(m, (255,255,255,255), (0,0)+water.get_size())
    wa = pygame.Surface(water.get_size(), pygame.SRCALPHA); wa.blit(water, (0,0)); wa.blit(m, (0,0), special_flags=pygame.BLEND_RGBA_MIN)
    s.blit(wa, (36,36))
    band = pygame.Surface(water.get_size(), pygame.SRCALPHA)                                  # anime cel band: the bank's shadow on the water
    pygame.draw.ellipse(band, (20,80,170,90), (0, 0) + water.get_size()); pygame.draw.ellipse(band, (0,0,0,0), (10, 22, water.get_width()-20, water.get_height()-16))
    s.blit(band, (36,36))
    for rx, ry, rw in ((W//2-80, H//2-30, 90), (W//2+40, H//2+30, 70), (W//2-20, H//2+60, 50)):
        pygame.draw.ellipse(s, (200,235,255), (rx, ry, rw, 10), 2)                           # ripples
    pygame.draw.ellipse(s, WHITE, (W//2-120, 70, 80, 14))
    pygame.draw.ellipse(s, WHITE, (W//2-30, 78, 26, 7))
    for gx, gy, gr in ((W//2+90, H//2-50, 6), (W//2-150, H//2+40, 5), (W//2+20, H//2+20, 4)):   # twinkles on the water
        pygame.draw.line(s, WHITE, (gx-gr, gy), (gx+gr, gy), 2); pygame.draw.line(s, WHITE, (gx, gy-gr), (gx, gy+gr), 2)
    for x, y in ((60,70),(W-80,80),(70,H-90),(W-70,H-100),(W//2,30),(W//2+60,H-40)):         # reeds and cattails
        for d in (-6, 0, 6):
            pygame.draw.line(s, (60,140,60), (x+d, y+20), (x+d*2, y-12), 3)
        pygame.draw.ellipse(s, (130,80,40), (x-3, y-14, 6, 14))
    return s
POND_IMG = _make_pond()
pygame.draw.arc(POND_IMG, (230,248,255), (40, 40, POND_IMG.get_width()-80, POND_IMG.get_height()-80), 0.5, 2.6, 3)   # anime rim light on the water
POND_GLINTS = [(0.30,0.35),(0.62,0.30),(0.75,0.55),(0.40,0.66),(0.55,0.48),(0.22,0.55),(0.66,0.72)]
LILY_PADS = [(POND_RECT.x+120, POND_RECT.y+80), (POND_RECT.right-130, POND_RECT.y+95),
             (POND_RECT.x+150, POND_RECT.bottom-75), (POND_RECT.right-150, POND_RECT.bottom-80), (POND_RECT.centerx, POND_RECT.centery)]
_LILY = []
def lily_img(flower):
    if not _LILY:
        for f in (False, True):
            l = pygame.Surface((70,46), pygame.SRCALPHA)
            pygame.draw.ellipse(l, (90,190,90), (2,4,66,38)); pygame.draw.polygon(l, (0,0,0,0), [(35,23),(68,10),(68,30)])
            pygame.draw.ellipse(l, (140,220,120), (14,10,24,10))
            l = _outline(l)
            if f:
                for a in range(6): pygame.draw.circle(l, (255,160,200), (22+int(6*math.cos(a)), 24+int(6*math.sin(a))), 4)
                pygame.draw.circle(l, (255,230,120), (22,24), 3)
            _LILY.append(l)
    return _LILY[1 if flower else 0]
_FROG = {}
def frog_img(col, blink):
    key = (col, blink)
    if key not in _FROG:
        s = pygame.Surface((44,36), pygame.SRCALPHA)
        pygame.draw.ellipse(s, col, (4,12,36,22))                                                 # body
        pygame.draw.ellipse(s, _light(col, 60), (12,20,20,12))                                    # tummy
        for ex in (13, 31): pygame.draw.circle(s, col, (ex, 12), 8)                             # eye bumps
        pygame.draw.ellipse(s, _dark(col, 30), (0,26,14,8)); pygame.draw.ellipse(s, _dark(col, 30), (30,26,14,8))   # feet
        _shade(s, 185); s = _outline(s)
        for ex in (13, 31):
            if blink: pygame.draw.line(s, (40,100,45), (ex-5,12), (ex+5,12), 2)
            else: _shine_eye(s, ex, 12, 4, 5, (60,40,30))
        pygame.draw.arc(s, (40,100,45), (16,18,12,8), math.pi+0.3, 2*math.pi-0.3, 2)                # smile
        bl = pygame.Surface((7,4), pygame.SRCALPHA); pygame.draw.ellipse(bl, (255,120,150,150), (0,0,7,4))
        s.blit(bl, (6,19)); s.blit(bl, (31,19))
        _FROG[key] = s
    return _FROG[key]
class Frog:
    def __init__(self, name, col, pos, lines):
        self.name, self.col, self.lines, self.i = name, col, lines, 0
        self.rect = pygame.Rect(0, 0, 44, 36); self.rect.center = pos
        self.talk_frames = 0; self.seed = sum(map(ord, name))
    @property
    def line(self): return self.lines[self.i % len(self.lines)]
    def update(self):
        if self.talk_frames > 0:
            self.talk_frames -= 1
            if self.talk_frames == 0: self.i += 1    # next time: the next tip
    def draw(self, surf, cx, cy):
        if not self.rect.move(-cx, -cy).inflate(300, 200).colliderect(surf.get_rect()): return   # off screen
        t = pygame.time.get_ticks() + self.seed*97
        ph = t % 2600
        hop = -int(10*math.sin(ph/300*math.pi)) if ph < 300 else 0            # little idle hop
        if self.talk_frames > 0: hop = -int(6*abs(math.sin(self.talk_frames/8)))
        blink = (t % 3700) < 130
        fq = (1.12, 0.88) if (ph < 45 or 255 < ph < 300) else (0.94, 1.07) if ph < 300 else (1.0, 1.0)   # squash to jump, stretch in the air, squash to land
        clay_blit(surf, frog_img(self.col, blink, toon_throat(t) if ph >= 300 else 0), self.rect.x-cx, self.rect.y-cy+hop, fq[0], fq[1])
        n = otext(tinyfont, self.name, WHITE, (30,90,40))
        surf.blit(n, (self.rect.centerx-cx-n.get_width()//2, self.rect.y-cy-22+hop))
        if self.talk_frames > 0:
            speech_bubble(surf, [self.line], (self.rect.centerx-cx, self.rect.y-cy-26))
frogs = [
    Frog("Lily",    (110,200,90),  (LILY_PADS[0][0], LILY_PADS[0][1]-4), ["Fox Village is up in the top-right corner. Follow the map!", "Press P to pause."]),
    Frog("Ribbit",  (80,170,120),  (POND_RECT.right+4, POND_RECT.centery+10), ["Berries come in four kinds: blue, black, rasp and straw. Ribbit!"]),
    Frog("Bubbles", (150,210,80),  (LILY_PADS[2][0], LILY_PADS[2][1]-4), ["Make an axe: press C, then 1. Throw it with A or X!", "Berry bombs knock out trolls: C then 2, throw with B."]),
    Frog("Moss",    (90,150,70),   (POND_RECT.x-6, POND_RECT.centery-20), ["The gray dot on the map is the Secret Cave!"]),
]
def draw_pond(cx, cy):
    r = POND_RECT.move(-cx, -cy)
    if r.inflate(200,200).colliderect(screen.get_rect()):
        screen.blit(choc_pond() if CANDY[0] else POND_IMG, (r.x-40, r.y-40))
        if not CANDY[0]:
            tk = pygame.time.get_ticks()
            for k, (gx, gy) in enumerate(POND_GLINTS):   # sparkle glints dancing on the water
                tw = (math.sin(tk/240 + k*1.9) + 1) / 2
                if tw > 0.45: _glint4(screen, r.x + int(gx*r.w), r.y + int(gy*r.h), int(2 + 6*tw))
        for k, (lx, ly) in enumerate(LILY_PADS):
            bob = int(2*math.sin(pygame.time.get_ticks()/500 + k))
            screen.blit(lily_img(k in (1, 4)), (lx-35-cx, ly-23-cy+bob))
        t = otext(tinyfont, "Chocolate Pond" if CANDY[0] else "Frog Pond", WHITE, (110,60,40) if CANDY[0] else (30,90,140)); screen.blit(t, (r.centerx-t.get_width()//2, r.y-58))

# ================= SNOW BLOWING OFF THE MOUNTAINS (looks only) =================
SNOW_LIMIT = WORLD_H // 8          # the top eighth of the map
_snow_rng = random.Random()
snowflakes = []                    # [x, y, vx, vy, size]
snow_wisps = []                    # [x, y, life]
_WISP = pygame.Surface((90,18), pygame.SRCALPHA)
for _k in range(6): pygame.draw.ellipse(_WISP, (255,255,255,22), (_k*6, _k*2, 90-_k*12, 18-_k*3))
def update_draw_snow(cx, cy, moving):
    if cy > SNOW_LIMIT:
        snowflakes.clear(); snow_wisps.clear(); return
    t = pygame.time.get_ticks()
    sway = 1.2*math.sin(t/700) + 0.6*math.sin(t/230)               # shared gusty sway
    if moving:
        for _ in range(4):             # new flakes come off the snowy ridge
            if len(snowflakes) < 220:
                x = _snow_rng.uniform(cx-200, cx+WIDTH+100)
                snowflakes.append([x, 200+80*math.sin(x*0.02) - _snow_rng.uniform(110,190),
                                   _snow_rng.uniform(1.2,3.0), _snow_rng.uniform(1.4,3.2), _snow_rng.choice((1,2,2,3))])
        if _snow_rng.random() < 0.02:  # a gust blows a wisp of snow off a peak
            px = (int(_snow_rng.uniform(cx, cx+WIDTH))//80)*80 + 120
            snow_wisps.append([px, 200+80*math.sin((px-120)*0.02) - 190, 60])
        for f in snowflakes:
            f[0] += f[2] + sway; f[1] += f[3]
        for f in snowflakes[:]:
            if f[1] > SNOW_LIMIT or _snow_rng.random() < 0.06*(f[1]/SNOW_LIMIT)**3:   # thins out going south
                snowflakes.remove(f)
        for w in snow_wisps[:]:
            w[0] += 6 + sway; w[1] += 3; w[2] -= 1
            if w[2] <= 0: snow_wisps.remove(w)
    for w in snow_wisps:
        _WISP.set_alpha(int(255*w[2]/60))
        for k in range(3): screen.blit(_WISP, (w[0]-cx-k*30, w[1]-cy+k*9))
    for x, y, vx, vy, sz in snowflakes:
        sx, sy = int(x-cx), int(y-cy)
        if -5 < sx < WIDTH+5 and -5 < sy < HEIGHT+5:
            pygame.draw.circle(screen, (150,175,215), (sx, sy), sz+1)   # soft blue edge so it shows on grass
            pygame.draw.circle(screen, WHITE, (sx, sy), sz)
            if sz > 1: pygame.draw.line(screen, (230,240,255), (sx, sy), (int(sx-vx*2-sway), int(sy-vy*2)), 1)

# ================= LEVELS: 10 levels + 1 special finale (always 3:00 each) =================
ROCK_BAND = SNOW_LIMIT          # the rocky mountain band at the top of the map (only stones out here)
LEVELS = [   # tuning only: trolls = how many, speed = troll speed, plus each level's special twist
    dict(name="Sunny Start",        trolls=12, speed=1.0),
    dict(name="Berry Hunt",         trolls=0,  speed=1.0, no_trolls=True, tree_berries=260, task=("ruby", 8), time=240),   # 4:00 on this level
    dict(name="Troll Trouble",      trolls=24, speed=1.0, task=("nohit", 0)),   # no-hit challenge: one troll hit = try Level 3 again
    dict(name="Rainy Day",          trolls=18, speed=1.0, rain=0.004, task=("hearts", 2)),   # Faroe Oct 31: finish with at least 2 hearts
    dict(name="Hungry Fox",         trolls=18, speed=1.0),
    dict(name="Snowy Mountains",    trolls=20, speed=1.0, mountain_start=True, theme="snow", task=("nohit", 0), task_msg="Task: Get to Fox Village without getting hit by any yetis!", hit_word="No yeti hits!", hit_msg="A yeti got you! Try Level {lv} again!"),   # Faroe Nov 1: snowy mountains + yetis
    dict(name="Speedy Trolls",      trolls=18, speed=1.3, task=("village", 2), no_storm=True),   # no lightning on level 7   # Faroe Nov 1: reach Fox Village with at least 2 hearts
    dict(name="Outer Space",        trolls=20, speed=1.0, extra_rocks=80, theme="space"),   # Faroe Nov 1: space level (moon rocks, aliens)
    dict(name="Sunny Desert",       trolls=20, speed=1.0, theme="desert"),   # Faroe Nov 1: desert + scorpions (was Night Run, no night now)
    dict(name="Candyland",          trolls=8,  speed=1.0, theme="candy"),   # Faroe Nov 1: Candyland moved here from 11 (no boss)
    dict(name="Dragon Dungeon",     trolls=8,  speed=1.0, finale=True, task=("boss", 2), theme="dungeon"),   # Faroe Nov 1: dungeon + dragon
]
level = 1
N_OBSTACLES, N_STONES, N_MOUNTAIN_STONES = 180, 88, 25
N_TREE_BERRIES, N_TREE_STICKS = 175, 87
LESS_ITEMS = 50   # Faroe Oct 31: 50 fewer berries, sticks and stones scattered on every level
NIGHT_TINT = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); NIGHT_TINT.fill((10,15,55,125))
midfont = pygame.font.Font(None, 80)
def level_title(n):
    L = LEVELS[n-1]
    return ("SPECIAL FINALE: " + L["name"]) if L.get("finale") else f"Level {n}: {L['name']}"
_PANELS = {}
def cartoon_panel(x, y, w, h, top=(125,90,195), bot=(85,60,150), a=215):
    """rounded cartoon panel with a soft gradient (instead of a dark see-through box)"""
    key = (w, h, top, bot, a)
    if key not in _PANELS:
        pn = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(pn, (255,255,255,255), (0,0,w,h), border_radius=28)
        pn.blit(_vgrad(w, h, top, bot), (0,0), special_flags=pygame.BLEND_RGB_MULT)
        pn.set_alpha(a)
        pygame.draw.rect(pn, _light(top, 70) + (255,), (0,0,w,h), 4, border_radius=28)
        _PANELS[key] = pn
    screen.blit(_PANELS[key], (x, y))
def draw_level_done():
    cartoon_panel(WIDTH//2-480, 170, 960, 330)
    t = otext(bigfont, f"LEVEL {level} DONE!", YELLOW, th=4); screen.blit(t, (WIDTH//2-t.get_width()//2, 200))
    n = otext(font, "Next: " + level_title(level+1), WHITE); screen.blit(n, (WIDTH//2-n.get_width()//2, 320))
    k = otext(font, "Press SPACE for the next level", (150,255,170)); screen.blit(k, (WIDTH//2-k.get_width()//2, 380))
def draw_victory():
    cartoon_panel(WIDTH//2-520, 170, 1040, 330, (230,120,190), (150,80,190))
    t = otext(midfont, "YOU BEAT ALL THE LEVELS!", GOLD, th=4); screen.blit(t, (WIDTH//2-t.get_width()//2, 205))
    n = otext(font, "Dragon Dungeon complete! You're a super fox!", WHITE); screen.blit(n, (WIDTH//2-n.get_width()//2, 310))
    k = otext(font, "Press R to play again from Level 1", (150,255,170)); screen.blit(k, (WIDTH//2-k.get_width()//2, 370))
festive_fw = []
def draw_festive():   # finale: fireworks in the sky and golden sparkles everywhere
    if len(festive_fw) < 3 and random.random() < 0.05: festive_fw.append(Firework(WIDTH//2, 300))
    for fw in festive_fw[:]:
        if not fw.update(): festive_fw.remove(fw)
        else: fw.draw(screen)
    t = pygame.time.get_ticks()
    for k in range(36):
        x = (k*331 + t//25) % WIDTH; y = 120 + (k*197 + (t//40)*(1 + k%3)) % (HEIGHT-120)
        if (t//200 + k) % 3:
            r = 2 + (k % 3)
            sc = SPRINKLE_COLS[k % len(SPRINKLE_COLS)] if CANDY[0] else GOLD   # candy-colored sparkles in Candyland
            pygame.draw.line(screen, sc, (x-r*2, y), (x+r*2, y), 2); pygame.draw.line(screen, sc, (x, y-r*2), (x, y+r*2), 2)
            pygame.draw.circle(screen, (255,250,200), (x, y), r-1)

# ================= TROLL LEGS (looks only) =================
def draw_troll_legs(t, cx, cy, k=1.0):
    ph = t.step * 0.28
    for side in (-1, 1):
        a = ph + (0 if side < 0 else math.pi)
        lift = max(0.0, 4*math.sin(a))*k if t.moving else 0
        sw = 3*math.cos(a)*k if t.moving else 0
        hx, hy = t.rect.centerx + side*9*k - cx, t.rect.y + 52*k - cy
        fx, fy = hx + sw, t.rect.y + 68*k - lift - cy
        if CANDY[0] and isinstance(t, Troll):   # peppermint legs with round mint feet
            st_, rim_ = mint_cols(t); candy_stick((hx, hy), (fx, fy), int(7*k), st_, rim_)
            pygame.draw.ellipse(screen, rim_, (fx-9*k, fy-4*k, 18*k, 10*k)); pygame.draw.ellipse(screen, WHITE, (fx-8*k, fy-3*k, 16*k, 8*k))
            pygame.draw.line(screen, st_, (fx-4*k, fy-2*k), (fx+2*k, fy+4*k), max(1, int(3*k)))
            continue
        tc = troll_cols(t) if isinstance(t, Troll) else getattr(t, "cols", ((70,70,70), (120,120,120), (150,150,150)))
        pygame.draw.line(screen, tc[0], (hx, hy), (fx, fy), int(9*k))      # old-style troll leg
        pygame.draw.line(screen, tc[1], (hx, hy), (fx, fy), int(6*k))
        pygame.draw.ellipse(screen, tc[0], (fx-9*k, fy-4*k, 18*k, 10*k))
        pygame.draw.ellipse(screen, tc[2], (fx-8*k, fy-3*k, 16*k, 8*k))   # little round foot

# ================= BERRY CAVE (up in the mountains) =================
BERRY_CAVE_RECT = pygame.Rect(0, 0, 240, 170); BERRY_CAVE_RECT.center = (WORLD_W*11//60, WORLD_H*3//40)
BERRY_CAVE_DOOR = pygame.Rect(BERRY_CAVE_RECT.centerx-50, BERRY_CAVE_RECT.bottom-30, 100, 34)
BERRY_KINDS = ["strawberry", "blueberry", "raspberry", "blackberry"]   # the 4 real berries
berry_cave_berries = []   # [x, y, kind] on the cave floor
_BERRY_IMG = {}
def berry_img(kind):
    if kind not in _BERRY_IMG and kind in REAL_BERRIES:   # Berry Cave berries: the same real-looking art (26 px like before)
        _BERRY_IMG[kind] = real_berry_small(kind, 26)
    if kind not in _BERRY_IMG:
        s = pygame.Surface((26,26), pygame.SRCALPHA)
        if kind == "purple":
            pygame.draw.circle(s, (205,20,205), (13,15), 10); pygame.draw.ellipse(s, (90,200,90), (10,1,10,6))
        elif kind == "strawberry":
            pygame.draw.polygon(s, (235,40,60), [(3,8),(23,8),(20,17),(13,25),(6,17)])
            pygame.draw.circle(s, (235,40,60), (8,10), 6); pygame.draw.circle(s, (235,40,60), (18,10), 6)
            pygame.draw.polygon(s, (60,170,60), [(6,6),(13,1),(20,6),(13,8)])
        elif kind == "blueberry":
            pygame.draw.circle(s, (70,90,220), (13,14), 10)
        elif kind == "raspberry":
            for bx, by in ((9,10),(17,10),(13,8),(8,16),(18,16),(13,14),(13,20)): pygame.draw.circle(s, (240,70,120), (bx,by), 4)
            pygame.draw.ellipse(s, (90,190,90), (9,1,9,5))
        else:
            for bx, by in ((9,10),(17,10),(13,8),(8,16),(18,16),(13,14),(13,20)): pygame.draw.circle(s, (70,30,90), (bx,by), 4)
            pygame.draw.ellipse(s, (90,190,90), (9,1,9,5))
        _shade(s, 175); s = _outline(s)
        if kind == "strawberry":
            for sx, sy in ((9,12),(15,11),(12,17),(17,16),(8,16)): pygame.draw.circle(s, (255,230,120), (sx,sy), 1)
        elif kind == "blueberry":
            pygame.draw.lines(s, (30,40,120), True, [(11,4),(15,4),(16,7),(13,9),(10,7)], 2)
        pygame.draw.circle(s, WHITE, (9,11), 2)
        _BERRY_IMG[kind] = s
    return _BERRY_IMG[kind]
BERRY_FLOOR = pygame.Rect(CAVE_ROOM.x+40, CAVE_ROOM.y+250, CAVE_ROOM.w-80, CAVE_ROOM.h-280)
BERRY_CLEAR = pygame.Rect(0, 0, 320, 170); BERRY_CLEAR.midbottom = CAVE_EXIT.midbottom   # clear spot by the exit
def fill_berry_cave(n=150):   # a fresh carpet of berries every new game
    berry_cave_berries.clear()
    spots = [(x, y) for x in range(BERRY_FLOOR.x, BERRY_FLOOR.right, 30) for y in range(BERRY_FLOOR.y, BERRY_FLOOR.bottom, 28)
             if not BERRY_CLEAR.collidepoint(x, y)]
    random.shuffle(spots)
    for x, y in spots[:n]:
        jx, jy = x + random.randint(-6, 6), y + random.randint(-5, 5)
        if BERRY_CLEAR.collidepoint(jx, jy): jx, jy = x, y
        berry_cave_berries.append([jx, jy, random.choice(BERRY_KINDS)])
    berry_cave_berries.sort(key=lambda b: b[1])
def pick_cave_berries():
    for pf, r in ((fox, cave_fox), (fox2, cave_fox2)) if two_player else ((fox, cave_fox),):
        for b in berry_cave_berries[:]:
            if r.inflate(-6, -6).collidepoint(b[0], b[1]):
                berry_cave_berries.remove(b)   # each one is a normal berry
                fox.inventory["berries"] += 1; picked_order.append("berry"); task_berry()
_BCAVE_OUT = []
def draw_berry_cave_outside(cx, cy):
    r = BERRY_CAVE_RECT.move(-cx, -cy)
    if not r.inflate(100, 100).colliderect(screen.get_rect()): return
    if not _BCAVE_OUT:
        s = _cave_mound(BCAVE_PAL, 8).copy(); rr = random.Random(8)
        for bx, by in ((40,70),(60,95),(30,110),(200,75),(185,100),(210,115),(70,40),(170,45)):   # berry bushes on the hill
            for _ in range(3):
                k = rr.choice(BERRY_KINDS); s.blit(pygame.transform.smoothscale(berry_img(k), (16,16)), (bx+rr.randint(-8,8), by+rr.randint(-6,6)))
        _BCAVE_OUT.append(_ready(s))
    screen.blit(_BCAVE_OUT[0], r.topleft)
    t = otext(tinyfont, "Berry Cave", (255,190,250)); screen.blit(t, (r.centerx-t.get_width()//2, r.y-26))
def enter_berry_cave():
    global state, pause_start
    state = "berry_cave"; pause_start = pygame.time.get_ticks()
    cave_fox.center = (CAVE_ROOM.centerx, CAVE_ROOM.bottom-80)
    cave_fox2.center = (CAVE_ROOM.centerx+80, CAVE_ROOM.bottom-80)
def leave_berry_cave():
    global state, start_ticks
    start_ticks += pygame.time.get_ticks() - pause_start   # timer was paused in the cave
    fox.rect.midtop = (BERRY_CAVE_RECT.centerx, BERRY_CAVE_RECT.bottom + 30)
    if two_player: fox2.rect.topleft = (fox.rect.x + 70, fox.rect.y)
    state = "playing"
_BCAVE_BG = []
BCAVE_GLINTS = [(CAVE_ROOM.x+180, CAVE_ROOM.y+120), (CAVE_ROOM.right-200, CAVE_ROOM.y+140), (CAVE_ROOM.centerx, CAVE_ROOM.y+100)]
def draw_berry_cave():
    if not _BCAVE_BG:
        bg = _cave_room_bg(BCAVE_IN_PAL, 4, crystals=False, pool=False)
        rr = random.Random(4)
        for _ in range(26):   # berry vines on the walls
            x, y = rr.randint(CAVE_ROOM.x+40, CAVE_ROOM.right-40), rr.randint(CAVE_ROOM.y+90, CAVE_ROOM.y+215)
            pts = [(x + int(3*math.sin(k)), y-30+k*6) for k in range(6)]
            pygame.draw.lines(bg, (80,160,85), False, pts, 3)
            pygame.draw.ellipse(bg, (120,200,120), (x+2, y-22, 9, 5)); pygame.draw.ellipse(bg, (120,200,120), (x-10, y-12, 9, 5))
            bg.blit(pygame.transform.smoothscale(berry_img(rr.choice(BERRY_KINDS)), (18,18)), (x-9, y-6))
        _BCAVE_BG.append(bg)
    screen.blit(_BCAVE_BG[0], (0,0))
    draw_cave_magic(BCAVE_GLINTS)
    for x, y, k in berry_cave_berries: screen.blit(berry_img(k), (x-13, y-13))
    draw_shoo_ball()
    blit_fox(screen, fox.image, cave_fox.topleft, fox.face_left, 1); draw_held_dagger(cave_fox, fox.face_left)
    screen.blit(otext(bigfont, "Berry Cave", (255,170,240), th=3), (WIDTH//2-195, 17))
    h = otext(tinyfont, f"Berries left: {len(berry_cave_berries)}    Your berries: {fox.inventory['berries']}    Walk out the bright exit or press E to leave  (timer paused)", WHITE)
    screen.blit(h, (WIDTH//2-h.get_width()//2, CAVE_ROOM.bottom+30))

# ================= TREE BERRIES + STICKS NEXT TO TREES =================
_HANG = {}
def hanging_berry_image(side, key="rb3"):   # side = which way the tree is (+1 right, -1 left): a little stem reaches to it
    if (side, key) not in _HANG:
        s = collectible_image(key).copy()
        x0, x1 = (18, 31) if side > 0 else (14, 1)
        pygame.draw.line(s, (60,120,45), (x0, 6), (x1, 1), 4); pygame.draw.line(s, (90,170,70), (x0, 6), (x1, 1), 2)
        _HANG[(side, key)] = _ready(s)
    return _HANG[(side, key)]
def POND_TREE_SPOTS():   # left and right of the pond, just outside the pond's safe ring
    return [(POND_SAFE.left - 41, POND_RECT.centery - 90), (POND_SAFE.right + 41, POND_RECT.centery + 90)]
def grow_tree_berries(n_berries, n_sticks):
    obs = [o.rect for o in obstacles]
    zones = [VILLAGE_RECT, CAVE_RECT.inflate(100,100), BERRY_CAVE_RECT.inflate(100,100), POND_RECT.inflate(120,120)]
    taken = [c.rect for c in collectibles]
    world = pygame.Rect(40, 40, WORLD_W-80, WORLD_H-80)
    def ok(r):
        return (r.top > ROCK_BAND and world.contains(r) and r.collidelist(obs) == -1
                and r.collidelist(zones) == -1 and r.collidelist(taken) == -1)
    bspots, sspots = [], []
    for o in obstacles:
        if getattr(o, "kind", "") != "tree": continue
        r = o.rect
        for dy in (20, 40, 60):
            bspots += [(r.left-17, r.top+dy, 1), (r.right+17, r.top+dy, -1)]   # hanging just outside the leaves
        sspots += [(r.centerx+random.randint(-30,30), r.bottom+18), (r.left-20, r.bottom-12), (r.right+20, r.bottom-12)]
    random.shuffle(bspots); random.shuffle(sspots)
    nb = ns = 0
    for x, y, side in bspots:
        if nb >= n_berries: break
        c = Collectible(x, y, "berry")
        if ok(c.rect):
            c.image = c.image if (CANDY[0] or THEME[0] == "space") else hanging_berry_image(side, real_berry_key(x, y)); collectibles.add(c); taken.append(c.rect); nb += 1
    for x, y in sspots:
        if ns >= n_sticks: break
        c = Collectible(x, y, "stick")
        if ok(c.rect): collectibles.add(c); taken.append(c.rect); ns += 1
    return nb, ns

# ================= MOUNTAIN RAIN =================
def rain_chance(players):
    if level == 1: return 0.0   # Level 1 never rains
    if any(pf.rect.colliderect(VILLAGE_RECT) for pf in players): return 0.0   # it never rains in Fox Village
    c = LEVELS[level-1].get("rain", 0.0005)
    if any(pf.rect.centery < ROCK_BAND for pf in players): c = max(c, 0.004)   # mountain weather!
    return c

SPRINKLE_COLS = [(255,90,150), (90,200,255), (255,220,60), (120,220,120), (200,130,255), (255,150,80), WHITE]
def draw_rain(cx, cy, players):   # rain everywhere except over Fox Village
    if any(pf.rect.colliderect(VILLAGE_RECT) for pf in players): return
    if CANDY[0]:   # Candyland: colorful SPRINKLES fall instead of rain (no gray sky)
        v = VILLAGE_RECT.move(-cx, -cy)
        for i, (x, y, _) in enumerate(raindrops):
            if v.collidepoint(x, y): continue
            pygame.draw.line(screen, SPRINKLE_COLS[i % len(SPRINKLE_COLS)], (x, y), (x + (3 if i % 2 else -3), y + 7), 4)
        return
    v = VILLAGE_RECT.move(-cx, -cy).clip(screen.get_rect())
    if v.w and v.h:   # tint only around the village
        for r in (pygame.Rect(0, 0, WIDTH, v.top), pygame.Rect(0, v.bottom, WIDTH, HEIGHT-v.bottom),
                  pygame.Rect(0, v.top, v.left, v.h), pygame.Rect(v.right, v.top, WIDTH-v.right, v.h)):
            if r.w > 0 and r.h > 0: screen.blit(RAIN_TINT, r.topleft, r)
    else: screen.blit(RAIN_TINT, (0, 0))
    for x, y, _ in raindrops:
        if v.collidepoint(x, y) or v.collidepoint(x-3, y+12): continue
        pygame.draw.line(screen,(170,210,255),(x,y),(x-3,y+12),2)
        pygame.draw.line(screen,WHITE,(x,y),(x-1,y+4),1)

# ================= TEA KETTLE (in every house) =================
MAX_HEARTS = 6
HEART_LIMIT = 4   # Faroe Oct 31: only 4 hearts back per game (tea + muffin + cocoa together), each player her own 4
def hearts_left(pf): return getattr(pf, "hearts_left", HEART_LIMIT)
def use_heart(pf): pf.hearts += 1; pf.hearts_left = hearts_left(pf) - 1
NO_HEARTS_MSG = "No more hearts! You used all 4."
KETTLE_SPOT = pygame.Rect(ROOM.x+25, ROOM.bottom-125, 100, 95)   # little stove in the bottom-left corner
kettle_full = True; kettle_touch_prev = 0; kettle_msg = ""; kettle_msg_t = 0
energize_t = 0; energize_who = 1
_KETTLE = []
def _make_kettle():
    s = pygame.Surface((100,95), pygame.SRCALPHA)
    pygame.draw.rect(s, (70,70,85), (8,50,84,40), border_radius=6)                  # little iron stove
    pygame.draw.rect(s, (60,140,150), (14,86,8,9), border_radius=3); pygame.draw.rect(s, (60,140,150), (78,86,8,9), border_radius=3)
    pygame.draw.rect(s, (255,140,40), (34,62,32,18), border_radius=4)                # cozy fire window
    pygame.draw.rect(s, (255,220,110), (40,66,20,8), border_radius=3)
    pygame.draw.rect(s, (95,95,110), (4,46,92,8), border_radius=3)                   # stove top
    pygame.draw.ellipse(s, (70,190,190), (26,12,48,38))                               # round teal kettle
    pygame.draw.polygon(s, (70,190,190), [(70,30),(90,16),(92,20),(74,38)])          # spout
    pygame.draw.ellipse(s, (60,165,165), (36,8,28,9)); pygame.draw.circle(s, (240,90,120), (50,7), 4)   # lid + knob
    pygame.draw.arc(s, (70,150,160), (30,0,40,30), 0.3, math.pi-0.3, 4)                 # handle
    _shade(s, 185); s = _outline(s)
    pygame.draw.ellipse(s, WHITE, (34,20,10,6))
    for hx in (38, 50, 62): pygame.draw.circle(s, (255,150,180), (hx, 36), 3)         # hearts pattern
    return s
_PUFF = pygame.Surface((26,26), pygame.SRCALPHA)
for _k in range(5): pygame.draw.circle(_PUFF, (255,255,255,40), (13,13), 13-_k*2)
def draw_kettle():
    if not _KETTLE: _KETTLE.append(_make_kettle())
    screen.blit(_KETTLE[0], KETTLE_SPOT.topleft)
    t = pygame.time.get_ticks()
    sx, sy = KETTLE_SPOT.x+91, KETTLE_SPOT.y+14
    for k in range(4):   # steam puffs curl up from the spout
        p = ((t/1400.0) + k/4.0) % 1.0
        _PUFF.set_alpha(int(220*(1-p)) if kettle_full else int(90*(1-p)))
        screen.blit(_PUFF, (sx-13+int(8*math.sin(p*6+k)) + int(p*10), sy-13-int(p*70)))
    if kettle_msg_t > 0:
        m = otext(font, kettle_msg, (255,240,150) if kettle_msg.startswith("Sip") else WHITE)
        screen.blit(m, (WIDTH//2-m.get_width()//2, ROOM.y+135))
def sip_kettle(who):
    global kettle_full, kettle_msg, kettle_msg_t, energize_t, energize_who
    pf = heal_fox(who)
    if pf.out: return   # a ghost can't sip tea
    if kettle_full and hearts_left(pf) <= 0:
        kettle_msg = NO_HEARTS_MSG                                  # heart limit used up: the tea stays in the kettle
    elif kettle_full and pf.hearts < MAX_HEARTS:
        use_heart(pf); kettle_full = False
        kettle_msg = "Sip! You feel energized! +1 heart"; energize_t = 90; energize_who = who
    elif kettle_full:
        kettle_msg = "Your hearts are already full!"
    else:
        kettle_msg = "The kettle is empty. Come back later!"
    kettle_msg_t = 150
_HEART_S = pygame.Surface((26,24), pygame.SRCALPHA)
pygame.draw.circle(_HEART_S, RED, (7,8), 7); pygame.draw.circle(_HEART_S, RED, (19,8), 7)
pygame.draw.polygon(_HEART_S, RED, [(0,10),(26,10),(13,23)]); _HEART_S = _outline(_HEART_S)
pygame.draw.circle(_HEART_S, WHITE, (6,6), 2)
_EGLOW = pygame.Surface((150,150), pygame.SRCALPHA)
for _k in range(12): pygame.draw.circle(_EGLOW, (255,215,80,16), (75,75), 75-_k*6)
def draw_energize(cx, cy, top):   # ~1.5 s: golden glow, swirling sparkles, a heart floating up
    p = 1 - energize_t/90.0
    _EGLOW.set_alpha(int(160 + 90*math.sin(p*math.pi*8))); screen.blit(_EGLOW, (cx-75, cy-75))
    for k in range(10):
        a = k*0.628 + p*9; rad = 34 - p*14
        x = cx + math.cos(a)*rad; y = cy + 10 - p*80 - (k % 3)*8 + math.sin(a)*8
        col = GOLD if k % 2 else WHITE
        pygame.draw.line(screen, col, (x-4, y), (x+4, y), 2); pygame.draw.line(screen, col, (x, y-4), (x, y+4), 2)
    h = _HEART_S.copy(); h.set_alpha(int(255*min(1, (1-p)*3)))
    screen.blit(h, (cx-13, top-30-int(p*60)))

# ================= GLOWING DAGGER SWING (D) =================
dagger_t = 0; dagger_cd = 0; dagger_dir = pygame.math.Vector2(1, 0); dagger_clang = False
kos = []; clangs = []   # little "KO!" and "CLANG!" pops: [x, y, frames]
def swing_dagger():
    global dagger_t, dagger_cd, dagger_dir, dagger_clang
    if fox.inventory.get("dagger", 0) < 1 or dagger_cd > 0: return   # only if she has it (it's never used up)
    globals()["dagger_swing"] = globals().get("dagger_swing", 0) + 1   # each swing can hit a troll only once
    dagger_t = 15; dagger_cd = 30; dagger_dir = pygame.math.Vector2(fox.direction); dagger_clang = False
    fox.throw_t = 12                                                     # paw swings forward
def update_dagger():
    global dagger_t, dagger_cd, dagger_clang
    if dagger_cd > 0: dagger_cd -= 1
    if dagger_t <= 0: return
    dagger_t -= 1
    zx, zy = fox.rect.centerx + dagger_dir.x*45, fox.rect.centery + dagger_dir.y*45   # zone in front of her
    for t in list(trolls):
        if math.hypot(t.rect.centerx-zx, t.rect.centery-zy) < 70 and getattr(t, "last_swing", -1) != globals().get("dagger_swing", 0):
            t.last_swing = globals().get("dagger_swing", 0)
            kx, ky = t.rect.centerx, t.rect.y
            if hit_troll(t): kos.append([kx, ky, 40])
    if boss and not dagger_clang:
        bx = max(boss.rect.left, min(zx, boss.rect.right)); by = max(boss.rect.top, min(zy, boss.rect.bottom))
        if math.hypot(bx-zx, by-zy) < 70:
            dagger_clang = True                    # one hit per swing
            if boss.dagger_hit(fox.rect.center): beat_boss()
_HELD = []
def draw_held_dagger(r, face_left):   # the glowing green dagger in her front paw (r = her rect on screen)
    if fox.inventory.get("dagger", 0) < 1 or dagger_t > 0: return     # during a swing the swing shows it
    if not _DAGGER: draw_dagger(pygame.Surface((1,1), pygame.SRCALPHA), 0, 0)
    if not _HELD:
        d = pygame.transform.rotozoom(_DAGGER[0], -80, 1.0)                 # held OUT, blade pointing forward
        _HELD.append(d); _HELD.append(pygame.transform.flip(d, True, False))
        _HELD.append(pygame.transform.smoothscale(_DAGGER[1], (64, 64)))
    d = _HELD[1] if face_left else _HELD[0]
    bob = int(3*math.sin(fox.step*0.9)) if getattr(fox, "moving", True) else 0   # bobs with her steps
    x = r.left - 6 if face_left else r.right + 6; y = r.bottom - 18 + bob
    g = _HELD[2]; g.set_alpha(160 + int(90*math.sin(pygame.time.get_ticks()/250)))
    screen.blit(g, (x-32, y-32)); screen.blit(d, (x - d.get_width()//2, y - d.get_height()//2))
_DFONT = []
def draw_hud_dagger(x, y):   # HUD icon: glowing green dagger with "D" under it
    if not _DFONT: _DFONT.append(pygame.font.Font(None, 22))
    draw_dagger(screen, x, y)
    t = otext(_DFONT[0], "D", (150,255,170), (20,90,40), 1); screen.blit(t, (x - t.get_width()//2, y + 20))
def draw_dagger_swing(cx, cy):
    if dagger_t <= 0: return
    if not _DAGGER: draw_dagger(pygame.Surface((1,1), pygame.SRCALPHA), 0, 0)
    p = 1 - dagger_t/15.0
    th = math.atan2(dagger_dir.y, dagger_dir.x); a0 = th - math.pi/4; a = a0 + (math.pi/2)*p   # quarter turn: th-45deg .. th+45deg
    ox, oy = fox.rect.centerx - cx, fox.rect.centery - cy
    pts = [(ox + math.cos(a0 + (a-a0)*k/10)*58, oy + math.sin(a0 + (a-a0)*k/10)*58) for k in range(11)]
    if len(pts) > 1:
        pygame.draw.lines(screen, (80,255,120), False, pts, 12)    # glowing GREEN swoosh
        pygame.draw.lines(screen, (210,255,220), False, pts, 4)
    d = pygame.transform.rotate(_DAGGER[0], -90 - math.degrees(a))
    dx, dy = ox + math.cos(a)*38, oy + math.sin(a)*38
    screen.blit(d, (dx - d.get_width()//2, dy - d.get_height()//2))
# ================= FINALE: Fox Village is LOCKED by a candy barrier until the Boss Troll is beaten =================
LOCK = {"cd": 0, "msg": 0, "open": 0}   # pop-up cooldown, pop-up frames, "village is open" banner frames
barrier_sparks = []                      # [x, y, vx, vy, frames, color]
def village_locked():
    return bool(LEVELS[level-1].get("finale")) and boss is not None
def village_bump(pf):   # True when she'd step through the locked barrier
    if pf.rect.colliderect(VILLAGE_RECT): pf.lock_bump = True; return True
    return False
_BARRIER = []
def _make_barrier():
    V = VILLAGE_RECT; M = 30; w, h = V.w + 2*M, V.h + 2*M
    glow = pygame.Surface((w, h), pygame.SRCALPHA)
    for k in range(15):   # glowing bubble wall: magenta-pink, brightest right at the edge
        a = 30 + k*14 if k < 10 else 170 - (k-10)*30
        pygame.draw.rect(glow, (255,90,190,max(0, min(200, a))), (k*3, k*3, w-k*6, h-k*6), 4, border_radius=40)
    for k in range(3):   # a whiter shimmer line in the middle of the wall
        pygame.draw.rect(glow, (255,220,245,200-k*50), (M-4+k, M-4+k, V.w+8-2*k, V.h+8-2*k), 1, border_radius=27)
    pygame.draw.rect(glow, (255,235,250,170), (M-2, M-2, V.w+4, V.h+4), 3, border_radius=26)
    fence = pygame.Surface((w, h), pygame.SRCALPHA)
    for off, col in ((-6, (255,120,190)), (6, (255,190,225))):   # two pink candy rails all the way round
        pygame.draw.rect(fence, col, (M+off, M+off, V.w-2*off, V.h-2*off), 5, border_radius=24)
    pts = []
    for x in range(M, M + V.w + 1, 60): pts += [(x, M), (x, M + V.h)]
    for y in range(M + 60, M + V.h, 60): pts += [(M, y), (M + V.w, y)]
    for (x, y) in pts:   # peppermint posts: striped stick with a round swirly mint on top
        pygame.draw.rect(fence, (240,195,205), (x-6, y-22, 12, 30), border_radius=6)
        pygame.draw.rect(fence, WHITE, (x-5, y-21, 10, 28), border_radius=5)
        for yy in range(y-18, y+6, 7): pygame.draw.line(fence, (230,40,60), (x-5, yy+3), (x+4, yy-1), 3)
        pygame.draw.circle(fence, (240,195,205), (x, y-24), 11); pygame.draw.circle(fence, WHITE, (x, y-24), 10)
        for k in range(4):
            a = k*math.pi/2
            pygame.draw.polygon(fence, (230,40,60), [(x, y-24), (x+10*math.cos(a), y-24+10*math.sin(a)), (x+10*math.cos(a+0.8), y-24+10*math.sin(a+0.8))])
        pygame.draw.circle(fence, WHITE, (x, y-24), 3); pygame.draw.circle(fence, WHITE, (x-4, y-28), 2)
    return glow.convert_alpha(), fence.convert_alpha()
def draw_village_barrier(cx, cy):
    if not village_locked(): return
    V = VILLAGE_RECT; M = 30
    r = V.inflate(2*M, 2*M).move(-cx, -cy)
    if not r.inflate(60, 60).colliderect(screen.get_rect()): return
    if not _BARRIER: _BARRIER.extend(_make_barrier())
    glow, fence = _BARRIER; t = pygame.time.get_ticks()
    glow.set_alpha(150 + int(90*math.sin(t/260))); screen.blit(glow, r.topleft)   # shimmering bubble wall
    screen.blit(fence, r.topleft)
    per = 2*(V.w + V.h)
    for k in range(60):   # soap-bubbles drifting up along the wall
        d = (k*per/60 + k*37) % per
        if d < V.w: px, py = V.x + d, V.y
        elif d < V.w + V.h: px, py = V.right, V.y + d - V.w
        elif d < 2*V.w + V.h: px, py = V.right - (d - V.w - V.h), V.bottom
        else: px, py = V.x, V.bottom - (d - 2*V.w - V.h)
        ph = ((t/1600.0) + k*0.37) % 1.0; br = 4 + k % 5
        bx, by = int(px - cx + 6*math.sin(t/300 + k)), int(py - cy + 18 - ph*46)
        if -20 < bx < WIDTH + 20 and -20 < by < HEIGHT + 20:
            pygame.draw.circle(screen, (255,170,225), (bx, by), br, 2); pygame.draw.circle(screen, WHITE, (bx - br//3, by - br//3), max(1, br//4))
    for k in range(36):   # sparkles gliding round the wall
        d = (k*per/36 + t*0.06) % per
        if d < V.w: px, py = V.x + d, V.y
        elif d < V.w + V.h: px, py = V.right, V.y + d - V.w
        elif d < 2*V.w + V.h: px, py = V.right - (d - V.w - V.h), V.bottom
        else: px, py = V.x, V.bottom - (d - 2*V.w - V.h)
        tw = (math.sin(t/180 + k*1.3) + 1) / 2
        if tw > 0.3: _star_glint(screen, int(px - cx), int(py - cy - 10), int(3 + 6*tw), (255,240,250) if k % 2 else (255,190,230))
def pop_barrier():   # boss beaten: the barrier POPS into sparkles
    V = VILLAGE_RECT; per = 2*(V.w + V.h)
    for k in range(160):
        d = k*per/160
        if d < V.w: px, py, nx, ny = V.x + d, V.y, 0, -1
        elif d < V.w + V.h: px, py, nx, ny = V.right, V.y + d - V.w, 1, 0
        elif d < 2*V.w + V.h: px, py, nx, ny = V.right - (d - V.w - V.h), V.bottom, 0, 1
        else: px, py, nx, ny = V.x, V.bottom - (d - 2*V.w - V.h), -1, 0
        v = random.uniform(1.5, 6); sd = random.uniform(-2, 2)
        barrier_sparks.append([px, py, nx*v + (ny and sd), ny*v + (nx and sd), random.randint(40, 80),
                               random.choice(((255,150,215), (255,255,255), (255,90,120), (255,220,240)))])
    LOCK["open"] = 260; LOCK["msg"] = 0
def draw_barrier_fx(cx, cy):
    for sp in barrier_sparks[:]:
        sp[0] += sp[2]; sp[1] += sp[3]; sp[2] *= 0.95; sp[3] *= 0.95; sp[4] -= 1
        if sp[4] <= 0: barrier_sparks.remove(sp); continue
        x, y = int(sp[0]-cx), int(sp[1]-cy)
        if -20 < x < WIDTH + 20 and -20 < y < HEIGHT + 20:
            if sp[4] % 12 < 6: _star_glint(screen, x, y, 3 + sp[4]//14, sp[5])
            else: pygame.draw.circle(screen, sp[5], (x, y), 2 + sp[4]//25)
def village_lock_step(players):   # once per frame while playing: gentle push-back + pop-up
    if LOCK["cd"] > 0: LOCK["cd"] -= 1
    if LOCK["msg"] > 0: LOCK["msg"] -= 1
    if LOCK["open"] > 0: LOCK["open"] -= 1
    if not village_locked():
        for pf in players: pf.lock_bump = False; pf.lock_kick = 0
        return
    V = VILLAGE_RECT
    for pf in players:
        if getattr(pf, "lock_bump", False) or pf.rect.colliderect(V):
            pf.lock_bump = False
            gaps = {(-1,0): pf.rect.right - V.left, (1,0): V.right - pf.rect.left, (0,-1): pf.rect.bottom - V.top, (0,1): V.bottom - pf.rect.top}
            pf.lock_dir = min(gaps, key=gaps.get); pf.lock_kick = 10
            if LOCK["cd"] == 0: LOCK["msg"] = 150; LOCK["cd"] = 300
        if pf.rect.colliderect(V):   # somehow inside: slide her out to the nearest edge
            ddx, ddy = pf.lock_dir; pf.rect.x += ddx*6; pf.rect.y += ddy*6
        elif getattr(pf, "lock_kick", 0) > 0:   # a gentle bounce back from the wall
            pf.lock_kick -= 1; ddx, ddy = pf.lock_dir; k = 1 + pf.lock_kick // 4
            pf.rect.x += ddx*k; pf.rect.y += ddy*k
            if pygame.sprite.spritecollideany(pf, obstacles) or pf.rect.collidelist(POND_BLOCKS) != -1:
                pf.rect.x -= ddx*k; pf.rect.y -= ddy*k; pf.lock_kick = 0
        pf.rect.clamp_ip(pygame.Rect(0, 0, WORLD_W, WORLD_H))
def draw_lock_popups():
    if LOCK["msg"] > 0 and village_locked():
        im = otext(font, f"The village is locked! Beat {BOSS_NAME()} first!", WHITE, (170,50,120), 3)
        w = im.get_width() + 60; x = WIDTH//2 - w//2; y = 300
        cartoon_panel(x, y, w, im.get_height() + 24, (255,170,220), (220,90,170), 235)
        screen.blit(im, (x + 30, y + 12))
    if LOCK["open"] > 0:
        k = LOCK["open"]; im = otext(bigfont, "The village is open!", (255,235,250), (200,60,140), 3)
        y = 250 + max(0, (k - 230))*3
        screen.blit(im, (WIDTH//2 - im.get_width()//2, y))
        t = pygame.time.get_ticks()
        for j in range(8):
            a = j*0.785 + t/400.0
            _star_glint(screen, int(WIDTH//2 + math.cos(a)*(im.get_width()//2 + 30)), int(y + im.get_height()//2 + math.sin(a)*40), 7, (255,200,235) if j % 2 else WHITE)
ouches = []; boss_sparks = []; boss_banner = 0
def beat_boss():   # third dagger hit: POOF with green sparkles, gone for the rest of this run
    global boss, boss_banner
    for k in range(70):
        a = random.uniform(0, 6.283); v = random.uniform(2, 9)
        boss_sparks.append([boss.rect.centerx, boss.rect.centery, math.cos(a)*v, math.sin(a)*v, random.randint(35, 70)])
    boss = None; boss_banner = 240
    if LEVELS[level-1].get("finale"): pop_barrier(); rage_banner[0] = 0   # Fox Village opens! (and "You beat the Boss Troll!" shows)
def draw_pops(cx, cy):
    global boss_banner
    for pp in ouches[:]:
        im = otext(font, "OUCH!", (120,255,140), (20,90,40))
        screen.blit(im, (pp[0]-cx-im.get_width()//2, pp[1]-cy-40-(40-pp[2])))
        pp[2] -= 1
        if pp[2] <= 0: ouches.remove(pp)
    for sp in boss_sparks[:]:
        sp[0] += sp[2]; sp[1] += sp[3]; sp[2] *= 0.95; sp[3] *= 0.95; sp[4] -= 1
        if sp[4] <= 0: boss_sparks.remove(sp); continue
        r = 2 + sp[4] // 18
        pygame.draw.circle(screen, (80,255,120), (int(sp[0]-cx), int(sp[1]-cy)), r+2)
        pygame.draw.circle(screen, (220,255,225), (int(sp[0]-cx), int(sp[1]-cy)), r)
    if boss_banner > 0:
        boss_banner -= 1
        pn = pygame.Surface((760, 90), pygame.SRCALPHA); pygame.draw.rect(pn, (30,70,40,170), (0,0,760,90), border_radius=20)
        screen.blit(pn, (WIDTH//2-380, 150))
        im = otext(font, f"You beat {BOSS_NAME()}!", (150,255,160), (20,90,40), 3)
        screen.blit(im, (WIDTH//2-im.get_width()//2, 195-im.get_height()//2))
    for lst, txt, col in ((kos, "KO!", YELLOW), (clangs, "CLANG!", (200,230,255))):
        for pp in lst[:]:
            im = otext(font if txt == "CLANG!" else tinyfont, txt, col)
            screen.blit(im, (pp[0]-cx-im.get_width()//2, pp[1]-cy-30-(45-pp[2])))
            if txt == "KO!":
                for k in range(6):
                    a = k*1.047 + pp[2]*0.2; r = 10 + (40-pp[2])
                    pygame.draw.circle(screen, GOLD, (int(pp[0]-cx+math.cos(a)*r), int(pp[1]-cy+20+math.sin(a)*r)), 3)
            pp[2] -= 1
            if pp[2] <= 0: lst.remove(pp)

# ================= LIGHTNING STORM + DARK GLOW MODE =================
storm_on = False; troll_acc = 0.0; troll_steps = 1
bolts = []; flash_t = 0
DARK_GLOW = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); DARK_GLOW.fill((5,10,40,180))   # ~70% dark blue
FLASH = pygame.Surface((WIDTH, HEIGHT), 0, 32); FLASH.fill((210,225,255))
def _glow(r, col):   # pre-rendered soft light for additive blending
    g = pygame.Surface((r*2, r*2), 0, 32); g.fill((0,0,0))
    for k in range(r, 0, -2):
        f = (1 - k/r) ** 1.6
        pygame.draw.circle(g, (int(col[0]*f), int(col[1]*f), int(col[2]*f)), (r, r), k)
    return g
GLOW_FOX = _glow(48, (150,90,25)); GLOW_EYE = _glow(14, (255,150,20)); GLOW_BIGEYE = _glow(26, (255,140,10))
GLOW_ITEM = {"golden_berry": _glow(20, (120,95,20)), "berry": _glow(20, (90,30,90)), "stick": _glow(20, (70,50,25)), "stone": _glow(20, (55,55,70))}
GLOW_WIN = _glow(22, (180,140,40)); GLOW_STATUE = _glow(90, (170,140,30))
GLOW_CAVE = _glow(46, (170,90,30)); GLOW_BCAVE = _glow(46, (160,60,150)); GLOW_POND = _glow(150, (20,60,120))
def _make_bolt():
    x = random.randint(80, WIDTH-80); y = 110; pts = [(x, y)]
    end = random.randint(330, 640)
    while y < end:
        y += random.randint(25, 55); x += random.randint(-45, 45); pts.append((x, y))
    return [pts, 9]
def start_storm():
    global flash_t
    bolts.append(_make_bolt()); flash_t = 8
# ---------- MOUNTAIN FREEZE: 10 s on the SNOWY MOUNTAINS (very top of the map) = GAME OVER ----------
FREEZE_FRAMES = 600            # 10 seconds
CAMPFIRES = []                 # outdoor campfires (world spots); standing within 150 px of one keeps you warm
cold_last = [0]
freeze_t = [0]                 # the short "freezing" moment before the game over screen
game_over_why = [""]
def mountain_base(x):          # the bottom line of the mountain picture drawn at world x (same math as the drawing)
    return 200 + 80*math.sin(x*0.02)
def in_snowy_mountains(r):
    """THE one place a fox can freeze: standing on the snowy mountain picture at the very top of the map.
    Each mountain is drawn every 80 px as a 240-wide triangle whose base sits on mountain_base(x)."""
    px, py = r.centerx, r.centery
    if py > 300: return False                                                 # the mountain art never reaches lower
    if r.colliderect(VILLAGE_RECT) or r.colliderect(BERRY_CAVE_RECT.inflate(60, 60)) or r.colliderect(CAVE_RECT.inflate(60, 60)): return False
    if r.colliderect(POND_RECT.inflate(300, 300)) or r.colliderect(WARP_RECT.inflate(40, 40)): return False
    if math.hypot(px - fox.start[0], py - fox.start[1]) < 400: return False   # the start spot
    if any(h.rect.inflate(40, 40).colliderect(r) for h in houses) or (shop and shop.rect.inflate(40, 40).colliderect(r)): return False
    if any(math.hypot(px-fx, py-fy) < 150 for fx, fy in CAMPFIRES): return False
    for x0 in range(max(0, int(px - 240)//80*80), min(WORLD_W, int(px) + 1), 80):
        lx = px - x0; ly = py - (mountain_base(x0) - 205)
        if 0 <= lx <= 240 and ly <= 205 and ly >= 5 + 200*abs(lx - 120)/120: return True
    return False
def update_cold(players):
    """True when a fox has frozen solid (10 s in a row on the snowy mountains)"""
    now = pygame.time.get_ticks()
    if now - cold_last[0] > 250:                          # was inside a house/cave/shop (or paused): warmed up
        for pf in players: pf.cold = 0
    cold_last[0] = now
    for pf in players:
        if not in_snowy_mountains(pf.rect): pf.cold = 0; continue   # leaving the snow resets it right away
        pf.cold = getattr(pf, "cold", 0) + 1
        if pf.cold >= FREEZE_FRAMES:
            freeze_t[0] = 120; game_over_why[0] = "frozen"; pf.frozen = True
            return True
    return False
_ICED = {}
def iced_image(img):   # ice-blue frozen fox
    key = id(img)
    if key not in _ICED:
        g = pygame.transform.grayscale(img)
        g.fill((170, 220, 255), special_flags=pygame.BLEND_RGB_MULT); g.fill((45, 70, 105), special_flags=pygame.BLEND_RGB_ADD)
        _ICED.clear(); _ICED[key] = g
    return _ICED[key]
_FROST = {}
def draw_cold(cx, cy, players):
    worst = max(getattr(pf, "cold", 0) for pf in players)
    if state in ("freezing", "game_over") and game_over_why[0] == "frozen": k = 1.0
    elif state == "playing" and worst > FREEZE_FRAMES - 300: k = (worst - (FREEZE_FRAMES - 300)) / 300.0   # last 5 seconds only
    else: k = 0.0
    if k > 0:   # frost creeps in from the screen edges
        step = int(k*20)
        if step not in _FROST:
            fr = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); kk = max(0.05, step/20.0)
            th = int(30 + 170*kk)
            for i in range(30):   # soft frost: faint on the inside, thick and white at the very edge
                a = int(205*kk*((i+1)/30.0)**1.6); w = th*(30-i)//30
                pygame.draw.rect(fr, (215, 240, 255, a), (0, 0, WIDTH, HEIGHT), max(1, w), border_radius=60)
            rr = random.Random(step)
            for _ in range(int(60*kk)):   # little ice crystals near the edges
                side = rr.randint(0, 3); d = rr.randint(5, th)
                x, y = ((d, rr.randint(0, HEIGHT)), (WIDTH-d, rr.randint(0, HEIGHT)), (rr.randint(0, WIDTH), d), (rr.randint(0, WIDTH), HEIGHT-d))[side]
                for a in range(3):
                    ang = a*math.pi/3
                    pygame.draw.line(fr, (240,250,255,200), (x - 6*math.cos(ang), y - 6*math.sin(ang)), (x + 6*math.cos(ang), y + 6*math.sin(ang)), 2)
            _FROST[step] = fr
        screen.blit(_FROST[step], (0, 0))
    if state == "playing" and worst > FREEZE_FRAMES - 300:   # Too cold! 5..4..3..2..1
        n = (FREEZE_FRAMES - worst - 1) // 60 + 1
        im = otext(bigfont, f"Too cold! {n}", (200,240,255), (50,90,150), 4)
        screen.blit(im, (WIDTH//2 - im.get_width()//2, 150))
        for pf in players:
            if getattr(pf, "cold", 0) > FREEZE_FRAMES - 300:
                b = otext(tinyfont, "Brrr...", (200,240,255), (50,90,150))
                screen.blit(b, (pf.rect.centerx-cx-b.get_width()//2, pf.rect.top-cy-34))
    if state == "freezing":
        cartoon_panel(WIDTH//2-430, 150, 860, 110, (150,200,245), (90,130,200))
        im = otext(font, "Brrr! Your fox froze in the mountains!", (230,248,255), (50,90,150), 3)
        screen.blit(im, (WIDTH//2 - im.get_width()//2, 205 - im.get_height()//2))

WARP_RECT = pygame.Rect(int(40*WS), int(110*WS), 140, 140)           # swirling portal in the top-left corner (below the HUD)
WARP_DEST = (CAVE_DOOR.centerx, CAVE_DOOR.bottom + 150)              # open spot just outside the Secret Cave
WARP_LAND = pygame.Rect(0, 0, 260, 160); WARP_LAND.center = (WARP_DEST[0], WARP_DEST[1] + 20)
warp_cd = [0]; warp_fx = []
def update_warp(players):
    if warp_cd[0] > 0: warp_cd[0] -= 1; return
    if any(pf.rect.colliderect(WARP_RECT) for pf in players):        # one-way WHOOSH for the whole team
        for pf in players: warp_fx.append([pf.rect.centerx, pf.rect.centery, 40, 0])
        for i, pf in enumerate(players):
            pf.rect.center = (WARP_DEST[0] + i*70, WARP_DEST[1])
            warp_fx.append([pf.rect.centerx, pf.rect.centery, 40, 1 if i == 0 else 0])
        warp_cd[0] = 60                                                # 1 second before it can warp again
def draw_warp(cx, cy):
    r = WARP_RECT.move(-cx, -cy); t = pygame.time.get_ticks()
    if r.inflate(200, 200).colliderect(screen.get_rect()):
        g = pygame.Surface((200, 200), pygame.SRCALPHA)
        for k in range(10): pygame.draw.circle(g, (170, 90, 255, 16), (100, 100), 100 - k*8)
        screen.blit(g, (r.centerx-100, r.centery-100))
        cols = [(255,90,90), (255,170,60), (255,240,90), (90,220,120), (90,170,255), (170,110,255), (230,110,230)]
        if CANDY[0]:   # Candyland: a big spinning PEPPERMINT swirl
            pygame.draw.circle(screen, (255,250,250), r.center, 68)
            spin = t/500.0
            for k in range(8):
                a = spin + k*math.pi/4
                pts = [r.center] + [(r.centerx + math.cos(a + j*0.06)*66, r.centery + math.sin(a + j*0.06)*66) for j in range(0, 7)]
                pygame.draw.polygon(screen, (235,50,70) if k % 2 == 0 else (255,190,200), pts)
            pygame.draw.circle(screen, (255,225,230), r.center, 68, 5); pygame.draw.circle(screen, (255,255,255), r.center, 16)
            cols = []
        for k, col in enumerate(cols):                                  # spinning rainbow rings
            rad = 68 - k*9; a0 = t/300.0*(1 if k % 2 else -1) + k
            rect = pygame.Rect(0, 0, rad*2, rad*2); rect.center = r.center
            pygame.draw.arc(screen, col, rect, a0, a0 + 4.4, 6)
            pygame.draw.arc(screen, _light(col, 60), rect, a0 + 0.3, a0 + 1.4, 2)
        pygame.draw.circle(screen, (120, 60, 200), r.center, 12); pygame.draw.circle(screen, (235, 210, 255), r.center, 6)
        for k in range(8):                                              # sparkles
            a = t/400.0 + k*0.785; rr = 40 + 30*math.sin(t/300.0 + k)
            sx, sy = r.centerx + math.cos(a)*rr, r.centery + math.sin(a)*rr
            pygame.draw.polygon(screen, (255, 250, 200), [(sx,sy-5),(sx+1.5,sy-1.5),(sx+5,sy),(sx+1.5,sy+1.5),(sx,sy+5),(sx-1.5,sy+1.5),(sx-5,sy),(sx-1.5,sy-1.5)])
        n = otext(tinyfont, "WARP ZONE", (235, 200, 255), (90, 40, 140)); screen.blit(n, (r.centerx - n.get_width()//2, r.bottom + 4))
    for fx in warp_fx[:]:                                               # sparkle-poof + WHOOSH text
        k = 40 - fx[2]
        for j in range(10):
            a = j*0.628 + k*0.05; rr = 8 + k*2.2
            pygame.draw.circle(screen, (200, 140, 255) if j % 2 else (255, 240, 160), (int(fx[0]-cx + math.cos(a)*rr), int(fx[1]-cy + math.sin(a)*rr)), max(1, 5 - k//9))
        if fx[3]:
            im = otext(font, "WHOOSH! Warp!", (235, 200, 255), (90, 40, 140)); screen.blit(im, (fx[0]-cx-im.get_width()//2, fx[1]-cy-70-k//2))
        fx[2] -= 1
        if fx[2] <= 0: warp_fx.remove(fx)

# ================= DARK GREEN TROLLS (3 extra per level, a bit faster) =================
FOX_WALK = 8.4          # fox normal walking speed (px per frame). Nov 8: was 6.2, then 7.8 - quicker trips to Fox Village
MEAT_SPEED = max(12.4, FOX_WALK + 4)   # meat is always the top (or equal-top) boost: at least walk + the golden berry's +4
SPRINT_BONUS = 0.6*FOX_WALK            # SPRINT (Nov 8): +60% of the walk while held
SPRINT_MAX, SPRINT_REST = 600, 600     # a full sprint lasts 10 s, then a 10 s rest before it works again (the meter refills while not sprinting)
SPRINT_KEYS = (pygame.K_LSHIFT, pygame.K_RSHIFT)   # player 1 sprints with either SHIFT
FOX2_SPRINT_KEYS = (pygame.K_u,)                   # player 2 (I J K L) sprints with U
TROLL_STEP_PX = 7.2     # Nov 8 (Anton): a regular troll moves 7.2 px per frame on a speed-1.0 level (was ~2) - just a bit slower than the fox
TROLL_CAP = 0.9*FOX_WALK    # regular trolls never go faster than this (Speedy Trolls x1.3 and lightning x2 included)
FAST_CAP = 0.95*FOX_WALK    # NOTHING that chases the fox is ever faster than this: she can always outrun every troll
BOUNCE_SPEED = 3.0          # pond bounce / Shoo Ball push-away: the same gentle little bounce as before
def troll_speed(lv=None, storm=None):   # px per frame for a regular troll (yetis, aliens, scorpions, dragons are trolls with a new look)
    if storm is None: storm = storm_on
    return min(TROLL_CAP, TROLL_STEP_PX * LEVELS[(lv or level)-1]["speed"] * (2 if storm else 1))
def green_speed(lv=None):
    R_ = troll_speed(lv, False)                                          # regular troll speed this level
    return min(1.2*R_, 0.5*(R_ + FAST_CAP))                              # strictly between regular trolls and the fox
assert all(troll_speed(i+1, False) < green_speed(i+1) < FAST_CAP < FOX_WALK for i in range(len(LEVELS)))
assert all(troll_speed(i+1, s) <= FAST_CAP for i in range(len(LEVELS)) for s in (False, True))
class GreenTroll(Troll):
    def __init__(self, x, y):
        self.cols = ((25,75,25), (40,110,40), (60,140,58))
        super().__init__(x, y); self.fx, self.fy = float(x), float(y)
        self.hp = self.max_hp = GREEN_CANDY_HP if CANDY[0] else 1; self.hit_flash = 0   # tougher in Candyland
    def draw_face(self, eye_dx):
        self.image.fill((0,0,0,0)); self.image.blit(troll_face_img(self.cols, eye_dx), (0, 0))   # Oct 29 classic look
    def update(self, fox):
        if self.hit_flash > 0: self.hit_flash -= 1
        return mean_chase(self, fox, min(MEAN_CAP, MEAN_SPEEDUP*green_speed()*(2 if storm_on else 1)))   # the MEAN kind
    def _old_update(self, fox):
        if (round(self.fx), round(self.fy)) != self.rect.center: self.fx, self.fy = map(float, self.rect.center)   # got pushed
        self.moving = False
        sp = green_speed() * (2 if storm_on else 1)
        if self.bounce > 0:
            self.bounce -= 1; self.fx += self.bvec[0]*sp; self.fy += self.bvec[1]*sp
            self.rect.center = (round(self.fx), round(self.fy)); self.moving = True; self.step += 1; return
        if not can_see(self.rect.center, fox.rect.center):
            self.searching = True; self.draw_face(int(5*math.sin(pygame.time.get_ticks()/180))); return
        if self.searching: self.searching = False; self.draw_face(0)
        dx, dy = fox.rect.centerx-self.fx, fox.rect.centery-self.fy; d = math.hypot(dx, dy)
        if d > 5:
            nx, ny = self.fx + dx/d*sp, self.fy + dy/d*sp
            test = self.rect.copy(); test.center = (round(nx), round(ny))
            if test.colliderect(POND_SAFE): troll_bounce(self); return
            self.fx, self.fy = nx, ny; self.rect.center = (round(nx), round(ny))
            self.moving = True; self.step += 1

def draw_storm(cx, cy, players):
    global flash_t
    add = pygame.BLEND_RGB_ADD
    screen.blit(DARK_GLOW, (0, 0))
    view = screen.get_rect()
    for c in collectibles:   # faint halos on berries, sticks and stones
        sx, sy = c.rect.centerx-cx, c.rect.centery-cy
        if -30 < sx < WIDTH+30 and -30 < sy < HEIGHT+30:
            screen.blit(GLOW_ITEM.get(c.type, GLOW_ITEM["stone"]), (sx-20, sy-20), special_flags=add)
    st = STATUE_RECT.move(-cx, -cy)
    if st.inflate(200, 200).colliderect(view): screen.blit(GLOW_STATUE, (st.centerx-90, st.centery-90), special_flags=add)
    for h in houses:
        hx, hy = h.rect.x-cx, h.rect.y-cy
        if -150 < hx < WIDTH+30 and -150 < hy < HEIGHT+30:
            for wx in (20, 80):
                screen.blit(GLOW_WIN, (hx+wx+10-22, hy+69-22), special_flags=add)
                pygame.draw.rect(screen, (255,225,120), (hx+wx, hy+60, 20, 18), border_radius=3)   # lit windows
    r = CAVE_RECT.move(-cx, -cy); screen.blit(GLOW_CAVE, (r.centerx-46, r.bottom-80), special_flags=add)
    r = BERRY_CAVE_RECT.move(-cx, -cy); screen.blit(GLOW_BCAVE, (r.centerx-46, r.bottom-80), special_flags=add)
    r = POND_RECT.move(-cx, -cy)
    if r.inflate(300, 300).colliderect(view): screen.blit(GLOW_POND, (r.centerx-150, r.centery-150), special_flags=add)
    for t in trolls:   # bright glowing troll eyes
        ex, ey = t.rect.x-cx, t.rect.y+17-cy
        if -40 < ex < WIDTH+40 and -40 < ey < HEIGHT+40:
            for e in (26, 38):
                screen.blit(GLOW_EYE, (ex+e-14, ey-14), special_flags=add)
                pygame.draw.circle(screen, (255,200,80), (ex+e, ey), 4)
    if boss: boss.draw_eyes(cx, cy, glow=True)
    for pf in players:   # foxes glow warm and stay bright
        fx, fy = pf.rect.centerx-cx, pf.rect.centery-cy
        screen.blit(GLOW_FOX, (fx-48, fy-48), special_flags=add)
        draw_fox_world(pf, cx, cy)
    for b in bolts[:]:   # jagged cartoon bolts
        pygame.draw.lines(screen, (120,170,255), False, b[0], 11)
        pygame.draw.lines(screen, (230,240,255), False, b[0], 4)
        b[1] -= 1
        if b[1] <= 0: bolts.remove(b)
    if not bolts and random.random() < 0.035: bolts.append(_make_bolt()); flash_t = 6
    if flash_t > 0:
        FLASH.set_alpha(18*flash_t); screen.blit(FLASH, (0, 0)); flash_t -= 1
    t = pygame.time.get_ticks()
    bn = otext(font, "LIGHTNING! Trolls are super fast!", (255,240,120) if (t//250) % 2 else WHITE, (40,20,80), 3)
    screen.blit(bn, (WIDTH//2-bn.get_width()//2, 122))

# ================= TROLLS BOUNCE OFF THE FROG POND =================
POND_SAFE = POND_RECT.inflate(160, 160)   # trolls never come this close to the water: a fox at the pond is safe
# ================= MEAN TROLLS (green trolls + Candyland peppermint trolls, Faroe Oct 31) =================
TROLL_REACH = 180                 # regular trolls: arms reach out (and Grr) inside this distance
MEAN_NOTICE = int(1.5*TROLL_REACH)   # 270: mean trolls sniff a fox out even behind a tree this close, and reach from here
MEAN_SPEEDUP = 1.25               # mean trolls chase 25% faster...
MEAN_CAP = FAST_CAP           # ...but never faster than 0.95 x the fox's walk (even in a lightning storm): the fox can always run away
MEAN_MEMORY = 150                 # lost sight of the fox? keep running to where she was for 2.5 s before giving up
CROUCH_FRAMES, LUNGE_FRAMES, LUNGE_SPEED, LUNGE_COOLDOWN = 24, 11, FAST_CAP, 150   # "!" + crouch 0.4 s, then a short hop (slower than the fox; Nov 8: same ~88 px hop)
LUNGE_MIN, LUNGE_MAX = 90, 220
EX_FONT = pygame.font.Font(None, 64)
def is_mean(t): return isinstance(t, GreenTroll) or (CANDY[0] and isinstance(t, Troll))
def _mean_step(t, ux, uy, sp):
    nx, ny = t.fx + ux*sp, t.fy + uy*sp
    test = t.rect.copy(); test.center = (round(nx), round(ny))
    if test.colliderect(POND_SAFE): t.lunge = 0; troll_bounce(t); return   # same pond bounce as every troll
    t.fx, t.fy = nx, ny; t.rect.center = (round(nx), round(ny)); t.moving = True; t.step += 1
def mean_chase(t, fox, sp):
    if not hasattr(t, "fx") or (round(t.fx), round(t.fy)) != t.rect.center:   # got pushed (hit bump, pet, zone edge)
        t.fx, t.fy = map(float, t.rect.center); t.crouch = t.lunge = 0
    t.moving = False
    if t.bounce > 0:   # pond bounce or the Shoo Ball's push: still works on mean trolls
        t.crouch = t.lunge = 0; t.bounce -= 1; t.fx += t.bvec[0]*BOUNCE_SPEED; t.fy += t.bvec[1]*BOUNCE_SPEED
        t.rect.center = (round(t.fx), round(t.fy)); t.moving = True; t.step += 1; return
    if getattr(t, "lunge_cd", 0) > 0: t.lunge_cd -= 1
    fx_, fy_ = fox.rect.center; d = math.hypot(fx_ - t.fx, fy_ - t.fy)
    if getattr(t, "crouch", 0) > 0:   # telegraph: crouched with a "!" ... then LUNGE where the fox is now
        t.crouch -= 1
        if t.crouch == 0: dd = d or 1; t.lvec = ((fx_ - t.fx)/dd, (fy_ - t.fy)/dd); t.lunge = LUNGE_FRAMES
        return
    if getattr(t, "lunge", 0) > 0:
        t.lunge -= 1
        if t.lunge == 0: t.lunge_cd = LUNGE_COOLDOWN
        _mean_step(t, t.lvec[0], t.lvec[1], LUNGE_SPEED); return
    if d < MEAN_NOTICE or can_see(t.rect.center, fox.rect.center):
        t.last_seen = (fx_, fy_); t.memory = MEAN_MEMORY
        if t.searching: t.searching = False; t.draw_face(0)
        if LUNGE_MIN < d < LUNGE_MAX and getattr(t, "lunge_cd", 0) == 0 and fox.invuln == 0:
            t.crouch = CROUCH_FRAMES; return
        tx, ty = fx_, fy_
    elif getattr(t, "memory", 0) > 0:   # keeps hunting where she saw the fox
        t.memory -= 1; tx, ty = t.last_seen
        if math.hypot(tx - t.fx, ty - t.fy) < 8: t.memory = 0
    else:
        t.searching = True; t.draw_face(int(5*math.sin(pygame.time.get_ticks()/180))); hole_wander(t); return
    dx, dy = tx - t.fx, ty - t.fy; dd = math.hypot(dx, dy)
    if dd > 5: _mean_step(t, dx/dd, dy/dd, min(sp, dd - 4))   # never steps past her (no jiggling)
def troll_bounce(t):
    dx, dy = t.rect.centerx - POND_RECT.centerx, t.rect.centery - POND_RECT.centery
    d = math.hypot(dx, dy) or 1
    a = math.atan2(dy, dx) + random.uniform(-0.6, 0.6)
    t.bounce = 45; t.bvec = (math.cos(a), math.sin(a))

# ================= BOSS TROLL =================
boss = None
BOSS_ZONES = lambda: (VILLAGE_RECT, CAVE_RECT.inflate(80,80), BERRY_CAVE_RECT.inflate(80,80), POND_RECT.inflate(160,160), WARP_RECT.inflate(60,60))   # he bounces off the pond too
_BOSS = []
def _make_boss():
    s = pygame.Surface((160,160), pygame.SRCALPHA)
    BODY, HEAD = (60,140,50), (68,150,56)   # dark, scary troll green
    pygame.draw.circle(s, BODY, (80,108), 44)                                                  # huge body
    pygame.draw.ellipse(s, _light(BODY,30), (58,95,44,40))                                    # tummy
    pygame.draw.line(s, _dark(BODY,25), (64,104), (76,120), 3); pygame.draw.line(s, _dark(BODY,25), (92,100), (100,112), 3)   # scars
    for hx, d in ((48,-1), (112,1)):                                                           # big curly horns
        pygame.draw.polygon(s, (225,205,165), [(hx,40),(hx+d*28,6),(hx+d*34,0),(hx+d*14,40)])
        pygame.draw.polygon(s, (175,150,115), [(hx+d*20,24),(hx+d*30,6),(hx+d*34,0)])
    pygame.draw.polygon(s, HEAD, [(46,46),(18,36),(46,64)]); pygame.draw.polygon(s, HEAD, [(114,46),(142,36),(114,64)])   # ears
    pygame.draw.circle(s, HEAD, (80,55), 38)                                                   # head
    s = _outline(s, (35,90,30), 2)                                                             # Oct 29 style: flat colors, plain dark edge
    for side in (-1, 1):                                                                       # spiky angry brows
        pygame.draw.polygon(s, (45,100,35), [(80+side*6,42),(80+side*34,28),(80+side*30,36),(80+side*24,34),(80+side*20,40)])
    pygame.draw.polygon(s, (120,35,45), [(56,70),(104,70),(96,88),(64,88)])                     # big mouth
    for k in range(6):                                                                         # jagged teeth
        x = 58 + k*8
        pygame.draw.polygon(s, WHITE, [(x,70),(x+8,70),(x+4,79)])
        pygame.draw.polygon(s, WHITE, [(x+2,88),(x+8,88),(x+5,81)])
    pygame.draw.polygon(s, (240,235,220), [(56,72),(62,72),(59,58)]); pygame.draw.polygon(s, (240,235,220), [(98,72),(104,72),(101,58)])   # tusks
    return s
def _make_sword():
    s = pygame.Surface((40,170), pygame.SRCALPHA)
    pygame.draw.polygon(s, (205,210,225), [(14,130),(26,130),(26,20),(20,0),(14,20)])          # big blade
    pygame.draw.line(s, WHITE, (18,124), (18,18), 2)
    pygame.draw.rect(s, (120,40,40), (2,128,36,9), border_radius=4)                            # cross guard
    pygame.draw.rect(s, (80,50,30), (16,137,8,26), border_radius=3)                            # handle
    pygame.draw.circle(s, GOLD, (20,165), 5)
    return _outline(s)
_SWORD = {}
def sword_img(ang):
    k = int(ang // 3) * 3
    if k not in _SWORD:
        if "base" not in _SWORD: _SWORD["base"] = _make_sword()
        _SWORD[k] = pygame.transform.rotate(_SWORD["base"], k)
    return _SWORD[k], k
class Boss:
    def __init__(self):
        self.rect = pygame.Rect(0, 0, 110, 130)   # his giant body (sword and arms are just for looks)
        self.home = (VILLAGE_RECT.left - 220, VILLAGE_RECT.centery + 60)   # right outside the Fox Village entrance (the road)
        self.rage = False; self.chasing = False; self.steam = []
        self.rect.center = self.home; self.fx, self.fy = map(float, self.home)
        self.down = True; self.dir_x = -1; self.step = 0; self.moving = False
        self.hp = 3; self.hurt = 0; self.flash = 0; self.stagger = 0; self.charge = 0; self.svec = (0.0, 0.0)
        self.next_target()
    def dagger_hit(self, p):   # True when this hit beats him
        if self.hurt > 0: return False                        # ~0.8 s safe after each hit
        self.hp -= 1; self.hurt = 48; self.flash = 14
        ouches.append([self.rect.centerx, self.rect.top, 40])
        if self.hp <= 0: return True
        if self.hp == 1 and not self.rage:   # 2nd hit: he gets ANGRY and super fast for the rest of the fight
            self.rage = True; rage_banner[0] = 210
        dx, dy = self.rect.centerx - p[0], self.rect.centery - p[1]; d = math.hypot(dx, dy) or 1
        a = math.atan2(dy, dx) + random.choice((-0.785, 0.785))   # stumble backwards, diagonally left or right
        self.svec = (math.cos(a), math.sin(a)); self.stagger = 48; self.charge = 0; self.tilt_dir = random.choice((-1, 1))
        return False
    def next_target(self):
        """next guard post: pacing just outside Fox Village, mostly by the entrance (left side road) and the bottom"""
        V = VILLAGE_RECT
        for _ in range(40):
            side = random.choices(("left", "bottom", "top", "right"), (5, 4, 1, 1))[0]
            off = random.randint(140, 420)
            if side == "left": p = (V.left - off, random.randint(V.centery - 280, V.centery + 280))
            elif side == "right": p = (V.right + off, random.randint(V.top, V.bottom))
            elif side == "top": p = (random.randint(V.left, V.right), V.top - off)
            else: p = (random.randint(V.left - 300, V.right), V.bottom + off)
            r = self.rect.copy(); r.center = p
            if r.collidelist(BOSS_ZONES()) == -1 and GUARD_ZONE.contains(r) and math.hypot(p[0]-self.rect.centerx, p[1]-self.rect.centery) > 150:
                self.target = p; return
        self.target = self.home
    def bump_from(self, p):
        dx, dy = self.rect.centerx - p[0], self.rect.centery - p[1]; d = math.hypot(dx, dy) or 1
        self.fx += dx/d*120; self.fy += dy/d*120; self.rect.center = (int(self.fx), int(self.fy)); self.push_out()
    def push_out(self):
        for zone in BOSS_ZONES():
            if self.rect.colliderect(zone):
                gaps = {"left": self.rect.right - zone.left, "right": zone.right - self.rect.left,
                        "top": self.rect.bottom - zone.top, "bottom": zone.bottom - self.rect.top}
                side = min(gaps, key=gaps.get)
                if side == "left": self.rect.right = zone.left
                elif side == "right": self.rect.left = zone.right
                elif side == "top": self.rect.bottom = zone.top
                else: self.rect.top = zone.bottom
                self.fx, self.fy = map(float, self.rect.center)
                tr = self.rect.copy(); tr.center = self.target
                if tr.colliderect(zone) or zone == POND_SAFE: self.next_target()   # bounce away
        old = self.rect.center
        self.rect.clamp_ip(GUARD_ZONE)                  # he never wanders more than ~500 px from Fox Village
        self.rect.clamp_ip(pygame.Rect(0, 0, WORLD_W, WORLD_H))
        if self.rect.center != old: self.fx, self.fy = map(float, self.rect.center)
    def update(self, steps):
        if self.rage: sp = FAST_CAP if steps > 0 else 0   # ANGRY: his top speed (Nov 8: the fox can still just outrun him)
        else: sp = TROLL_CAP if steps > 0 else 0          # Nov 8: as fast as the quickest regular troll, still slower than the fox
        if self.rage and random.random() < 0.25:            # steam puffs from his head
            self.steam.append([self.rect.centerx + random.randint(-40, 40), self.rect.top + 10, 40])
        if self.hurt > 0: self.hurt -= 1
        if self.flash > 0: self.flash -= 1
        if self.stagger > 0:            # wobbly stumble backwards (can't catch anyone now)
            self.stagger -= 1; self.step += steps; self.moving = True
            self.fx += self.svec[0]*sp*0.9; self.fy += self.svec[1]*sp*0.9
            self.rect.center = (int(self.fx), int(self.fy)); self.push_out()
            if self.stagger == 0: self.charge = 90   # then CHARGE straight back at her for ~1.5 s
            return
        if self.charge > 0:
            self.charge -= 1
            tf = fox2 if (two_player and fox.out and not fox2.out) else fox   # never chases a ghost
            dx, dy = tf.rect.centerx-self.fx, tf.rect.centery-self.fy; d = math.hypot(dx, dy) or 1
            if d > 4: st_ = min(sp, d - 4); self.fx += dx/d*st_; self.fy += dy/d*st_   # never steps past her
            if dx: self.face = 1 if dx > 0 else -1
            self.step += steps; self.moving = sp > 0
            self.rect.center = (int(self.fx), int(self.fy)); self.push_out()
            if self.charge == 0: self.next_target()   # back to guarding the village
            return
        foxes = [pf for pf in [fox] + ([fox2] if two_player else []) if not pf.out]
        prey = [pf for pf in foxes if pf.rect.colliderect(GUARD_ZONE) and not pf.rect.colliderect(VILLAGE_RECT)]
        if prey:                                       # a fox came into his guard zone: CHASE her
            near = min(prey, key=lambda pf: math.hypot(pf.rect.centerx-self.fx, pf.rect.centery-self.fy))
            self.target = near.rect.center; self.chasing = True
        elif self.chasing:                             # she left: back to guarding
            self.chasing = False; self.next_target()
        dx, dy = self.target[0]-self.fx, self.target[1]-self.fy; d = math.hypot(dx, dy)
        self.moving = sp > 0
        if d <= max(sp, 4):
            self.fx, self.fy = map(float, self.target)
            if not self.chasing: self.next_target()
        else: self.fx += dx/d*sp; self.fy += dy/d*sp
        if dx: self.face = 1 if dx > 0 else -1
        self.step += steps
        self.rect.center = (int(self.fx), int(self.fy))
        self.push_out()
    def draw_eyes(self, cx, cy, glow=False):
        bx, by = self.rect.centerx-80-cx, self.rect.centery-85-cy + toon_boss_bob(self)
        pulse = 0.5 + 0.5*math.sin(pygame.time.get_ticks()/160)
        for ex in (66, 94):
            g = GLOW_BIGEYE if glow or pulse > 0.5 else GLOW_EYE
            screen.blit(g, (bx+ex-g.get_width()//2, by+52-g.get_height()//2), special_flags=pygame.BLEND_RGB_ADD)
            pygame.draw.ellipse(screen, (170,70,0), (bx+ex-9, by+44, 18, 16))
            pygame.draw.ellipse(screen, (255,140,0), (bx+ex-8, by+45, 16, 14))   # plain orange troll eye (Oct 29 style)
    def draw(self, cx, cy, players):
        global screen
        r0 = self.rect.move(-cx, -cy)
        if not r0.inflate(400, 400).colliderect(screen.get_rect()): return
        if self.rage:   # red-orange angry glow under him
            if not _RAGE_GLOW:
                g = pygame.Surface((300, 300), pygame.SRCALPHA)
                for k in range(15): pygame.draw.circle(g, (255, 90 + k*6, 30, 12), (150, 150), 150 - k*9)
                _RAGE_GLOW.append(g)
            pulse = 0.75 + 0.25*math.sin(pygame.time.get_ticks()/90)
            g = pygame.transform.smoothscale(_RAGE_GLOW[0], (int(300*pulse), int(300*pulse)))
            screen.blit(g, g.get_rect(center=(r0.centerx, r0.centery - 10)))
        if self.stagger > 0 or self.flash > 0:   # draw on a canvas so he can tilt / flash
            real = screen; W = 460
            canvas = pygame.Surface((W, W), pygame.SRCALPHA)
            ox, oy = self.rect.centerx - W//2, self.rect.centery - W//2
            screen = canvas
            try: self.draw_body(ox, oy, players)
            finally: screen = real
            if self.flash > 0: canvas.fill((110,160,110,0), special_flags=pygame.BLEND_RGBA_ADD)   # white-green flash
            ang = (14*math.sin(self.stagger*0.45)*getattr(self, 'tilt_dir', 1)) if self.stagger > 0 else 0
            img = pygame.transform.rotate(canvas, ang) if ang else canvas
            screen.blit(img, img.get_rect(center=r0.center))
        else:
            self.draw_body(cx, cy, players)
        t = pygame.time.get_ticks()
        if self.stagger > 0:   # dizzy stars
            for k in range(4):
                a = t/150 + k*1.571
                sx, sy = r0.centerx + math.cos(a)*48, r0.top - 22 + math.sin(a)*12
                pygame.draw.polygon(screen, (255,230,90), [(sx,sy-7),(sx+2,sy-2),(sx+7,sy),(sx+2,sy+2),(sx,sy+7),(sx-2,sy+2),(sx-7,sy),(sx-2,sy-2)])
        for st in self.steam[:]:   # angry steam puffs
            st[1] -= 2.2; st[2] -= 1
            if st[2] <= 0: self.steam.remove(st); continue
            pf = pygame.Surface((40, 40), pygame.SRCALPHA); rad = 8 + (40 - st[2])//3
            pygame.draw.circle(pf, (255, 245, 240, int(200*st[2]/40)), (20, 20), min(19, rad))
            screen.blit(pf, (st[0]-cx-20, st[1]-cy-20))
        if THEME[0] == "dungeon": draw_dragon_bar(self, cx, cy); return
        for k in range(3):     # 3 green hit-point pips over his head
            px = r0.centerx - 30 + k*30; py = r0.top - 62
            pygame.draw.circle(screen, (30,110,50), (px, py), 10)
            pygame.draw.circle(screen, (80,255,120) if k < self.hp else (60,80,65), (px, py), 8)
    def draw_body(self, cx, cy, players):
        if THEME[0] == "dungeon": return draw_dragon(self, cx, cy, players)   # Dragon Dungeon: the boss is a dragon
        if not _BOSS: _BOSS.append(_ready(_make_boss()))
        r = self.rect.move(-cx, -cy)
        if not r.inflate(400, 400).colliderect(screen.get_rect()): return
        t = pygame.time.get_ticks()
        bx, by = r.centerx-80, r.centery-85
        ph = self.step * 0.18
        for side in (-1, 1):            # big stomping legs
            a = ph + (0 if side < 0 else math.pi)
            lift = max(0.0, 9*math.sin(a)) if self.moving else 0
            sw = 7*math.cos(a) if self.moving else 0
            hx, hy = bx+80+side*22, by+138; fx, fy = hx+sw, by+168-lift
            pygame.draw.line(screen, (35,90,30), (hx, hy), (fx, fy), 22); pygame.draw.line(screen, (50,120,42), (hx, hy), (fx, fy), 16)
            pygame.draw.ellipse(screen, (30,75,25), (fx-22, fy-10, 44, 22)); pygame.draw.ellipse(screen, (45,110,38), (fx-20, fy-8, 40, 18))
        near = min(players, key=lambda pf: math.hypot(pf.rect.centerx-self.rect.centerx, pf.rect.centery-self.rect.centery))
        ddx, ddy = near.rect.centerx-self.rect.centerx, near.rect.centery-self.rect.centery; dist = math.hypot(ddx, ddy) or 1
        # left arm reaches for a close fox
        sx, sy = bx+40, by+100
        if dist < 400:
            reach = 30 + (400-dist)/400*80; hx, hy = sx + ddx/dist*reach, sy + ddy/dist*reach
        else: hx, hy = sx-16, sy+44
        pygame.draw.line(screen, (35,90,30), (sx, sy), (hx, hy), 22); pygame.draw.line(screen, (55,130,46), (sx, sy), (hx, hy), 16)
        pygame.draw.circle(screen, (35,90,30), (int(hx), int(hy)), 14); pygame.draw.circle(screen, (70,150,58), (int(hx), int(hy)), 12)
        # right arm swings the big sword side to side
        ang = 55*math.sin(t/190)
        sx, sy = bx+122, by+100; hx, hy = sx+30, sy+18
        pygame.draw.arc(screen, (230,240,255), (hx-130, hy-130, 260, 260), math.radians(90-55), math.radians(90+55), 3)   # swoosh arc
        img, k = sword_img(ang)
        rad = math.radians(k); off = 63   # handle sits in the hand, blade points away
        cxs, cys = hx - math.sin(rad)*off, hy - math.cos(rad)*off
        screen.blit(img, (cxs - img.get_width()//2, cys - img.get_height()//2))
        pygame.draw.line(screen, (35,90,30), (sx, sy), (hx, hy), 22); pygame.draw.line(screen, (55,130,46), (sx, sy), (hx, hy), 16)
        pygame.draw.circle(screen, (35,90,30), (int(hx), int(hy)), 14); pygame.draw.circle(screen, (70,150,58), (int(hx), int(hy)), 12)
        screen.blit(_BOSS[0], (bx, by + toon_boss_bob(self)))
        self.draw_eyes(cx, cy)
        n = tinyfont.render("BOSS TROLL", True, (255,90,60)); screen.blit(n, (r.centerx-n.get_width()//2, by-22))
_RAGE_GLOW = []
GUARD_ZONE = VILLAGE_RECT.inflate(1000, 1000)   # the boss patrols up to ~500 px around Fox Village
def boss_in(r):   # the boss's giant body is solid to foxes outside Fox Village
    return boss is not None and r.colliderect(boss.rect) and not r.colliderect(VILLAGE_RECT)

# Groups
fox = Fox()
# ---------- PLAYER 2 (only in two-player mode): a silver fox that moves with I J K L ----------
two_player = False
LEASH_X, LEASH_Y = 1000, 420   # how far apart the two foxes can get (so both stay on screen)
fox2 = Fox(colors=((215,215,225), (140,140,155)), keyset=(pygame.K_j, pygame.K_l, pygame.K_i, pygame.K_k), start=(int(600*WS)+80, WORLD_H - int(800*WS)))
fox2.sprint_keys = FOX2_SPRINT_KEYS   # Nov 8: fox 2 sprints with U (next to I J K L)
fox2.inventory = fox.inventory   # the two foxes share one bag
fox.leash, fox2.leash = fox2, fox
inside_fox2 = pygame.Rect(0, 0, 56, 42)
cave_fox2 = pygame.Rect(0, 0, 56, 42)
def p2_label(x, y):
    t = otext(tinyfont, "P2", (120,230,255)); screen.blit(t, (x - t.get_width()//2, y - 24))
collectibles = pygame.sprite.Group()
obstacles = pygame.sprite.Group()
trolls = pygame.sprite.Group()
axes = pygame.sprite.Group()
bombs = pygame.sprite.Group()

# Spirit fox
spirit = pygame.sprite.Sprite()
# Pet: a cute green ball buddy with a face
spirit.image = pygame.Surface((36,36), pygame.SRCALPHA)
pygame.draw.circle(spirit.image,(110,220,110),(18,18),17)
pygame.draw.circle(spirit.image,(40,140,40),(18,18),17,2)
for ex in (12,24):
    pygame.draw.circle(spirit.image,WHITE,(ex,15),5)
    pygame.draw.circle(spirit.image,(60,35,80),(ex+1,16),3)
    pygame.draw.circle(spirit.image,WHITE,(ex+2,14),1)
pygame.draw.circle(spirit.image,(255,150,170),(8,22),3)
pygame.draw.circle(spirit.image,(255,150,170),(28,22),3)
pygame.draw.arc(spirit.image,(90,60,110),(12,17,12,9),math.pi,2*math.pi,2)
pet_shoo = 0
spirit.rect = spirit.image.get_rect()
spirit_active = False

# Rain & fireworks
raindrops = []
rain_end = 0   # rain stops at this time (lasts 5 seconds)
fireworks = []

MOUNTAIN_BAND = 300   # the mountain strip along the top of the map

TASK = {"n": 0, "done_t": 0, "nag": 0}   # this run's task progress
level_banner = [0]; rage_banner = [0]
def level_time_ms():   # 3:00 on every level, except Berry Hunt (level 2) gets 4:00
    return LEVELS[level-1].get("time", TIME_LIMIT_MS // 1000) * 1000
def task_text(short=False):
    tk = LEVELS[level-1].get("task")
    if not tk: return "Task: Reach the golden statue"
    if tk[0] == "boss":
        return f"Task: Find the dagger and defeat {BOSS_NAME()}" if short else ("Find the dagger and defeat Smog" if THEME[0] == "dungeon" else "Find the dagger and defeat the boss")
    if tk[0] == "ruby":
        return f"Task: Find {tk[1]} Ruby Berries" if short else f"Ruby Berries {min(TASK['n'], tk[1])}/{tk[1]}"
    if tk[0] == "hearts":   # Level 4: be at the statue with at least 2 hearts
        return f"Task: Finish with at least {tk[1]} hearts left" if short else f"Finish with at least {tk[1]} hearts left  ({best_hearts()} now)"
    if tk[0] == "village":   # Level 7: get into Fox Village with at least 2 hearts
        return "Task: Reach the village with at least two hearts left." if short else f"Reach the village with {tk[1]}+ hearts  ({best_hearts()} now)"
    if tk[0] == "nohit":   # TASK["n"] counts troll hits (0 = still on track)
        L_ = LEVELS[level-1]
        return L_.get("task_msg", "Task: Try not to get hit by any trolls?") if short else f"{L_.get('hit_word', 'No troll hits!')} {TASK['n']} hits"
    return f"Task: Collect {tk[1]} berries" + ("" if short else f"  {min(TASK['n'], tk[1])}/{tk[1]}")
def dagger_found():   # step 1 of the finale task (stays ticked once Dorfghan gave it)
    if fox.inventory.get("dagger", 0) > 0: TASK["dagger"] = True
    return TASK.get("dagger", False)
def best_hearts():   # 2 players: the fox with the most hearts counts
    return max(fox.hearts, fox2.hearts) if two_player else fox.hearts
def task_done():
    tk = LEVELS[level-1].get("task")
    if tk and tk[0] in ("hearts", "village"): return best_hearts() >= tk[1]
    if tk and tk[0] == "boss": return dagger_found() and boss is None
    if tk and tk[0] == "nohit": return TASK["n"] == 0   # on track from the start, as long as no troll hits her
    return tk is None or TASK["n"] >= tk[1]
def task_berry():   # a berry picked from a tree / the ground / the Berry Cave (shop berries don't count)
    tk = LEVELS[level-1].get("task")
    if tk and tk[0] == "berries" and TASK["n"] < tk[1]:
        TASK["n"] += 1
        if TASK["n"] >= tk[1]: TASK["done_t"] = 180   # ding ding! sparkles
def task_gate():
    if task_done(): return True
    TASK["nag"] = 120; return False
def _check(x, y, col=WHITE):
    pygame.draw.lines(screen, col, False, [(x, y), (x+8, y+9), (x+24, y-10)], 5)
def draw_boss_task_panel():
    s1, s2 = dagger_found(), boss is None
    if s1 and s2:
        im = otext(tinyfont, "Task done! The village is open - run to the golden statue!", WHITE, (40,110,50))
        w = im.get_width() + 70; x = WIDTH//2 - w//2; y = 114
        cartoon_panel(x, y, w, 40, (120,215,120), (70,170,80), 235)
        _check(x+16, y+20); screen.blit(im, (x + 52, y + 20 - im.get_height()//2))
    else:
        rows = [("1. Find Dorfghan's dagger", s1), (f"2. Defeat {BOSS_NAME()}", s2)]
        ims = [otext(tinyfont, t, (230,255,225) if d else WHITE, (40,110,50) if d else (110,70,140)) for t, d in rows]
        w = max(i.get_width() for i in ims) + 80; x = WIDTH//2 - w//2; y = 114
        cartoon_panel(x, y, w, 70, (200,160,240), (150,110,210), 235)
        for k, ((t, d), im) in enumerate(zip(rows, ims)):
            ry = y + 18 + k*32
            pygame.draw.circle(screen, (120,215,120) if d else (235,215,250), (x+26, ry), 11)
            pygame.draw.circle(screen, (70,170,80) if d else (170,130,220), (x+26, ry), 11, 3)
            if d: pygame.draw.lines(screen, WHITE, False, [(x+20, ry), (x+25, ry+5), (x+33, ry-6)], 3)
            screen.blit(im, (x + 46, ry - im.get_height()//2))
    if TASK["nag"] > 0:
        ng = otext(font, "Finish your task first!", (255,200,120), (140,60,40), 3)
        screen.blit(ng, (WIDTH//2 - ng.get_width()//2, 230))
        if state == "playing": TASK["nag"] -= 1
def draw_task_panel():
    tk = LEVELS[level-1].get("task")
    if tk and tk[0] == "boss": draw_boss_task_panel(); return
    done = tk is not None and tk[0] not in ("nohit", "hearts", "village") and task_done()   # the no-hit + hearts tasks just show their counter
    txt = "Task done! Now run to the golden statue!" if done else task_text()
    im = otext(tinyfont, txt, WHITE, (40,110,50) if done else (110,70,140))
    w = im.get_width() + (70 if done else 40); x = WIDTH//2 - w//2; y = 114
    cartoon_panel(x, y, w, 40, (120,215,120) if done else (200,160,240), (70,170,80) if done else (150,110,210), 235)
    if done:   # check mark
        pygame.draw.lines(screen, WHITE, False, [(x+16, y+20), (x+24, y+29), (x+40, y+10)], 5)
        screen.blit(im, (x + 52, y + 20 - im.get_height()//2))
    else:
        screen.blit(im, (x + 20, y + 20 - im.get_height()//2))
    if TASK["done_t"] > 0:   # sparkle chime
        k = TASK["done_t"]; t = pygame.time.get_ticks()
        for j in range(10):
            a = j*0.628 + t/300.0; rr = 40 + (180 - k)*0.8
            sx, sy = WIDTH//2 + math.cos(a)*rr*3, y + 20 + math.sin(a)*rr*0.5
            col = (255,240,120) if j % 2 else (190,255,200)
            pygame.draw.line(screen, col, (sx-6, sy), (sx+6, sy), 2); pygame.draw.line(screen, col, (sx, sy-6), (sx, sy+6), 2)
        ch = otext(font, "Ding ding! Task done!", (255,245,150), (60,120,60), 3)
        screen.blit(ch, (WIDTH//2 - ch.get_width()//2, y + 50 - (180-k)//6))
        if state == "playing": TASK["done_t"] -= 1
    if TASK["nag"] > 0:
        hk = tk and tk[0] == "hearts"
        vk = tk and tk[0] == "village"
        ng = otext(font, f"You need {tk[1]} hearts to get into the village!" if vk else f"You need {tk[1]} hearts to win!" if hk else "Finish your task first!", (255,200,120), (140,60,40), 3)
        screen.blit(ng, (WIDTH//2 - ng.get_width()//2, 230))
        if state == "playing": TASK["nag"] -= 1
def draw_level_banner():
    if level_banner[0] <= 0: return
    if state == "playing": level_banner[0] -= 1
    finale = LEVELS[level-1].get("finale")
    lines = [(level_title(level), font, GOLD), (task_text(short=True), tinyfont, WHITE)]
    if finale: lines.append((f"Fox Village is locked until {BOSS_NAME()} is beaten!", tinyfont, (255,190,150)))
    h = 40 + sum(f.get_height() + 10 for _, f, _ in lines)
    cartoon_panel(WIDTH//2 - 420, 175, 840, h, (255,150,200) if finale else (125,90,195), (190,90,190) if finale else (85,60,150), 225)
    y = 195
    for txt, f, col in lines:
        im = otext(f, txt, col, (90,50,110), 3 if f is font else 2)
        screen.blit(im, (WIDTH//2 - im.get_width()//2, y)); y += im.get_height() + 10
def draw_dust(cx, cy):
    for d in dust[:]:
        d[2] -= 1
        if d[2] <= 0: dust.remove(d); continue
        pf = pygame.Surface((30, 30), pygame.SRCALPHA)
        pygame.draw.circle(pf, d[3] + (int(170*d[2]/22),), (15, 15), max(3, min(14, 4 + (22 - d[2])//2)))
        screen.blit(pf, (d[0]-cx-15, d[1]-cy-15 - (22 - d[2])//3))
def draw_power(cx, cy, players):
    t = pygame.time.get_ticks()
    for pf in players:
        x, top = pf.rect.centerx - cx, pf.rect.top - cy
        texts = []
        if pf.meat_t > 0:   # speed lines behind her
            d = pf.direction
            for k in range(4):
                off = (k - 1.5)*9; px, py = -d.y*off, d.x*off
                L = 22 + (t//40 + k*7) % 18
                sx, sy = pf.rect.centerx - cx - d.x*30 + px, pf.rect.centery - cy - d.y*30 + py
                pygame.draw.line(screen, (255,250,235), (sx, sy), (sx - d.x*L, sy - d.y*L), 3)
            texts.append((f"Meat power! Super speed! {pf.meat_t//60 + 1}", (255,215,140), (150,70,30)))
        if pf.dizzy > 0:    # stars circling her head
            for k in range(5):
                a = t/160.0 + k*1.2566
                sx, sy = x + math.cos(a)*26, top - 6 + math.sin(a)*8
                col = ((255,230,90), (255,150,220), (150,220,255))[k % 3]
                pygame.draw.polygon(screen, col, [(sx,sy-6),(sx+1.8,sy-1.8),(sx+6,sy),(sx+1.8,sy+1.8),(sx,sy+6),(sx-1.8,sy+1.8),(sx-6,sy),(sx-1.8,sy-1.8)])
            texts.append((f"Whoa! So dizzy! {pf.dizzy//60 + 1}", (235,200,255), (110,60,150)))
        y = top - 22
        for txt, col, oc in texts:
            im = otext(tinyfont, txt, col, oc)
            y -= im.get_height() + 2
            screen.blit(im, (x - im.get_width()//2, y))
    if rage_banner[0] > 0:
        if state == "playing": rage_banner[0] -= 1
        cartoon_panel(WIDTH//2 - 400, 150, 800, 90, (255,140,90), (210,70,60), 225)
        im = otext(font, f"{BOSS_NAME(True)} is ANGRY! Super fast!", (255,240,200), (150,40,30), 3)
        screen.blit(im, (WIDTH//2 - im.get_width()//2, 195 - im.get_height()//2))
def special_spot(st, meat):
    """a random open outdoor spot (never in the mountains, village, caves, pond, warp, or near the start)"""
    bad = [VILLAGE_RECT.inflate(600, 600), CAVE_RECT.inflate(600, 600), BERRY_CAVE_RECT.inflate(600, 600),
           POND_RECT.inflate(600, 600), WARP_RECT.inflate(600, 600), WARP_LAND.inflate(300, 300), POND_SAFE]
    for _ in range(4000):
        x = random.randint(300, WORLD_W-300); y = random.randint(ROCK_BAND+150, WORLD_H-300)
        r = pygame.Rect(0, 0, 44, 44); r.center = (x, y)
        if r.collidelist(bad) != -1 or r.collidelist(POND_BLOCKS) != -1: continue
        if math.hypot(x-st[0], y-st[1]) < 800*WS: continue
        if meat and (math.hypot(x-CAVE_RECT.centerx, y-CAVE_RECT.centery) < 1500*WS or math.hypot(x-WARP_DEST[0], y-WARP_DEST[1]) < 1500*WS): continue
        if any(o.rect.inflate(40, 40).colliderect(r) for o in obstacles): continue
        if any(c.rect.colliderect(r) for c in collectibles): continue
        return x, y
    return None
N_GOLDEN = 2   # golden berries per original-size map (the old scatter made ~2): x AREA = 4 on the big map
def golden_spot(st, far, pad):
    """an open, reachable outdoor spot: not in water, obstacles, caves, the warp, the village (locked on 11) or mountains"""
    bad = [VILLAGE_RECT.inflate(pad, pad), CAVE_RECT.inflate(pad, pad), BERRY_CAVE_RECT.inflate(pad, pad),
           POND_SAFE.inflate(pad//2, pad//2), WARP_RECT.inflate(pad, pad), WARP_LAND.inflate(pad, pad)]
    for _ in range(3000):
        x = random.randint(300, WORLD_W-300); y = random.randint(ROCK_BAND+150, WORLD_H-300)
        r = pygame.Rect(0, 0, 44, 44); r.center = (x, y)
        if r.collidelist(bad) != -1 or r.collidelist(POND_BLOCKS) != -1: continue
        if math.hypot(x-st[0], y-st[1]) < far: continue
        if any(o.rect.inflate(30, 30).colliderect(r) for o in obstacles): continue
        if any(c.rect.colliderect(r) for c in collectibles): continue
        return x, y
    return None
def place_golden(st):   # golden berries (speed boost) on EVERY level, always at least one
    n = 0
    for _ in range(round(N_GOLDEN*AREA)):
        p = golden_spot(st, 600*WS, 300)
        if p: collectibles.add(Collectible(p[0], p[1], "golden_berry")); n += 1
    for far, pad in ((300, 150), (0, 60)):   # guarantee: relax the rules until one fits
        if n: break
        p = golden_spot(st, far, pad)
        if p: collectibles.add(Collectible(p[0], p[1], "golden_berry")); n += 1
    if not n:   # last resort: right beside the start, on open ground
        for dx, dy in ((260, 0), (-260, 0), (0, 260), (0, -260), (380, 180), (-380, 180)):
            r = pygame.Rect(0, 0, 44, 44); r.center = (st[0]+dx, st[1]+dy)
            if not any(o.rect.colliderect(r) for o in obstacles):
                collectibles.add(Collectible(r.centerx, r.centery, "golden_berry")); n += 1; break
    return n
def place_specials(st):
    for k in range(5):
        meat = k >= 3
        p = special_spot(st, meat)
        if p: collectibles.add(Collectible(p[0], p[1], random.choice(("meat_steak", "meat_drum")) if meat else "mushroom"))
RUBY_FAR = 1500   # no Ruby Berry within this many px of the start
ruby_pops = []    # [x, y, frames, text]
def place_rubies(st):
    tk = LEVELS[level-1].get("task")
    if not tk or tk[0] != "ruby": return
    placed = []
    for gap in (2600, 2000, 1400, 900, 0):   # spread them out across the map
        tries = 0
        while len(placed) < tk[1] and tries < 60:
            tries += 1
            p = special_spot(st, False)
            if not p or math.hypot(p[0]-st[0], p[1]-st[1]) < RUBY_FAR: continue
            if any(math.hypot(p[0]-q[0], p[1]-q[1]) < gap for q in placed): continue
            placed.append(p); collectibles.add(Collectible(p[0], p[1], "ruby"))
        if len(placed) >= tk[1]: break
def draw_rubies(cx, cy):   # twinkles on each Ruby Berry + the 'Ruby Berry! 3/8' pop-ups
    t = pygame.time.get_ticks()
    for c in collectibles:
        if c.type != "ruby": continue
        sx, sy = c.rect.centerx - cx, c.rect.centery - cy
        if not (-40 < sx < WIDTH+40 and -40 < sy < HEIGHT+40): continue
        for k in range(3):
            ph = (t/300.0 + k*2.1 + c.rect.x*0.01) % 6.283
            r = int(2 + 4*max(0.0, math.sin(ph)))
            if r <= 2: continue
            px, py = sx + int(18*math.cos(k*2.1 + t/900.0)), sy - 6 + int(14*math.sin(k*2.1 + t/900.0))
            pygame.draw.line(screen, (255,235,240), (px-r, py), (px+r, py), 2)
            pygame.draw.line(screen, (255,235,240), (px, py-r), (px, py+r), 2)
            pygame.draw.circle(screen, (255,120,150), (px, py), 1)
    for pp in ruby_pops[:]:
        im = otext(font, pp[3], (255,120,140), (120,20,40), 3)
        screen.blit(im, (pp[0]-cx-im.get_width()//2, pp[1]-cy-60-(90-pp[2])//2))
        if state == "playing": pp[2] -= 1
        if pp[2] <= 0: ruby_pops.remove(pp)
def team_out():   # 1 player: out of hearts. 2 players: BOTH foxes are ghosts
    return (fox.out and fox2.out) if two_player else fox.hearts <= 0
def knock_out(pf):   # 2 players: a fox with no hearts left becomes a little ghost and sits out
    if two_player and pf.hearts <= 0 and not pf.out:
        pf.hearts = 0; pf.out = True; pf.swimming = False; pf.invuln = 0; pf.ko_t = 240
        for _ in range(3): splash_puff(pf.rect.centerx, pf.rect.centery)
_GHOST = {}
def ghost_image(pf):   # pale, see-through fox with a little golden halo
    key = (id(pf), pf.face_left)
    if key not in _GHOST:
        g = pf.frames[0].copy()
        g.fill((200,215,255,0), special_flags=pygame.BLEND_RGBA_MAX)       # pale blue-white
        g.fill((255,255,255,140), special_flags=pygame.BLEND_RGBA_MULT)    # see-through
        pygame.draw.ellipse(g, (255,225,90), (36, 0, 18, 6), 2)            # halo
        _GHOST[key] = pygame.transform.flip(g, True, False) if pf.face_left else g
    return _GHOST[key]
def ghost_step():   # the ghost floats gently behind the fox who is still playing (in every room)
    if not two_player: return
    t = pygame.time.get_ticks()
    for pf, other, rr in ((fox, fox2, (cave_fox, cave_fox2, inside_fox, inside_fox2)), (fox2, fox, (cave_fox2, cave_fox, inside_fox2, inside_fox))):
        if not pf.out: continue
        if pf.ko_t > 0 and state == "playing": pf.ko_t -= 1
        if not other.out and state in ("playing", "cave", "berry_cave", "inside", "cafe") and not crafting_open:
            if state == "playing": me, lead = pf.rect, other.rect
            elif state in ("cave", "berry_cave"): me, lead = rr[0], rr[1]
            else: me, lead = rr[2], rr[3]
            tx = lead.x + (60 if other.face_left else -60); ty = lead.y - 30 + int(6*math.sin(t/300))
            me.x = round(me.x + (tx - me.x)*0.08); me.y = round(me.y + (ty - me.y)*0.08)
        pf.image = ghost_image(pf)
def draw_ko_msg():
    for pf, nm in ((fox, "P1"), (fox2, "P2")):
        if two_player and pf.out and pf.ko_t > 0:
            other = "P2" if nm == "P1" else "P1"
            m = otext(font, f"Oh no! {nm} is a little ghost now. Keep going, {other}!", (220,230,255), (70,80,150), 2)
            screen.blit(m, (WIDTH//2 - m.get_width()//2, HEIGHT - 120))
_HEARTS = {}
def heart_img(col, big=True):
    """anime HUD heart (same spot + size as before): 2-tone cel shading, clean outline, shine + sparkle"""
    key = (col, big)
    if key not in _HEARTS:
        k = 1.0 if big else 0.7; r = 10*k
        def pts(dx, dy):
            return ((4+9*k+dx, 3+10*k+dy), (4+27*k+dx, 3+10*k+dy), [(4-1+dx, 3+13*k+dy), (4+37*k+dx, 3+13*k+dy), (4+18*k+dx, 3+36*k+dy)])
        s = pygame.Surface((int(44*k)+6, int(42*k)+6), pygame.SRCALPHA)
        def heart(surf, c, dx=0, dy=0, rr=r):
            a, b, tri = pts(dx, dy)
            pygame.draw.circle(surf, c, a, rr); pygame.draw.circle(surf, c, b, rr); pygame.draw.polygon(surf, c, tri)
        heart(s, _dark(col, 45))                                                   # shadow tone
        lit = pygame.Surface(s.get_size(), pygame.SRCALPHA); heart(lit, col, -2, -3)
        m = pygame.Surface(s.get_size(), pygame.SRCALPHA); heart(m, (255,255,255))
        lit.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN); s.blit(lit, (0, 0))
        s = _outline(s, _dark(col, 110), 2 if big else 1)
        pygame.draw.ellipse(s, _light(col, 95), (4+3*k, 3+4*k, 8*k, 5*k))         # shine
        pygame.draw.circle(s, WHITE, (int(4+25*k), int(3+7*k)), max(1, int(2*k)))  # little sparkle
        pygame.draw.ellipse(s, WHITE, (int(4+4*k), int(3+5*k), max(2, int(5*k)), max(2, int(3*k))))   # kawaii glossy shine
        _glint4(s, int(4+30*k), int(3+6*k), max(2, int(4*k)))
        _HEARTS[key] = s.convert_alpha()
    return _HEARTS[key]
def draw_p2_hearts():   # 2 players: P2's own heart row (blue), under the HUD bar
    if not two_player: return
    nh = max(4, min(MAX_HEARTS, fox2.hearts)); x0, y0 = 16, 98
    hl = otext(tinyfont, f"Hearts left: {hearts_left(fox2)}", (220,230,255), (30,40,90), 1)
    w = 44 + nh*30 + (70 if fox2.out else 0) + hl.get_width() + 12
    bgp = pygame.Surface((w, 34), pygame.SRCALPHA); pygame.draw.rect(bgp, (40,30,70,160), bgp.get_rect(), border_radius=12); screen.blit(bgp, (x0, y0))
    screen.blit(otext(tinyfont, "P2", (150,200,255), (30,40,90), 2), (x0 + 8, y0 + 5))
    for i in range(nh):
        hx, hy = x0 + 44 + i*30, y0 + 7
        col = (90,160,255) if i < fox2.hearts else (175,180,205)
        screen.blit(heart_img(col, False), (hx-4, hy-3))   # anime heart, same spot
    if fox2.out: screen.blit(otext(tinyfont, "ghost", (220,230,255), (70,80,150), 1), (x0 + 44 + nh*30 + 4, y0 + 5))
    screen.blit(hl, (x0 + 44 + nh*30 + (70 if fox2.out else 0) + 4, y0 + 6))   # P2's own hearts-left count

# ================= LEVEL THEMES (Faroe Oct 31): 6 snowy mountains, 8 space, 9 desert, 10 Candyland, 11 dungeon =================
THEME = [None]          # set by new_game from LEVELS[...]["theme"]
THEME_DECOR = []        # [kind, x, y, v] world decorations (looks only, never solid)
THEME_HOLES = []        # desert burrows (scorpions live here)
_TH_CACHE = {}
def _th_glint(surf, x, y, r):   # tiny 4-point sparkle
    pygame.draw.line(surf, (255,255,255), (x-r, y), (x+r, y), 1); pygame.draw.line(surf, (255,255,255), (x, y-r), (x, y+r), 1)
def _th_c(key, make):
    if key not in _TH_CACHE: _TH_CACHE[key] = make()
    return _TH_CACHE[key]
def theme_tile():   # the 240x240 ground tile for this level (the normal grass everywhere else)
    th = THEME[0]
    if th == "candy": return candy_tile()
    if th in ("space", "desert", "dungeon", "snow"): return _th_c(("tile", th), lambda: _make_theme_tile(th))
    return GRASS_TILE
def _make_theme_tile(th):
    N = TILE*6; s = pygame.Surface((N, N)); rng = random.Random(77)
    if th == "space":   # Faroe Nov 2: deep open space - dark blue/purple with 8-bit pixel stars (looks only)
        s.fill((14,10,34))
        for _ in range(46):   # darker / purpler pixel blocks give it depth
            s.fill(rng.choice(((20,12,48), (22,16,56), (10,8,26), (16,14,44))), (rng.randrange(0, N, 8), rng.randrange(0, N, 8), 8, 8))
        for _ in range(90): s.fill(rng.choice(((120,120,170), (90,90,140), (150,140,200))), (rng.randrange(N), rng.randrange(N), 1, 1))
        for _ in range(22): s.fill(rng.choice(((230,230,255), (200,220,255), (255,235,200))), (rng.randrange(N-2), rng.randrange(N-2), 2, 2))
        for _ in range(3):   # a few bright plus-shaped stars
            x, y = rng.randrange(6, N-6), rng.randrange(6, N-6)
            s.fill((150,160,230), (x-4, y, 10, 2)); s.fill((150,160,230), (x, y-4, 2, 10)); s.fill((255,255,255), (x-1, y-1, 4, 4))
    elif th == "desert":   # warm sand with dune bands and wind ripples
        for y in range(N):
            k = math.sin(y*2*math.pi/N*2)
            pygame.draw.line(s, (int(232+10*k), int(198+10*k), int(136+8*k)), (0, y), (N, y))
        for row in range(0, N, 16):   # little ripple lines (they wrap, so the tile repeats cleanly)
            pts = [(x, row + 5*math.sin(x*2*math.pi/N*3 + row)) for x in range(0, N+1, 8)]
            pygame.draw.lines(s, (214,176,116), False, pts, 2)
            pygame.draw.lines(s, (246,220,166), False, [(x, y-2) for x, y in pts], 1)
        for _ in range(80): pygame.draw.circle(s, rng.choice(((200,160,100), (250,228,180))), (rng.randrange(N), rng.randrange(N)), 1)
    elif th == "dungeon":   # dark stone bricks
        s.fill((44,40,54))
        for r in range(N//24):
            off = 20 if r % 2 else 0
            for c in range(-1, N//40 + 1):
                x, y = c*40 + off, r*24; v = rng.randint(-8, 8)
                pygame.draw.rect(s, (72+v, 68+v, 84+v), (x+2, y+2, 37, 21), border_radius=3)
                pygame.draw.line(s, (90+v, 86+v, 104+v), (x+4, y+3), (x+36, y+3), 2)       # top light edge
                if rng.random() < 0.15: pygame.draw.lines(s, (48,44,58), False, [(x+10, y+6), (x+16, y+12), (x+13, y+19)], 1)   # crack
        for _ in range(25): pygame.draw.circle(s, (60,90,60), (rng.randrange(N), rng.randrange(N)), rng.randint(1, 3))   # moss
    else:   # snow: white-blue snowy ground
        s.fill((232,240,252))
        for _ in range(40):
            x, y, w = rng.randrange(N), rng.randrange(N), rng.randint(30, 80)
            pygame.draw.ellipse(s, (214,226,246), (x-w//2, y-w//6, w, w//3))
            pygame.draw.ellipse(s, (244,248,255), (x-w//2+4, y-w//6-3, w-8, w//4))
        for _ in range(60): pygame.draw.circle(s, (255,255,255), (rng.randrange(N), rng.randrange(N)), 1)
    return s.convert()
def obst_prefix():
    return {"candy": "c_", "space": "s_", "desert": "d_", "dungeon": "g_", "snow": "y_"}.get(THEME[0], "")
def _theme_obstacle(typ, v):   # same sizes as the normal tree (70x90) and rock (55x55), so the hitboxes match
    th, kind = typ[0], typ[2:]
    if kind == "tree":
        s = pygame.Surface((70,90), pygame.SRCALPHA)
        if th == "s":   # glowy crystal plant
            cA, cB = [((120,230,255), (190,120,255)), ((190,120,255), (120,255,200)), ((255,140,220), (120,230,255))][v]
            g = pygame.Surface((70,90), pygame.SRCALPHA)
            for k in range(6): pygame.draw.circle(g, cA + (18,), (35,40), 34 - k*4)
            s.blit(g, (0, 0))
            pygame.draw.ellipse(s, (80,70,105), (14,78,42,11))
            for (bx, by, h, w, c) in ((35,84,64,14,cA), (20,84,40,10,cB), (50,84,46,11,cB), (28,84,30,8,cA), (44,84,26,8,cA)):
                pts = [(bx-w//2, by), (bx-w//2+2, by-h+12), (bx, by-h), (bx+w//2-2, by-h+12), (bx+w//2, by)]
                pygame.draw.polygon(s, c, pts); pygame.draw.polygon(s, _light(c, 70), [(bx-w//2+3, by-2), (bx-w//2+4, by-h+13), (bx, by-h+3), (bx-1, by-2)])
                pygame.draw.polygon(s, _dark(c, 80), pts, 2)
            for (px, py) in ((35,22), (20,46), (50,40)): _th_glint(s, px, py, 3)
        elif th == "d":   # cactus (berries still grow next to it)
            G, D, Lt = (80,160,80), (40,110,55), (130,200,110)
            pygame.draw.ellipse(s, (200,160,100), (14,80,42,9))
            pygame.draw.rect(s, G, (27,14,16,72), border_radius=8)
            if v != 1: pygame.draw.rect(s, G, (12,38,10,26), border_radius=5); pygame.draw.rect(s, G, (12,58,18,8), border_radius=4)
            if v != 2: pygame.draw.rect(s, G, (48,30,10,24), border_radius=5); pygame.draw.rect(s, G, (40,48,18,8), border_radius=4)
            pygame.draw.line(s, Lt, (31,20), (31,82), 3)
            for yy in range(22, 82, 9):
                for xx in (29, 41): pygame.draw.line(s, (240,240,210), (xx, yy), (xx + (-3 if xx < 35 else 3), yy-2), 1)
            s = _outline(s, D, 2)
            c = [(255,120,170), (255,220,80), (255,150,90)][v]
            for a in range(5): pygame.draw.circle(s, c, (int(35 + 4*math.cos(a*1.257)), int(13 + 4*math.sin(a*1.257))), 3)
            pygame.draw.circle(s, (255,240,150), (35,13), 2)
        elif th == "g":   # dungeon: stone pillar (Nov 3: a little lighter + warmer than the floor so it is easy to see) (or a broken bit of wall)
            if v < 2:
                pygame.draw.ellipse(s, (30,26,38), (10,78,50,12))
                pygame.draw.rect(s, (108,98,96), (18,14,34,70), border_radius=4)
                pygame.draw.rect(s, (132,120,114), (18,14,12,70), border_radius=4)
                pygame.draw.rect(s, (122,110,106), (12,8,46,12), border_radius=3); pygame.draw.rect(s, (122,110,106), (12,76,46,10), border_radius=3)
                for yy in (32, 50, 66): pygame.draw.line(s, (78,68,70), (19, yy), (51, yy), 2)
                if v == 1: pygame.draw.lines(s, (76,66,68), False, [(40,22), (34,34), (40,44)], 2)
            else:
                for r_ in range(4):
                    for c_ in range(3 - (r_ == 0)):
                        x, y = 4 + c_*22 + (11 if r_ % 2 else 0), 20 + r_*16
                        pygame.draw.rect(s, (106 + 6*((r_+c_) % 2), 96, 94), (x, y, 21, 15), border_radius=3)
                        pygame.draw.line(s, (130,118,112), (x+2, y+2), (x+18, y+2), 2)
            s = _outline(s, (30,26,40), 2)
        else:   # "y": snowy pine tree
            pygame.draw.rect(s, (110,70,40), (31,70,9,18), border_radius=3)
            for k, (y0, w) in enumerate(((50, 60), (32, 48), (14, 34))):
                pts = [(35 - w//2, y0 + 26), (35, y0 - 6), (35 + w//2, y0 + 26)]
                pygame.draw.polygon(s, [(40,110,80), (35,100,75), (45,120,85)][v], pts)
                pygame.draw.polygon(s, (250,252,255), [(35 - w//2 + 8, y0 + 20), (35, y0 - 4), (35 + w//2 - 8, y0 + 20), (35, y0 + 12)])   # snow cap
            s = _outline(s, (30,70,70), 2)
            _th_glint(s, 30, 12, 3)
        return s
    s = pygame.Surface((55,55), pygame.SRCALPHA)
    if th == "s":   # Faroe Nov 2: a FLOATING ASTEROID (same 55x55 box + same hitbox as the old moon rock)
        rr = random.Random(31 + v); pts = []
        for k in range(11):
            a = k*2*math.pi/11; r = 20 + rr.randint(-3, 3)
            pts.append((27 + r*math.cos(a), 24 + r*0.9*math.sin(a)))
        base = (128,118,150) if v == 0 else (114,106,138)
        pygame.draw.polygon(s, base, pts)
        pygame.draw.polygon(s, _light(base, 28), [(p[0] + 1, p[1] + 1) for p in pts[6:10]] + [(27,24)])   # lit top-left side
        for (x, y, r) in ((19,26,5), (35,20,4), (30,34,4)):
            pygame.draw.circle(s, _dark(base, 34), (x, y), r); pygame.draw.circle(s, _light(base, 40), (x-1, y-1), r, 1)
        s = _outline(s, (60,54,86), 2)
        pygame.draw.ellipse(s, (6,4,20,70), (14,50,28,5))   # faint shadow far below = it floats
    elif th == "d":   # sandstone with layers
        pygame.draw.ellipse(s, (205,140,85), (2,8,51,44))
        for y, c in ((18, (225,165,105)), (28, (190,120,70)), (38, (220,155,95))): pygame.draw.line(s, c, (8, y), (47, y + (3 if v else -2)), 4)
        pygame.draw.ellipse(s, (240,190,130), (12,12,16,7))
        s = _outline(s, (140,85,50), 2)
    elif th == "g":   # pile of rubble
        for (x, y, w, h) in ((4,26,24,22), (24,22,26,26), (14,10,22,18)):
            pygame.draw.rect(s, (110 + v*6, 100, 98), (x, y, w, h), border_radius=4); pygame.draw.line(s, (134,122,116), (x+3, y+3), (x+w-4, y+3), 2)
        pygame.draw.ellipse(s, (230,225,200), (36,44,14,6))   # a little bone
        s = _outline(s, (30,26,40), 2)
    else:   # icy rock
        pygame.draw.ellipse(s, (170,200,230) if v == 0 else (150,185,220), (2,8,51,44))
        pygame.draw.ellipse(s, (250,252,255), (6,6,43,18))
        pygame.draw.line(s, (230,245,255), (16,30), (24,38), 3)
        s = _outline(s, (90,120,160), 2); _th_glint(s, 40, 26, 3)
    return s
# ---- themed trolls (same 64x64 picture, same hitbox) ----
def troll_cols(t):
    th = THEME[0]; mean = isinstance(t, GreenTroll)
    if th == "space": return ((20,80,30), (80,190,80), (140,230,120)) if mean else ((70,30,100), (150,80,200), (190,130,235))
    if th == "desert": return ((130,50,15), (225,110,45), (245,160,90)) if mean else ((120,70,20), (215,155,80), (240,190,120))
    if th == "snow": return ((90,110,150), (205,218,236), (232,240,250)) if mean else ((120,140,170), (238,242,250), (255,255,255))
    if th == "dungeon" and not mean: return ((38,38,48), (84,84,98), (112,112,128))
    return getattr(t, "cols", ((70,70,70), (120,120,120), (150,150,150)))
def theme_troll_img(t):
    th = THEME[0]
    if th == "candy": return candy_troll_image(t)
    if th not in ("space", "desert", "snow", "dungeon"): return t.image
    mean = isinstance(t, GreenTroll)
    eye = int(5*math.sin(pygame.time.get_ticks()/180)) if t.searching else 0
    if th == "dungeon":
        if mean: return t.image
        def stone():   # dark gray stone troll: same picture, turned to cool gray stone
            im = t.image.copy(); im.fill((150,150,170,255), special_flags=pygame.BLEND_RGBA_MULT)
            g = pygame.Surface(im.get_size(), pygame.SRCALPHA); g.fill((18,18,26,0)); im.blit(g, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
            return im
        return stone()   # (cheap 64x64 copy, keeps the moving eyes)
    return _th_c(("troll", th, mean, eye), lambda: _make_theme_troll(th, mean, eye, troll_cols(t)))
def _googly(s, x, y, r, dx):
    q = max(-(r//2), min(r//2, dx))
    pygame.draw.circle(s, (40,30,50), (x, y), r + 1); pygame.draw.circle(s, WHITE, (x, y), r)
    pygame.draw.circle(s, (20,20,30), (x + q, y + 1), max(2, r//2))
    pygame.draw.circle(s, WHITE, (x + q - 1, y - 1), 1)
def _make_theme_troll(th, mean, eye, cols):
    line, body, light = cols
    s = pygame.Surface((64,64), pygame.SRCALPHA)
    if th == "space":   # silly cartoon alien
        for ax in (20, 44):   # antennae with glowing tips
            pygame.draw.line(s, line, (32 + (ax-32)//3, 14), (ax, 5), 3)
            for k in range(3): pygame.draw.circle(s, (255,255,120, 60 + k*50), (ax, 5), 7 - k*2)
            pygame.draw.circle(s, (255,250,170), (ax, 5), 3)
        pygame.draw.ellipse(s, body, (12,12,40,48)); pygame.draw.ellipse(s, light, (18,16,16,12))
        pygame.draw.ellipse(s, light, (20,40,24,14))   # tummy
        pygame.draw.ellipse(s, line, (12,12,40,48), 2)
        if mean:   # 3 googly eyes
            for (x, y, r) in ((22,26,5), (32,21,6), (42,26,5)): _googly(s, x + eye//2, y, r, eye)
        else:      # 1 big googly eye
            _googly(s, 32 + eye//2, 26, 9, eye)
        pygame.draw.arc(s, line, (24,32,16,10), 3.5, 5.9, 2)   # silly smile
    elif th == "desert":   # cute cartoon scorpion (tan / orange)
        for k in range(3):   # little side legs
            for sd in (-1, 1):
                pygame.draw.line(s, line, (32 + sd*10, 38 + k*6), (32 + sd*20, 42 + k*7), 3)
        pygame.draw.ellipse(s, body, (16,30,32,26)); pygame.draw.ellipse(s, light, (21,33,14,8))
        for y in (40, 46): pygame.draw.arc(s, line, (18, y-6, 28, 12), 3.4, 6.0, 1)   # body segments
        pygame.draw.ellipse(s, line, (16,30,32,26), 2)
        pts = [(40,52), (48,44), (52,32), (50,20), (44,12), (36,10)]   # curled tail over the back
        for k, p in enumerate(pts):
            r = 6 - k//2; pygame.draw.circle(s, line, p, r + 1); pygame.draw.circle(s, body, p, r); pygame.draw.circle(s, light, (p[0]-1, p[1]-1), max(1, r//2))
        pygame.draw.polygon(s, (120,40,20), [(36,6), (30,12), (37,14)])   # stinger (cartoon, round tip)
        pygame.draw.ellipse(s, body, (20,24,24,16)); pygame.draw.ellipse(s, line, (20,24,24,16), 2)   # head
        for x in (27, 37):
            pygame.draw.circle(s, (30,20,20), (x + eye//2, 31), 3); pygame.draw.circle(s, WHITE, (x + eye//2 - 1, 30), 1)
        if mean: pygame.draw.line(s, (90,30,10), (24,26), (30,28), 2); pygame.draw.line(s, (90,30,10), (40,26), (34,28), 2)
    else:   # snow: cute big white furry yeti with a blue face
        for k in range(14):   # fluffy fur bumps
            a = k/14*2*math.pi; pygame.draw.circle(s, body, (int(32 + 18*math.cos(a)), int(42 + 16*math.sin(a))), 6)
        pygame.draw.circle(s, body, (32,42), 18); pygame.draw.circle(s, light, (26,38), 7)
        for k in range(10):
            a = k/10*2*math.pi; pygame.draw.circle(s, body, (int(32 + 14*math.cos(a)), int(18 + 12*math.sin(a))), 5)
        pygame.draw.circle(s, body, (32,18), 14)
        s = _outline(s, line, 2)
        pygame.draw.ellipse(s, (110,160,225) if not mean else (80,120,200), (21,10,22,18))   # blue face
        pygame.draw.circle(s, (20,30,60), (27 + eye//2, 17), 3); pygame.draw.circle(s, (20,30,60), (37 + eye//2, 17), 3)
        pygame.draw.circle(s, WHITE, (26 + eye//2, 16), 1); pygame.draw.circle(s, WHITE, (36 + eye//2, 16), 1)
        pygame.draw.arc(s, (20,30,60), (27,19,10,7), 3.5, 5.9, 2)
        pygame.draw.rect(s, WHITE, (29,23,3,3)); pygame.draw.rect(s, WHITE, (33,23,3,3))   # two little teeth
    return s.convert_alpha()
def draw_pincer(hx, hy, ux, uy, cols):   # scorpion claws at the end of its arms
    line, body, light = cols; a = math.atan2(uy, ux)
    for sd in (-1, 1):
        b = a + sd*0.6
        pygame.draw.line(screen, line, (hx, hy), (hx + 11*math.cos(b), hy + 11*math.sin(b)), 6)
        pygame.draw.line(screen, body, (hx, hy), (hx + 10*math.cos(b), hy + 10*math.sin(b)), 4)
    pygame.draw.circle(screen, line, (int(hx), int(hy)), 7); pygame.draw.circle(screen, body, (int(hx), int(hy)), 6)
# ---- scorpions hang out at their holes ----
def hole_wander(t):   # when it isn't chasing, a scorpion strolls around near its home hole
    home = getattr(t, "home", None)
    if home is None or THEME[0] != "desert": return
    tg = getattr(t, "wtarget", None)
    cx, cy = t.rect.center
    if tg is None or math.hypot(tg[0]-cx, tg[1]-cy) < 6:
        a = random.uniform(0, 6.283); r = random.uniform(30, 130); t.wtarget = tg = (home[0] + r*math.cos(a), home[1] + r*math.sin(a))
    dx, dy = tg[0]-cx, tg[1]-cy; d = math.hypot(dx, dy) or 1
    nx, ny = round(cx + dx/d*1.2), round(cy + dy/d*1.2)
    test = t.rect.copy(); test.center = (nx, ny)
    if test.colliderect(POND_SAFE) or test.colliderect(VILLAGE_RECT): t.wtarget = None; return
    t.rect.center = (nx, ny)
    if hasattr(t, "fx"): t.fx, t.fy = float(nx), float(ny)
    t.moving = True; t.step += 1
# ---- decorations ----
def theme_setup(st):   # place this level's looks-only decorations (and the desert holes)
    THEME_DECOR.clear(); THEME_HOLES.clear()
    th = THEME[0]
    if th not in ("space", "desert", "dungeon", "snow"): return
    rng = random.Random(level*131 + 7)
    zones = [VILLAGE_RECT.inflate(120,120), CAVE_RECT.inflate(160,160), BERRY_CAVE_RECT.inflate(160,160), POND_RECT.inflate(160,160),
             WARP_RECT.inflate(160,160), pygame.Rect(st[0]-160, st[1]-160, 320, 320)]
    obs = [o.rect for o in obstacles]
    def spot(w, h, top=ROCK_BAND + 40):
        for _ in range(200):
            x, y = rng.randint(200, WORLD_W-200), rng.randint(top, WORLD_H-200)
            r = pygame.Rect(0, 0, w, h); r.center = (x, y)
            if r.collidelist(zones) == -1 and r.collidelist(obs) == -1: return x, y
        return None
    if th == "desert":
        for _ in range(9):
            p = None
            for tries in range(200):
                p = spot(110, 70)
                if p and math.hypot(p[0]-st[0], p[1]-st[1]) > 900*WS and all(math.hypot(p[0]-q[0], p[1]-q[1]) > 1200 for q in THEME_HOLES): break
                p = None
            if p: THEME_HOLES.append(p); THEME_DECOR.append(["hole", p[0], p[1], len(THEME_HOLES) % 3])
        if THEME_HOLES:   # every scorpion lives at a hole (and starts there)
            for i, t in enumerate(trolls):
                h = THEME_HOLES[i % len(THEME_HOLES)]; t.home = h; c = h
                for _ in range(30):
                    a = rng.uniform(0, 6.283); r = rng.uniform(50, 120); c = (int(h[0] + r*math.cos(a)), int(h[1] + r*math.sin(a)))
                    tr = t.rect.copy(); tr.center = c
                    if not tr.colliderect(POND_SAFE) and tr.collidelist([VILLAGE_RECT, CAVE_RECT, BERRY_CAVE_RECT]) == -1: break
                t.rect.center = c
                if hasattr(t, "fx"): t.fx, t.fy = map(float, c)
        for _ in range(40):
            p = spot(30, 20)
            if p: THEME_DECOR.append(["pebbles", p[0], p[1], rng.randint(0, 2)])
    elif th == "space":
        for _ in range(70):
            p = spot(40, 40)
            if p: THEME_DECOR.append(["alienplant", p[0], p[1], rng.randint(0, 2)])
    elif th == "dungeon":
        for kind, n in (("torch", 40), ("chain", 26), ("bones", 45)):
            for _ in range(n):
                p = spot(40, 50)
                if p: THEME_DECOR.append([kind, p[0], p[1], rng.randint(0, 2)])
    elif th == "snow":
        for _ in range(60):
            p = spot(90, 40)
            if p: THEME_DECOR.append(["drift", p[0], p[1], rng.randint(0, 2)])
def _decor_img(kind, v):
    def mk():
        if kind == "hole":
            s = pygame.Surface((110,64), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (205,165,105), (0,4,110,58)); pygame.draw.ellipse(s, (180,135,80), (8,10,94,44))
            pygame.draw.ellipse(s, (70,45,25), (16,16,78,34)); pygame.draw.ellipse(s, (35,22,12), (26,22,58,24))
            for k in range(5): pygame.draw.circle(s, (225,190,130), (10 + k*22, 52 + (k % 2)*4), 4)   # dug-up sand
            return s.convert_alpha()
        if kind == "pebbles":
            s = pygame.Surface((30,20), pygame.SRCALPHA)
            for (x, y, r) in ((6,12,4), (15,8,3), (22,13,4)): pygame.draw.circle(s, (190,140,90), (x, y), r); pygame.draw.circle(s, (230,190,140), (x-1, y-1), max(1, r-2))
            return s.convert_alpha()
        if kind == "alienplant":
            s = pygame.Surface((44,50), pygame.SRCALPHA); c = [(120,255,170), (255,130,230), (140,200,255)][v]
            for (bx, tx, ty) in ((22, 10, 10), (22, 34, 8), (22, 22, 2)):
                pygame.draw.line(s, (70,150,110), (bx, 48), (tx, ty + 8), 3)
                for g in range(3): pygame.draw.circle(s, c + (60 + g*60,), (tx, ty + 6), 7 - g*2)
            pygame.draw.ellipse(s, (60,110,90), (8,40,28,10))
            return s.convert_alpha()
        if kind == "torch":
            s = pygame.Surface((24,50), pygame.SRCALPHA)
            pygame.draw.rect(s, (90,60,40), (9,20,6,28), border_radius=2); pygame.draw.rect(s, (120,120,130), (5,18,14,6), border_radius=2)
            return s.convert_alpha()
        if kind == "chain":
            s = pygame.Surface((20,60), pygame.SRCALPHA)
            for k in range(6): pygame.draw.ellipse(s, (130,130,145), (4 + (k % 2)*2, k*9, 10 - (k % 2)*4, 12), 3)
            pygame.draw.circle(s, (100,100,115), (10,54), 5, 3)
            return s.convert_alpha()
        if kind == "bones":
            s = pygame.Surface((40,24), pygame.SRCALPHA); B = (235,228,205)
            pygame.draw.line(s, B, (6,6), (32,18), 4); pygame.draw.line(s, B, (8,18), (30,5), 4)
            for p in ((5,4), (8,8), (31,16), (34,20), (7,16), (10,20), (29,3), (32,7)): pygame.draw.circle(s, B, p, 3)
            if v == 0: pygame.draw.circle(s, B, (20,12), 6); pygame.draw.circle(s, (60,50,60), (18,11), 1); pygame.draw.circle(s, (60,50,60), (22,11), 1)
            return s.convert_alpha()
        s = pygame.Surface((90,40), pygame.SRCALPHA)   # snow drift
        pygame.draw.ellipse(s, (200,215,240), (0,14,90,26)); pygame.draw.ellipse(s, (250,252,255), (6,6,74,26)); pygame.draw.ellipse(s, WHITE, (18,8,30,10))
        return s.convert_alpha()
    return _th_c(("decor", kind, v), mk)
def draw_theme_decor(cx, cy):   # ground decorations (under the trees, items and trolls)
    if not THEME_DECOR: return
    t = pygame.time.get_ticks()
    for kind, x, y, v in THEME_DECOR:
        sx, sy = x - cx, y - cy
        if not (-120 < sx < WIDTH + 120 and -120 < sy < HEIGHT + 120): continue
        im = _decor_img(kind, v); screen.blit(im, (sx - im.get_width()//2, sy - im.get_height()//2))
        if kind == "torch":   # flickering flame
            f = 0.75 + 0.25*math.sin(t/70 + x) + 0.1*math.sin(t/23 + y)
            fx, fy = sx, sy - im.get_height()//2 + 12
            pygame.draw.ellipse(screen, (255,140,40), (fx-6*f, fy-14*f, 12*f, 18*f)); pygame.draw.ellipse(screen, (255,230,120), (fx-3*f, fy-8*f, 6*f, 10*f))
            draw_embers(fx, fy - 8, 3, 40)
        elif kind == "alienplant" and (t//400 + x) % 5 == 0:
            _star_glint(screen, sx + 10, sy - 18, 3, (255,255,220))
_TORCH_GLOW = []
def _tint(rgba):
    s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); s.fill(rgba); return s
def _planet_img(kind):
    def mk():
        if kind == "ringed":
            s = pygame.Surface((220,140), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (240,200,140,150), (0,52,220,40), 6)
            pygame.draw.circle(s, (230,150,110,210), (110,70), 46); pygame.draw.circle(s, (250,190,140,210), (96,58), 22)
            for y in (60, 76, 88): pygame.draw.line(s, (200,120,90,160), (70, y), (150, y), 4)
            pygame.draw.arc(s, (250,215,160,200), (0,52,220,40), math.pi, 2*math.pi, 6)   # front of the ring
            return s
        if kind == "moon":
            s = pygame.Surface((90,90), pygame.SRCALPHA)
            pygame.draw.circle(s, (235,235,250,200), (45,45), 36)
            for (x, y, r) in ((32,36,8), (55,52,6), (44,62,4)): pygame.draw.circle(s, (200,200,220,200), (x, y), r)
            return s
        s = pygame.Surface((80,80), pygame.SRCALPHA)
        pygame.draw.circle(s, (120,200,255,180), (40,40), 26); pygame.draw.ellipse(s, (90,230,170,180), (20,26,26,14))
        return s
    return _th_c(("planet", kind), mk)
_STARFIELD = [(random.Random(i).randrange(WIDTH), random.Random(i+999).randrange(110, HEIGHT), random.Random(i+5).random()) for i in range(110)]
def draw_theme_overlay(cx, cy):   # sky, tint and glow on top of the world (under the HUD)
    th = THEME[0]
    if th == "space":
        screen.blit(_th_c("spacesky", lambda: _tint((20,10,60,70))), (0, 0))
        t = pygame.time.get_ticks()
        for i, (x, y, ph) in enumerate(_STARFIELD):   # twinkling stars
            x2 = int((x - cx*0.05) % WIDTH); y2 = int(110 + (y - 110 - cy*0.05) % (HEIGHT - 110))
            k = 0.5 + 0.5*math.sin(t/300 + ph*20)
            if k > 0.75 and i % 3 == 0: _star_glint(screen, x2, y2, 3, (255,255,230))
            else: pygame.draw.circle(screen, (230,230,255) if k > 0.4 else (150,150,200), (x2, y2), 1)
        pass   # the planets now live in the deep-space backdrop (draw_space_backdrop), behind everyone
    elif th == "desert":
        screen.blit(_th_c("deserttint", lambda: _tint((255,170,80,38))), (0, 0))
    elif th == "snow":
        screen.blit(_th_c("snowtint", lambda: _tint((180,210,255,30))), (0, 0))
    elif th == "dungeon":
        screen.blit(_th_c("dungtint", lambda: _tint((40,25,70,105))), (0, 0))
        if not _TORCH_GLOW:
            g2 = pygame.Surface((180,180)); g2.fill((0,0,0))
            for k in range(12): pygame.draw.circle(g2, (9 + k*5, 5 + k*3, 1 + k), (90,90), 90 - k*7)
            _TORCH_GLOW.append(g2)
        t = pygame.time.get_ticks()
        for kind, x, y, v in THEME_DECOR:
            if kind != "torch": continue
            sx, sy = x - cx, y - cy - 13
            if -100 < sx < WIDTH + 100 and -100 < sy < HEIGHT + 100:
                f = 0.85 + 0.15*math.sin(t/70 + x)
                g = pygame.transform.scale(_TORCH_GLOW[0], (int(180*f), int(180*f)))
                screen.blit(g, g.get_rect(center=(sx, sy)), special_flags=pygame.BLEND_RGB_ADD)
# ---- LEVEL 8 deep-space backdrop: drawn right after the ground, BEHIND foxes/aliens/items (looks only, no collisions) ----
# each thing has a 'world spot' P and a parallax factor f: it sits in the middle of the screen when the camera is
# centered on P, and moves only f x as fast as the camera, so it drifts slowly past like it is very far away.
SPACE_PLANETS = [("ringed", (5200, 3600), 0.25), ("moon", (11800, 7400), 0.35), ("small", (3000, 6600), 0.20)]
SPACE_NEBULAS = [((2600, 2400), 0.12, 0), ((9000, 4800), 0.12, 1), ((14200, 8400), 0.12, 2), ((6200, 10600), 0.12, 3), ((12500, 1800), 0.12, 1)]
def _para_pos(p, f, cx, cy, w, h):
    return (int(WIDTH/2 + (p[0] - cx - WIDTH/2)*f - w/2), int(HEIGHT/2 + (p[1] - cy - HEIGHT/2)*f - h/2))
def _nebula_img(k):
    def mk():
        rr = random.Random(500 + k); w, h = 560, 340
        im = pygame.Surface((w, h), pygame.SRCALPHA)
        c = [(150,70,200), (60,110,210), (200,70,150), (70,160,190)][k % 4]
        for _ in range(1100):
            a = rr.uniform(0, 6.283); r = min(0.98, abs(rr.gauss(0, 0.42)))
            x = int(w/2 + math.cos(a)*r*w/2)//8*8; y = int(h/2 + math.sin(a)*r*h/2)//8*8
            if 0 <= x < w and 0 <= y < h: im.fill(c + (rr.randint(10, 24),), (x, y, 8, 8))
        return im
    return _th_c(("nebula", k), mk)
def draw_space_backdrop(cx, cy):
    if THEME[0] != "space": return
    t = pygame.time.get_ticks()
    for p, f, k in SPACE_NEBULAS:   # faint pixel nebula clouds (slowest)
        im = _nebula_img(k); w, h = im.get_size(); x, y = _para_pos(p, f, cx, cy, w, h)
        if -w < x < WIDTH and -h < y < HEIGHT: screen.blit(im, (x, y))
    for kind, p, f in SPACE_PLANETS:   # moon / Earth / Saturn, far away
        im = _planet_img(kind); w, h = im.get_size(); x, y = _para_pos(p, f, cx, cy, w, h)
        y += int(round(3*math.sin(t/1600.0 + f*20)))   # very gentle float
        if -w < x < WIDTH and -h < y < HEIGHT: screen.blit(im, (x, y))
    f = 0.5; C = 150; ox = cx*f + t/90.0; oy = cy*f + t/240.0   # faint floating dust specks (just decoration)
    for i in range(int(ox//C) - 1, int((ox + WIDTH)//C) + 2):
        for j in range(int(oy//C) - 1, int((oy + HEIGHT)//C) + 2):
            for q in range(2):
                hh = _hash(i, j, 40 + q); sx = int(i*C + hh % C - ox); sy = int(j*C + (hh >> 9) % C - oy)
                tw = 0.5 + 0.5*math.sin(t/900.0 + (hh % 628)/100.0); sz = 2 if hh % 5 == 0 else 1
                screen.fill((int(70 + 60*tw), int(70 + 50*tw), int(120 + 70*tw)), (sx, sy, sz, sz))
def space_float(pf):   # level 8: weightless fox - gentle bob + slight tilt (looks only)
    if THEME[0] != "space" or getattr(pf, "swimming", False) or indoors(): return 0, 0.0
    t = pygame.time.get_ticks(); sd = 1.3 if pf is fox else 2.9
    return int(round(3*math.sin(t/430.0 + sd))), 4.0*math.sin(t/950.0 + sd)
def draw_space_helmet(pf, cx, cy):   # level 8: a round see-through space helmet bubble
    if THEME[0] != "space" or getattr(pf, "swimming", False): return
    d = getattr(pf, "direction", None); dx, dy = (d.x, d.y) if d is not None and (d.x or d.y) else (0, 0)
    hx, hy = pf.rect.centerx - cx + dx*12, pf.rect.centery - cy + dy*12 - (8 if not dy else 0)
    g = _th_c("helmet", _make_helmet); hy += space_float(pf)[0]   # bobs along with the floating fox
    screen.blit(g, (int(hx) - 26, int(hy) - 26))
def _make_helmet():
    s = pygame.Surface((52,52), pygame.SRCALPHA)
    pygame.draw.circle(s, (200,235,255,55), (26,26), 24)
    pygame.draw.circle(s, (230,245,255,200), (26,26), 24, 2)
    pygame.draw.arc(s, (255,255,255,230), (8,8,30,30), 1.7, 2.9, 3)   # shine
    pygame.draw.circle(s, (255,255,255,220), (34,14), 2)
    return s
# ---- the DRAGON (level 11 dungeon boss: same rect, same patrol, 3 dagger hits) ----
def BOSS_NAME(cap=False):   # "Smog the Dragon" on the dungeon level, "the Boss Troll" anywhere else
    if THEME[0] == "dungeon": return "Smog the Dragon"
    return "The Boss Troll" if cap else "the Boss Troll"
def _make_dragon(flap):
    s = pygame.Surface((240,220), pygame.SRCALPHA)
    B, Bd, Bl, Belly = (150,70,190), (90,35,120), (190,120,230), (250,200,140)
    wy = DRAGON_WY[flap]
    for sd in (-1, 1):   # wings
        root = (120 + sd*30, 90); tip = (120 + sd*112, 30 + wy); mid = (120 + sd*104, 110 + wy//2)
        pygame.draw.polygon(s, (120,50,160), [root, tip, (120 + sd*96, 70 + wy), mid, (120 + sd*60, 120)])
        pygame.draw.polygon(s, (200,140,240), [root, (120 + sd*96, 70 + wy), mid, (120 + sd*60, 120)])
        for k in (0.35, 0.65): pygame.draw.line(s, Bd, root, (int(120 + sd*(60 + 50*k)), int(70 + wy*k + 40)), 3)
        pygame.draw.lines(s, Bd, False, [root, tip, (120 + sd*96, 70 + wy), mid, (120 + sd*60, 120)], 3)
    pygame.draw.ellipse(s, B, (70,80,100,110)); pygame.draw.ellipse(s, Belly, (90,110,60,72))   # body + belly
    for y in (122, 138, 154, 170): pygame.draw.line(s, (225,170,110), (98, y), (142, y), 2)
    pygame.draw.ellipse(s, Bd, (70,80,100,110), 3)
    pygame.draw.circle(s, B, (120,62), 40); pygame.draw.circle(s, Bl, (106,48), 14)   # head
    for sd in (-1, 1):   # horns
        pygame.draw.polygon(s, (250,230,180), [(120 + sd*18, 30), (120 + sd*36, 2), (120 + sd*30, 34)])
        pygame.draw.polygon(s, (180,150,110), [(120 + sd*18, 30), (120 + sd*36, 2), (120 + sd*30, 34)], 2)
    pygame.draw.circle(s, Bd, (120,62), 40, 3)
    pygame.draw.ellipse(s, Bl, (96,70,48,30)); pygame.draw.ellipse(s, Bd, (96,70,48,30), 2)   # snout
    pygame.draw.circle(s, Bd, (110,82), 3); pygame.draw.circle(s, Bd, (130,82), 3)
    for x in (104, 136):   # big cute eyes
        pygame.draw.circle(s, WHITE, (x, 54), 10); pygame.draw.circle(s, (255,170,0), (x, 56), 7); pygame.draw.circle(s, (30,20,40), (x, 57), 4)
        pygame.draw.circle(s, WHITE, (x - 3, 52), 2)
    pygame.draw.line(s, Bd, (94,40), (110,44), 3); pygame.draw.line(s, Bd, (146,40), (130,44), 3)   # scary-cute brows
    pygame.draw.polygon(s, WHITE, [(112,96), (116,104), (120,96)]); pygame.draw.polygon(s, WHITE, [(122,96), (126,104), (130,96)])   # little fangs
    return s.convert_alpha()
def draw_dragon(b, cx, cy, players):
    r = b.rect.move(-cx, -cy)
    if not r.inflate(400, 400).colliderect(screen.get_rect()): return
    t = pygame.time.get_ticks(); fc = getattr(b, "face", 1)
    flap = toon_dragon_flap(t)
    ph = b.step * 0.18
    for k in range(5):   # swishy tail behind him
        p = (r.centerx - fc*(50 + k*14), r.centery + 60 - k*8 + 6*math.sin(t/200 + k))
        pygame.draw.circle(screen, (90,35,120), (int(p[0]), int(p[1])), 13 - 2*k); pygame.draw.circle(screen, (150,70,190), (int(p[0]), int(p[1])), 11 - 2*k)
    for side in (-1, 1):   # stomping legs
        a = ph + (0 if side < 0 else math.pi)
        lift = max(0.0, 9*math.sin(a)) if b.moving else 0
        hx, hy = r.centerx + side*30, r.centery + 50; fx, fy = hx + (7*math.cos(a) if b.moving else 0), r.centery + 78 - lift
        pygame.draw.line(screen, (90,35,120), (hx, hy), (fx, fy), 22); pygame.draw.line(screen, (150,70,190), (hx, hy), (fx, fy), 16)
        pygame.draw.ellipse(screen, (90,35,120), (fx-20, fy-9, 40, 20)); pygame.draw.ellipse(screen, (190,120,230), (fx-18, fy-7, 36, 16))
    img = toon_dragon_img(flap, fc, t)
    sx_, sy_ = clay_squash(b, b.moving, ph, walk=0.03, breath=0.024); bx_, by_ = clay_boil(77, 1.0, t)   # Smog: squash on his stomps, weighty breathing
    clay_blit(screen, img, r.centerx - 120 + int(round(bx_)), r.centery - 125 + int(round(4*math.sin(t/520.0) + by_ - DRAGON_LIFT[flap])), sx_, sy_)   # Smog breathes
    pf = getattr(b, "puffs", None)
    if pf is None: pf = b.puffs = []
    if len(pf) < 12 and random.random() < (0.25 if b.rage else 0.08):   # puffs of fire and smoke from the snout
        pf.append([b.rect.centerx + random.randint(-8, 8), b.rect.centery - 40, random.uniform(-1.2, 1.2), random.uniform(-2.4, -1.2), 40, random.random() < (0.6 if b.rage else 0.35)])
    for p in pf[:]:
        p[0] += p[2]; p[1] += p[3]; p[4] -= 1
        if p[4] <= 0: pf.remove(p); continue
        rad = int(6 + (40 - p[4])/3); al = int(220*p[4]/40)
        g = pygame.Surface((rad*2, rad*2), pygame.SRCALPHA)
        pygame.draw.circle(g, ((255,150,40, al) if p[5] else (200,195,210, al)), (rad, rad), rad)
        if p[5]: pygame.draw.circle(g, (255,235,120, al), (rad, rad), rad//2)
        screen.blit(g, (p[0] - cx - rad, p[1] - cy - rad))
    n = tinyfont.render("SMOG THE DRAGON", True, (255,120,200)); screen.blit(n, (r.centerx - n.get_width()//2, r.centery - 148))
def draw_dragon_bar(b, cx, cy):   # health bar over the dragon (3 dagger hits)
    r0 = b.rect.move(-cx, -cy); w = 150; x, y = r0.centerx - w//2, r0.centery - 176
    pygame.draw.rect(screen, (40,20,50), (x-3, y-3, w+6, 20), border_radius=8)
    pygame.draw.rect(screen, (90,60,100), (x, y, w, 14), border_radius=6)
    if b.hp > 0: pygame.draw.rect(screen, (255,80,120), (x, y, int(w*b.hp/3), 14), border_radius=6)
    for k in (1, 2): pygame.draw.line(screen, (40,20,50), (x + w*k//3, y), (x + w*k//3, y + 13), 2)
# ---- WEATHER: rain on every level (snow on level 6), never over Fox Village ----
_RAIN = [(random.Random(i*3+1).randrange(WIDTH), random.Random(i*3+2).randrange(HEIGHT), random.Random(i*3+3).uniform(0.55, 0.9)) for i in range(170)]
_FLAKES = [(random.Random(i*5+1).randrange(WIDTH), random.Random(i*5+2).randrange(HEIGHT), random.Random(i*5+3).uniform(0.06, 0.13), random.Random(i*5+4).choice((1, 2, 2, 3))) for i in range(150)]
def draw_weather(cx, cy):
    if THEME[0] in ("dungeon", "space") or level == 1: return   # no rain in the dungeon (indoors), in outer space (level 8) or on Level 1
    t = pygame.time.get_ticks()
    v = VILLAGE_RECT.move(-cx, -cy)
    vc = v.clip(screen.get_rect())
    tint = _th_c("raintint", lambda: _tint((120,150,210,22)))
    if vc.w and vc.h:   # cool tint everywhere except over the village
        for rr in (pygame.Rect(0, 0, WIDTH, vc.top), pygame.Rect(0, vc.bottom, WIDTH, HEIGHT-vc.bottom),
                   pygame.Rect(0, vc.top, vc.left, vc.h), pygame.Rect(vc.right, vc.top, WIDTH-vc.right, vc.h)):
            if rr.w > 0 and rr.h > 0: screen.blit(tint, rr.topleft, rr)
    else: screen.blit(tint, (0, 0))
    vi = v.inflate(8, 8)
    if THEME[0] == "snow":   # level 6: snowflakes instead of rain
        for (x0, y0, sp, r) in _FLAKES:
            y = (y0 + t*sp - cy*0.3) % (HEIGHT + 20) - 10
            x = (x0 - cx*0.3 + 14*math.sin(t/900 + x0)) % WIDTH
            if vi.collidepoint(x, y): continue
            pygame.draw.circle(screen, WHITE, (int(x), int(y)), r)
        return
    for (x0, y0, sp) in _RAIN:   # light blue-white diagonal drops (screen space)
        y = (y0 + t*sp) % (HEIGHT + 30) - 15
        x = (x0 - (y0 + t*sp)*0.25 - cx*0.2) % (WIDTH + 20) - 10
        if vi.collidepoint(x, y) or vi.collidepoint(x - 4, y + 13): continue
        pygame.draw.line(screen, (185,215,255), (x, y), (x - 4, y + 13), 2)
    for k in range(22):   # little splash ripples on the ground
        cyc = t // 520 + k*7; ph = (t % 520) / 520.0
        h_ = (cyc * 2654435761 + k*97) & 0xffffffff
        x = h_ % WIDTH; y = 120 + (h_ // WIDTH) % (HEIGHT - 120)
        if vi.collidepoint(x, y): continue
        w = int(4 + 14*ph); hh = max(2, w//3)
        pygame.draw.ellipse(screen, (200,225,255) if ph < 0.6 else (170,200,235), (x - w//2, y - hh//2, w, hh), 1)

# ================= BREATH-OF-THE-WILD STYLE NATURE MOTION (Faroe Nov 1): gusts, swaying trees, waving grass, swishing tails =================
# looks only: everything here is drawn on top with offsets / see-through overlays, no rect, hitbox or gameplay changes
_AN = {}
def _an_c(key, make):
    if key not in _AN: _AN[key] = make()
    return _AN[key]
def _ease(u): return 0.5 - 0.5*math.cos(math.pi*max(0.0, min(1.0, u)))   # smooth sine ease 0..1
def _hash(i, j, k=0):
    h = (i*73856093) ^ (j*19349663) ^ (k*83492791); h &= 0xffffffff
    return (h ^ (h >> 13))*1274126177 & 0xffffffff
def _soft_blob(w, h, col, a, steps=10):   # soft see-through blob, strongest in the middle
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    for k in range(steps):
        f = k/steps; pygame.draw.ellipse(s, col + (min(255, int(a*(k + 1)/steps)),), (int(w*f/2), int(h*f/2), max(1, int(w*(1-f))), max(1, int(h*(1-f)))))
    return s
GUST_MS = 5600                    # a big gust rolls across the screen about every 5-6 seconds
def indoors(): return globals().get("state") in ("inside", "cafe", "shop", "cave", "berry_cave") or THEME[0] == "dungeon"
def gust_front(t=None):          # where the front of the current gust is on screen (x, px)
    if t is None: t = pygame.time.get_ticks()
    return -450 + (t % GUST_MS)*0.72
def wind_at(sx, t=None):          # wind strength at screen x: calm ~0.15 .. strong gust ~1.0 (smooth, travelling left -> right)
    if t is None: t = pygame.time.get_ticks()
    if indoors(): return 0.08 + 0.05*math.sin(t/1700.0 + sx*0.003)
    f = gust_front(t); d = (sx - f)/240.0
    g = math.exp(-d*d)                                                   # the gust front
    trail = (1.0/(1.0 + math.exp((sx - f)/80.0)))*math.exp(-max(0.0, f - sx)/650.0)*max(0.0, 1 - (t % GUST_MS)/4200.0)
    return 0.14 + 0.08*math.sin(t/1400.0 + sx*0.003) + 0.85*(g + 0.55*trail*(1 - g))
# ---------- swaying trees: rows bend more toward the top (smooth shear, cached per 1 px step) ----------
def _sheared(img, q, cutf=0.66):
    key = ("shear", id(img), q)
    if key not in _AN:
        w, h = img.get_size(); pad = 12; cut = int(h*cutf)
        s = pygame.Surface((w + 2*pad, h), pygame.SRCALPHA)
        s.blit(img, (pad, cut), (0, cut, w, h - cut))
        for y in range(0, cut, 3):
            f = ((cut - y)/cut)**1.4
            s.blit(img, (pad + int(round(q*f)), y), (0, y, w, min(3, cut - y)))
        if len(_AN) > 3000: _AN.clear()
        _AN[key] = s
    return _AN[key]
def blit_swaying(o, x, y):
    img = o.image
    if not (-200 < x < WIDTH + 100 and -220 < y < HEIGHT + 100): return
    vt = isinstance(o, VillageTree); th = THEME[0]
    tree = vt or (isinstance(o, Obstacle) and getattr(o, "kind", "") == "tree" and th != "dungeon")
    if not tree: screen.blit(img, (x, y)); return
    t = pygame.time.get_ticks(); w = img.get_width()
    amp = 2.5 if th == "desert" else 9.5                           # cacti only lean a little
    sw = wind_at(x + w//2, t)*amp - 0.18*amp + 1.4*math.sin(t/1250.0 + o.rect.x*0.013)
    q = max(-11, min(11, int(round(sw))))
    if q == 0: screen.blit(img, (x, y)); return
    screen.blit(_sheared(img, q, 0.72 if vt else 0.66), (x - 12, y))
# ---------- fox tails swish + fur ruffles (all foxes: players, villagers, house + cafe foxes, the menu fox) ----------
def blit_fox(surf, img, pos, left=False, seed=0, still=True):
    t = pygame.time.get_ticks(); w, h = img.get_size()
    wv = wind_at(pos[0] + w//2, t)
    k = h/42.0
    A = (2.2*math.sin(t/(560.0 + 40*(seed % 5)) + seed*1.7) - 4.5*(wv - 0.14))*k   # idle swish + lifted by the gusts
    if abs(A) < 0.6: surf.blit(img, pos); return
    pad = int(7*k) + 1; tw = max(4, int(w*0.31)); rows = int(h*0.74)
    out = _an_c(("foxbuf", w, h), lambda: pygame.Surface((w, h + 2*pad), pygame.SRCALPHA)); out.fill((0, 0, 0, 0))
    out.blit(img, (0, pad))
    x0 = w - tw if left else 0
    out.fill((0, 0, 0, 0), (x0, pad, tw, rows))
    step = max(1, int(k))
    for i in range(0, tw, step):
        x = (w - 1 - i) if left else i
        f = ((tw - i)/tw)**1.4
        out.blit(img, (x - (step - 1 if left else 0), pad + int(round(A*f))), (x - (step - 1 if left else 0), 0, step, rows))
    if wv > 0.4 and not indoors():   # fur tufts ruffle in the gust
        col = img.get_at((int(w*0.85) if left else int(w*0.15), int(h*0.33)))
        if col[3] > 200:
            lc = (min(255, col[0] + 50), min(255, col[1] + 50), min(255, col[2] + 50))
            n = 3; L = (2 + 4*(wv - 0.4))*k
            for j in range(n):
                fx = int(w*(0.08 + 0.09*j)); fx = w - 1 - fx if left else fx
                fy = pad + int(h*(0.14 + 0.06*j) + A*0.6)
                wig = math.sin(t/90.0 + j*2)
                pygame.draw.line(out, lc, (fx, fy), (fx + int(L), fy - int(1 + wig)*1), max(1, int(k)))
    surf.blit(out, (pos[0], pos[1] - pad))
# ---------- trolls, yetis, aliens, scorpions: soft breathing + a gentle sway ----------
def blit_troll(timg, x, y, t_):
    t = pygame.time.get_ticks(); ph = t/700.0 + (id(t_) % 97)
    w, h = timg.get_size()
    b = math.sin(ph); sy = 1 + (0.035 if not t_.moving else 0.02)*b
    nh = int(round(h*sy)); nw = int(round(w*(1 - 0.5*(sy - 1))))
    sway = int(round(1.6*math.sin(ph*0.55)))
    if nh != h or nw != w:
        im = pygame.transform.smoothscale(timg, (nw, nh)); screen.blit(im, (x + (w - nw)//2 + sway, y + h - nh))
    else: screen.blit(timg, (x + sway, y))
def idle_breath(obj, amp=1.2, per=1500.0):
    return int(round(amp*math.sin(pygame.time.get_ticks()/per*4.1 + (id(obj) % 97))))
def fox_breath_img(pf, img):   # standing still: a soft breathing squash (chest rises and falls)
    lp = getattr(pf, "_an_last", None); pf._an_last = pf.rect.center
    pf._an_still = (getattr(pf, "_an_still", 0) + 1) if lp == pf.rect.center else 0
    if pf._an_still < 20: return img, 0
    w, h = img.get_size(); nh = h + int(round(2*math.sin(pygame.time.get_ticks()/620.0)))
    if nh == h: return img, 0
    return pygame.transform.smoothscale(img, (w, nh)), 0
# ---------- ground overlays (grass waves, light, per-level looks) ----------
def _tuft(lean, v):
    s = pygame.Surface((30, 30), pygame.SRCALPHA)
    cols = [((40,128,54,210), (110,200,100,220)), ((34,118,52,210), (96,188,92,220)), ((52,142,60,210), (130,210,110,220))][v]
    for k, (bx, h) in enumerate(((8, 20), (12, 26), (16, 22), (20, 16), (5, 14), (23, 12))):
        mid = (bx + lean*0.35*(h/26.0), 29 - h*0.55); tip = (bx + lean*(h/26.0), 29 - h + abs(lean)*0.25)
        pygame.draw.lines(s, cols[k % 2], False, [(bx, 29), mid, tip], 2)
    return s
def draw_ground_anim(cx, cy):   # animated overlays on the ground (drawn right after the ground tiles)
    t = pygame.time.get_ticks(); th = THEME[0]; T6 = TILE*6
    vr = VILLAGE_RECT.move(-cx, -cy)
    x0, y0 = cx//T6, cy//T6
    if th is None:   # dense grass tufts bending with each gust
        frames = _an_c("tufts2", lambda: [[_tuft(l, v) for l in range(-4, 15)] for v in range(3)])
        for i in range(x0, x0 + WIDTH//T6 + 2):
            for j in range(y0, y0 + HEIGHT//T6 + 2):
                for k in range(12):
                    h = _hash(i, j, k); sx = i*T6 + h % T6 - cx; sy = j*T6 + (h >> 9) % T6 - cy
                    if not (-30 < sx < WIDTH and -30 < sy < HEIGHT) or vr.collidepoint(sx + 15, sy + 25): continue
                    w = wind_at(sx, t); li = max(0, min(18, int(round(4 + (w - 0.14)*15 + 1.2*math.sin(t/900.0 + h % 7)))))
                    screen.blit(frames[h % 3][li], (sx, sy))
    elif th == "snow":   # snow sparkles twinkling on the ground
        for i in range(x0, x0 + WIDTH//T6 + 2):
            for j in range(y0, y0 + HEIGHT//T6 + 2):
                for k in range(8):
                    h = _hash(i, j, k); sx = i*T6 + h % T6 - cx; sy = j*T6 + (h >> 9) % T6 - cy
                    tw = math.sin(t/520.0 + (h % 628)/100.0)
                    if tw > 0.6 and not vr.collidepoint(sx, sy): _star_glint(screen, sx, sy, int(2 + 5*(tw - 0.6)/0.4), (255,255,255))
    elif th == "space":   # twinkling moon dust
        for i in range(x0, x0 + WIDTH//T6 + 2):
            for j in range(y0, y0 + HEIGHT//T6 + 2):
                for k in range(10):
                    h = _hash(i, j, k); sx = i*T6 + h % T6 - cx; sy = j*T6 + (h >> 9) % T6 - cy
                    tw = 0.5 + 0.5*math.sin(t/700.0 + (h % 628)/100.0)
                    if tw > 0.55 and not vr.collidepoint(sx, sy):
                        if tw > 0.93: _star_glint(screen, sx, sy, 4, (220,220,255))
                        else: pygame.draw.circle(screen, (int(150 + 90*tw), int(150 + 90*tw), 255), (sx, sy), 1)
    elif th == "desert":   # heat shimmer bands slowly rolling up the sand
        band = _an_c("heat", lambda: _soft_blob(WIDTH + 200, 30, (255,240,210), 40, 6))
        for k in range(4):
            y = int((k*190 - t*0.018) % (HEIGHT + 60)) - 30
            screen.blit(band, (-100 + int(30*math.sin(t/900.0 + k)), y))
    elif th == "candy":   # a soft candy sheen gliding across the ground
        sheen = _an_c("sheen", lambda: pygame.transform.rotate(_soft_blob(260, HEIGHT*2, (255,255,255), 50, 8), -25))
        screen.blit(sheen, (int((t*0.09) % (WIDTH + 900)) - 450, -HEIGHT//2))
    elif th == "dungeon":   # warm flickering torchlight pools on the floor
        pool = _an_c("pool", lambda: _soft_blob(170, 80, (255,170,80), 80, 8))
        for kind, x, y, v in THEME_DECOR:
            if kind != "torch": continue
            sx, sy = x - cx, y - cy
            if -100 < sx < WIDTH + 100 and -60 < sy < HEIGHT + 60:
                f = 0.85 + 0.1*math.sin(t/90.0 + x) + 0.05*math.sin(t/37.0 + y)
                p = pygame.transform.scale(pool, (int(170*f), int(80*f)))
                screen.blit(p, (sx - p.get_width()//2, sy + 18 - p.get_height()//2))
    if th in (None, "candy"):   # a lighter wave rolling over the grass with the gust front
        band = _an_c(("wave", th), lambda: pygame.transform.rotate(_soft_blob(240, HEIGHT + 500, (235,255,200) if th is None else (255,240,250), 46, 9), -12))
        f = gust_front(t); screen.blit(band, (int(f) - band.get_width()//2, -250))
# ---------- light: big soft cloud shadows and warm sun patches ----------
def draw_light(cx, cy, w=WIDTH, h=HEIGHT, scroll=True):
    t = pygame.time.get_ticks()
    sh = _an_c("cloud2", lambda: _soft_blob(760, 430, (20,30,55), 52, 14))
    sun = _an_c("sun2", lambda: _soft_blob(520, 300, (255,248,205), 50, 12))
    ox = (cx*0.3) % 400 if scroll else 0; oy = (cy*0.3) % 300 if scroll else 0
    for k in range(3):
        wx = (k*1500 + t*0.03 - ox) % (w + 1900) - 950
        wy = (k*610 + 80 - oy + 40*math.sin(t/5000.0 + k)) % (h + 500) - 300
        screen.blit(sh, (int(wx), int(wy)))
    for k in range(2):
        wx = (k*1300 + 600 + t*0.022 - ox) % (w + 1300) - 650
        wy = (k*360 + 260 - oy + 50*math.sin(t/4000.0 + k)) % (h + 300) - 150
        screen.blit(sun, (int(wx), int(wy)))
# ---------- BotW wind trails: thin white curling lines riding each gust ----------
def draw_wind_trails(w=WIDTH, h=HEIGHT, col=(255,255,255)):
    t = pygame.time.get_ticks(); f = gust_front(t); gi = t // GUST_MS
    for k in range(7):
        hh = _hash(int(gi), k, 3)
        y0 = 60 + hh % (h - 120); off = -((hh >> 8) % 380); L = 150 + (hh >> 4) % 140
        head = f + off; life = (t % GUST_MS)/2600.0
        if life > 1 or head < -50 or head - L > w: continue
        a = math.sin(math.pi*min(1.0, life))*(0.6 + 0.4*math.sin(k))
        if a <= 0.05: continue
        S = pygame.Surface((int(L) + 40, 60), pygame.SRCALPHA)
        pts = []
        for i in range(17):
            u = i/16.0; x = u*L
            pts.append((x, 30 + 9*math.sin(u*5.0 + k + t/400.0)*(0.4 + 0.6*u)))
        cxh, cyh = pts[-1]
        for i in range(8):   # a little curl at the head (classic wind swirl)
            ang = -math.pi/2 + i*0.7; pts.append((cxh + 9*math.cos(ang) - 4, cyh + 9 + 9*math.sin(ang)))
        for i in range(len(pts) - 1):
            al = int(170*a*min(1.0, i/7.0))
            pygame.draw.line(S, col + (al,), pts[i], pts[i + 1], 2)
        screen.blit(S, (int(head - L), int(y0 - 30)))
# ---------- collectibles: bob + soft glow pulse + an occasional sparkle (same size) ----------
_GLOW_KIND = {"berry": (255,120,160), "golden_berry": (255,220,110), "ruby": (255,80,130), "mushroom": (255,200,230)}
def blit_item(s, cx, cy):
    x, y = s.rect.x - cx, s.rect.y - cy
    if not (-60 < x < WIDTH + 30 and -60 < y < HEIGHT + 30): return
    t = pygame.time.get_ticks(); col = _GLOW_KIND.get(s.type)
    if col:
        g = _an_c(("iglow2", col), lambda: _soft_blob(70, 70, col, 120, 9))
        g.set_alpha(int(90 + 140*_ease(0.5 + 0.5*math.sin(t/650.0 + s.rect.x*0.03))))
        screen.blit(g, (s.rect.centerx - cx - 35, s.rect.centery - cy - 35))
    bob = 0 if s.type in ("stone", "stick") else int(round(2.5*math.sin(t/700.0 + s.rect.x*0.05)))
    screen.blit(s.image, (x, y + bob))
    if col:
        u = ((t + s.rect.x*37) % 2600)/2600.0
        if u < 0.25: _star_glint(screen, s.rect.right - cx - 4, s.rect.y - cy + 4 + bob, int(2 + 7*math.sin(math.pi*u/0.25)), (255,255,240))
# ================= CLAY FEEL (Faroe Nov 1): Breath-of-the-Wild motion, "almost claymation but not claymation" =================
# looks only: squash & stretch on steps, weighty breathing, a gentle stop-motion "boil", bouncy squishy items,
# tails with follow-through. Same art, same sizes on the map, same hitboxes - just how things MOVE.
_CLAY = {}                  # (id(img), qx, qy) -> (img, scaled copy)   scaled variants are cached
CLAY_STEP_MS = 83           # the boil is held like stop-motion frames: it steps ~12 times a second
def clay_scaled(img, sx, sy):
    qx = int(round(sx*200)); qy = int(round(sy*200))          # 0.5% steps (keeps the cache small)
    if qx == 200 and qy == 200: return img
    key = (id(img), qx, qy); e = _CLAY.get(key)
    if e is not None and e[0] is img: return e[1]
    if len(_CLAY) > 500: _CLAY.clear()
    w, h = img.get_size(); size = (max(1, int(round(w*qx/200.0))), max(1, int(round(h*qy/200.0))))
    try: im = pygame.transform.smoothscale(img, size)
    except (ValueError, pygame.error): im = pygame.transform.scale(img, size)
    _CLAY[key] = (img, im); return im
def _vnoise(x, seed):       # smooth wandering value -1..1
    i = math.floor(x); f = x - i; u = f*f*(3 - 2*f)
    a = (_hash(int(i), seed, 5) % 2001)/1000.0 - 1; b = (_hash(int(i) + 1, seed, 5) % 2001)/1000.0 - 1
    return a + (b - a)*u
def clay_boil(seed, amp=1.0, t=None):   # tiny organic wobble (about 1 px), held on stop-motion steps but drifting smoothly
    if t is None: t = pygame.time.get_ticks()
    x = (t//CLAY_STEP_MS)*CLAY_STEP_MS/560.0
    return amp*_vnoise(x, seed*7 + 1), amp*_vnoise(x, seed*7 + 3)
def clay_vel(obj):          # how far something moved since last frame (world space)
    t = pygame.time.get_ticks(); st = obj.__dict__.get("_clv")
    c = obj.rect.center
    if st is None: st = obj._clv = [c, t, (0, 0)]
    if st[1] != t:
        v = (c[0] - st[0][0], c[1] - st[0][1])
        if abs(v[0]) > 40 or abs(v[1]) > 40: v = (0, 0)          # teleports (new level, doors) don't count
        st[0], st[1], st[2] = c, t, v
    return st[2]
def clay_squash(obj, moving, cyc, walk=0.035, breath=0.026, per=430.0):
    """springy squash & stretch: returns (sx, sy). cyc = step phase (feet plant at multiples of pi)."""
    t = pygame.time.get_ticks(); st = obj.__dict__.get("_cl")
    if st is None: st = obj._cl = [0.0, 0.0, bool(moving), -1, 1.0, 1.0, (id(obj) % 97)*0.7]
    if st[3] == t: return st[4], st[5]
    if moving and not st[2]: st[1] += 0.5*walk + 0.02        # starting off: a little stretch up
    if st[2] and not moving: st[1] -= 0.7*walk + 0.025       # stopping: plants and squashes down
    st[2] = bool(moving)
    if moving: b = abs(math.sin(cyc)); tgt = walk*(b - 0.55)   # squash as a foot lands, stretch between steps
    else: tgt = breath*(_ease(0.5 + 0.5*math.sin(t/per + st[6])) - 0.5)   # weighty eased breathing (lingers at full / empty)
    st[1] = st[1]*0.78 + (tgt - st[0])*0.2                    # underdamped spring = a soft bouncy settle
    st[0] = max(-0.12, min(0.12, st[0] + st[1]))
    bs = 0.004*_vnoise((t//CLAY_STEP_MS)*CLAY_STEP_MS/700.0, int(st[6]*10) + 9)   # the clay "boil" in the shape
    st[3] = t; st[4] = 1 - 0.6*st[0] + bs; st[5] = 1 + st[0] - bs
    return st[4], st[5]
def clay_blit(surf, img, x, y, sx, sy):   # draw scaled, standing on the same feet (bottom-centre anchored)
    im = clay_scaled(img, sx, sy); w, h = img.get_size()
    surf.blit(im, (x + (w - im.get_width())//2, y + h - im.get_height()))
# ---------- foxes: tail swish with follow-through (the tip lags the root), the tail trails her moves, plus the boil ----------
_TAILS = {}
def blit_fox(surf, img, pos, left=False, seed=0, still=True, vel=None):
    t = pygame.time.get_ticks(); w, h = img.get_size()
    st = _TAILS.get(seed)
    if st is None or t - st[3] > 400 or t < st[3]: st = _TAILS[seed] = [pos[0], pos[1], 0.0, t, 0.0]
    if st[3] != t:   # once a frame: the tail lags behind up / down moves and lifts a little when running, then springs back
        vx, vy = vel if vel is not None else (pos[0] - st[0], pos[1] - st[1])
        if abs(vx) > 40 or abs(vy) > 40: vx = vy = 0
        tgt = max(-6.0, min(6.0, -1.1*vy - 0.35*abs(vx)))
        st[4] = st[4]*0.8 + (tgt - st[2])*0.16; st[2] += st[4]
        st[0], st[1], st[3] = pos[0], pos[1], t
    bx, by = clay_boil(seed + 11, 0.9, t)
    pos = (pos[0] + int(round(bx)), pos[1] + int(round(by)))
    k = h/42.0; per = 560.0 + 40*(seed % 5)
    wv = wind_at(pos[0] + w//2, t)
    A0 = (2.2*math.sin(t/per + seed*1.7) - 4.5*(wv - 0.14))*k                          # at the root
    A1 = (2.2*math.sin((t - 190)/per + seed*1.7) - 4.5*(wind_at(pos[0] + w//2, t - 190) - 0.14))*k + st[2]*k   # the tip follows ~0.2 s later
    if abs(A0) < 0.6 and abs(A1) < 0.6: surf.blit(img, pos); return
    pad = int(9*k) + 1; tw = max(4, int(w*0.31)); rows = int(h*0.74)
    out = _an_c(("foxbuf2", w, h), lambda: pygame.Surface((w, h + 2*pad), pygame.SRCALPHA)); out.fill((0, 0, 0, 0))
    out.blit(img, (0, pad))
    x0 = w - tw if left else 0
    out.fill((0, 0, 0, 0), (x0, pad, tw, rows))
    step = max(1, int(k))
    for i in range(0, tw, step):
        x = (w - 1 - i) if left else i
        f = ((tw - i)/tw)**1.4                                    # 0 at the root .. 1 at the tip
        A = A0 + (A1 - A0)*f                                      # overlapping action down the tail
        out.blit(img, (x - (step - 1 if left else 0), pad + int(round(A*f))), (x - (step - 1 if left else 0), 0, step, rows))
    if wv > 0.4 and not indoors():   # fur tufts ruffle in the gust
        col = img.get_at((int(w*0.85) if left else int(w*0.15), int(h*0.33)))
        if col[3] > 200:
            lc = (min(255, col[0] + 50), min(255, col[1] + 50), min(255, col[2] + 50))
            L = (2 + 4*(wv - 0.4))*k
            for j in range(3):
                fx = int(w*(0.08 + 0.09*j)); fx = w - 1 - fx if left else fx
                fy = pad + int(h*(0.14 + 0.06*j) + A0*0.6)
                wig = math.sin(t/90.0 + j*2)
                pygame.draw.line(out, lc, (fx, fy), (fx + int(L), fy - int(1 + wig)*1), max(1, int(k)))
    surf.blit(out, (pos[0], pos[1] - pad))
def fox_breath_img(pf, img):   # the player foxes: squash on each footfall, stretch on starting, squash on stopping, weighty breathing
    v = clay_vel(pf); mv = abs(v[0]) + abs(v[1]) > 0.3
    sx, sy = clay_squash(pf, mv, math.pi*getattr(pf, "step", 0)/32.0, walk=0.04, breath=0.03)
    return clay_scaled(img, sx, sy), 0
def idle_breath(obj, amp=1.2, per=1500.0):   # eased, weighty breathing bob
    u = 0.5 + 0.5*math.sin(pygame.time.get_ticks()/per*4.1 + (id(obj) % 97))
    return int(round(amp*(2*_ease(u) - 1)))
# ---------- trolls, yetis, aliens, scorpions: squash on every step, weighty breathing, a slow lean, the boil ----------
def blit_troll(timg, x, y, t_):
    t = pygame.time.get_ticks(); sd = id(t_) % 97
    sx, sy = clay_squash(t_, t_.moving, getattr(t_, "step", 0)*0.28, walk=0.05, breath=0.035)
    bx, by = clay_boil(sd + 31, 0.9, t)
    sway = 1.6*math.sin(t/1270.0 + sd)
    clay_blit(screen, timg, x + int(round(sway + bx)), y + int(round(by)), sx, sy)
# ---------- trees: the boil rides on the wind sway (stop-motion steps) ----------
_blit_swaying_wind = blit_swaying
def blit_swaying(o, x, y):
    img = o.image
    if not (-200 < x < WIDTH + 100 and -220 < y < HEIGHT + 100): return
    vt = isinstance(o, VillageTree); th = THEME[0]
    tree = vt or (isinstance(o, Obstacle) and getattr(o, "kind", "") == "tree" and th != "dungeon")
    if not tree: screen.blit(img, (x, y)); return
    t = pygame.time.get_ticks(); w = img.get_width()
    amp = 2.5 if th == "desert" else 9.5
    sw = wind_at(x + w//2, t)*amp - 0.18*amp + 1.4*math.sin(t/1250.0 + o.rect.x*0.013)
    sw += 0.9*_vnoise((t//CLAY_STEP_MS)*CLAY_STEP_MS/640.0, o.rect.x % 997)   # gentle organic boil in the canopy
    q = max(-11, min(11, int(round(sw))))
    if q == 0: screen.blit(img, (x, y)); return
    screen.blit(_sheared(img, q, 0.72 if vt else 0.66), (x - 12, y))
# ---------- axe stones: a sweeping metal glint (frames made once, clipped to the stone's shape) ----------
STONE_GLINT_N = 12
_STONE_GLINT = []
def stone_glint(k):
    if not _STONE_GLINT:
        img = collectible_image("stone"); w, h = img.get_size()
        clip = pygame.mask.from_surface(img, 60).to_surface(setcolor=(255,255,255,255), unsetcolor=(255,255,255,0))
        for f in range(STONE_GLINT_N):
            p = -14 + f*(w + 16)/float(STONE_GLINT_N - 1)
            g = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.polygon(g, (255,255,255,165), [(p, h), (p + 5, h), (p + 13, 0), (p + 8, 0)])
            pygame.draw.polygon(g, (255,255,255,90), [(p + 5, h), (p + 7, h), (p + 15, 0), (p + 13, 0)])
            g.blit(clip, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            _STONE_GLINT.append(g.convert_alpha())
    return _STONE_GLINT[max(0, min(STONE_GLINT_N - 1, k))]
# ---------- items: a bouncy bob that squishes softly at the bottom, glow pulse, sparkles (same size on the map) ----------
def blit_item(s, cx, cy):
    x, y = s.rect.x - cx, s.rect.y - cy
    if not (-60 < x < WIDTH + 30 and -60 < y < HEIGHT + 30): return
    t = pygame.time.get_ticks(); col = _GLOW_KIND.get(s.type)
    if col:
        g = _an_c(("iglow2", col), lambda: _soft_blob(70, 70, col, 120, 9))
        g.set_alpha(int(90 + 140*_ease(0.5 + 0.5*math.sin(t/650.0 + s.rect.x*0.03))))
        screen.blit(g, (s.rect.centerx - cx - 35, s.rect.centery - cy - 35))
    bx, by = clay_boil(s.rect.x % 991, 0.7, t)
    x += int(round(bx)); y += int(round(by))
    if s.type in ("stone", "stick"): bob = 0; sx = sy = 1.0
    else:
        b = abs(math.sin(t/760.0 + s.rect.x*0.05))                 # a soft little bounce (resting at the bottom)
        bob = -int(round(3.5*b))
        q = max(0.0, 1 - b/0.3)                                    # squish when it touches down
        sx, sy = 1 + 0.07*q - 0.02*(1 - q)*b, 1 - 0.07*q + 0.03*(1 - q)*b
    if sx == 1.0 and sy == 1.0: screen.blit(s.image, (x, y + bob))
    else: clay_blit(screen, s.image, x, y + bob, sx, sy)
    if s.type == "stone" and not CANDY[0] and THEME[0] != "space":   # axe stones: a little metal glint sweeps across every ~1.7 s
        u = ((t + s.rect.x*53 + s.rect.y*17) % 1700)/1700.0
        if u < 0.4: screen.blit(stone_glint(int(u/0.4*STONE_GLINT_N)), (x, y + bob))
    if col:
        u = ((t + s.rect.x*37) % 2600)/2600.0
        if u < 0.25: _star_glint(screen, s.rect.right - cx - 4, s.rect.y - cy + 4 + bob, int(2 + 7*math.sin(math.pi*u/0.25)), (255,255,240))
# ---------- the golden statue shimmers ----------
def draw_statue_shimmer(st):
    t = pygame.time.get_ticks()
    g = _an_c("statue2", lambda: _soft_blob(st.w + 150, st.h + 150, (255,230,140), 120, 10))
    g.set_alpha(int(70 + 120*_ease(0.5 + 0.5*math.sin(t/900.0))))
    screen.blit(g, (st.centerx - g.get_width()//2, st.centery - g.get_height()//2))
def draw_statue_glint(st):   # a slow light glint sliding up + sparkles on top of the statue
    t = pygame.time.get_ticks(); u = (t % 3200)/3200.0
    if u < 0.5:
        yy = st.bottom - int(st.h*u*2)
        s = pygame.Surface((st.w, 10), pygame.SRCALPHA); pygame.draw.line(s, (255,250,220, int(200*math.sin(math.pi*u*2))), (4, 8), (st.w - 4, 1), 3)
        screen.blit(s, (st.x, yy - 8))
    for k in range(3):
        v = ((t + k*900) % 2700)/2700.0
        if v < 0.3: _star_glint(screen, st.x + 10 + (k*37) % max(1, st.w - 20), st.y + 10 + (k*53) % max(1, st.h - 20), int(2 + 6*math.sin(math.pi*v/0.3)), (255,255,230))
# ---------- pond: rings spreading + glints ----------
def draw_pond_anim(cx, cy):
    r = POND_RECT.move(-cx, -cy)
    if not r.inflate(100, 100).colliderect(screen.get_rect()): return
    t = pygame.time.get_ticks()
    for k in range(6):
        per = 3000 + k*430; u = ((t + k*911) % per)/per; cyc = (t + k*911)//per
        h = _hash(k, int(cyc)); px = r.x + 60 + h % max(1, r.w - 120); py = r.y + 50 + (h >> 10) % max(1, r.h - 100)
        w = int(10 + 70*u); hh = max(3, w//3); a = int(150*(1 - u))
        s = pygame.Surface((w + 4, hh + 4), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (230,245,255, a), (2, 2, w, hh), 2)
        screen.blit(s, (px - w//2, py - hh//2))
    for k in range(6):   # sun glints dancing on the water
        h = _hash(k, 99); v = 0.5 + 0.5*math.sin(t/300.0 + k*1.9)
        if v > 0.7: _star_glint(screen, r.x + 50 + h % max(1, r.w - 100), r.y + 40 + (h >> 10) % max(1, r.h - 80), int(2 + 8*(v - 0.7)/0.3), (255,255,255))
# ---------- village life: window light flicker, lanterns glow, roof pennants flutter ----------
def draw_house_anim(o, x, y):
    if not isinstance(o, House): return
    t = pygame.time.get_ticks(); sd = o.rect.x*0.01
    g = _an_c("winglow", lambda: _soft_blob(40, 40, (255,210,120), 150, 7))
    for wx in (28, 92):
        g.set_alpha(int(110 + 70*math.sin(t/230.0 + wx + sd)*math.sin(t/97.0 + sd)))
        screen.blit(g, (x + wx - 20, y + 76 - 20))
    lg = _an_c("lantglow", lambda: _soft_blob(34, 34, (255,230,140), 200, 6))
    lg.set_alpha(int(130 + 90*math.sin(t/160.0 + sd)*math.sin(t/61.0)))
    screen.blit(lg, (x + 80 - 17, y + 82 - 17))
    px, py = x + 60, y + 8   # a little pennant on the roof top, fluttering in the wind
    pygame.draw.line(screen, (120,80,60), (px, py), (px, py - 22), 2)
    wv = wind_at(px, t); pts = [(px, py - 22)]
    for i in range(1, 6):
        u = i/5.0; pts.append((px + u*(12 + 6*wv), py - 22 + 2*u + 3*math.sin(t/120.0 - i*1.2)*(0.4 + wv)*u))
    for i in range(5, -1, -1):
        u = i/5.0; pts.append((px + u*(12 + 6*wv)*0.7, py - 12 - 3*u + 3*math.sin(t/120.0 - i*1.2)*(0.4 + wv)*u*0.7))
    pygame.draw.polygon(screen, (255,120,150), pts); pygame.draw.lines(screen, (160,60,90), True, pts, 1)
# ---------- drifting particles: tumbling leaves, pollen, twinkles, fireflies, kicked-up dust ----------
KICK = []      # [x, y, vx, vy, life, col] in world space
LEAVES = []    # [x, y, ang, spin, kind, wob] in screen space
_KICK_COL = {None: (210,230,170), "snow": (245,250,255), "space": (190,185,210), "desert": (230,200,150), "candy": (255,200,230), "dungeon": (150,145,160)}
def _leaf_frames(c1, c2):
    base = pygame.Surface((18, 10), pygame.SRCALPHA)
    pygame.draw.ellipse(base, c1 + (235,), (0, 0, 18, 10)); pygame.draw.line(base, c2 + (235,), (1, 5), (16, 5), 1)
    return [pygame.transform.rotate(base, a*22.5) for a in range(16)]
_LEAF_COLS = {None: [((120,190,70), (70,130,40)), ((235,200,80), (170,130,40)), ((235,140,60), (170,90,30))],
              "candy": [((255,170,210), (220,110,160)), ((255,235,250), (230,170,210))],
              "menu": [((120,190,70), (70,130,40)), ((235,200,80), (170,130,40)), ((235,140,60), (170,90,30)), ((255,190,210), (220,120,160))]}
def draw_leaves(n, kinds, w=WIDTH, h=HEIGHT):
    t = pygame.time.get_ticks()
    while len(LEAVES) < n: LEAVES.append([random.uniform(-40, w), random.uniform(0, h), random.uniform(0, 16), random.uniform(-0.15, 0.15), random.randrange(len(kinds)), random.uniform(0, 6)])
    del LEAVES[n:]
    for L in LEAVES:
        wv = wind_at(L[0], t)
        L[0] += 0.4 + 5.5*(wv - 0.1); L[1] += 0.35 + 0.8*math.sin(t/700.0 + L[5]) - 1.2*(wv - 0.14)
        L[2] = (L[2] + L[3] + 0.5*wv*(1 if L[3] >= 0 else -1)) % 16
        if L[0] > w + 30 or L[1] > h + 20 or L[1] < -30: L[0] = random.uniform(-60, -20); L[1] = random.uniform(-10, h); L[4] = random.randrange(len(kinds))
        fr = _an_c(("leaf2",) + kinds[L[4] % len(kinds)], lambda: _leaf_frames(*kinds[L[4] % len(kinds)]))
        im = fr[int(L[2]) % 16]
        flip = abs(math.sin(t/260.0 + L[5]))   # tumbling: the leaf turns over and gets thin
        if flip < 0.35: im = pygame.transform.scale(im, (im.get_width(), max(2, int(im.get_height()*max(0.25, flip/0.35)))))
        screen.blit(im, (int(L[0]), int(L[1])))
def draw_motes(n, col, w=WIDTH, h=HEIGHT, cx=0, glow=False, tw=10):
    t = pygame.time.get_ticks()
    g = _an_c(("mote2", col, glow), lambda: _soft_blob(22 if glow else 12, 22 if glow else 12, col, 255 if glow else 220, 6))
    for k in range(n):
        hh = _hash(k, 7); sp = 0.012 + (hh % 100)/7000.0
        y = (hh >> 8) % h + 24*math.sin(t/1900.0 + k)
        x = ((hh % w) + t*sp + 60*math.sin(t/2300.0 + k*0.7) - cx*0.25) % (w + 40) - 20
        x += 30*wind_at(x, t)
        a = _ease(0.5 + 0.5*math.sin(t/800.0 + k*1.7)); g.set_alpha(int(60 + 190*a)); screen.blit(g, (int(x) - g.get_width()//2, int(y) - g.get_height()//2))
    for k in range(tw):   # twinkling sparkles popping in and out
        hh = _hash(k, 11); per = 1700 + hh % 1500; u = ((t + hh % 1000) % per)/per; c = (t + hh % 1000)//per
        if u < 0.3:
            h2 = _hash(k, int(c)); _star_glint(screen, h2 % w, (h2 >> 11) % h, int(2 + 6*math.sin(math.pi*u/0.3)), (255,255,235))
def draw_ambient(cx, cy, players):
    t = pygame.time.get_ticks(); th = THEME[0]
    if th not in ("space", "dungeon"): draw_light(cx, cy)
    for pf in players:   # dust / pollen puffs kicked up where the foxes run (max 20)
        lp = getattr(pf, "_an_kick", None); pf._an_kick = pf.rect.center
        if lp and lp != pf.rect.center and len(KICK) < 20 and not getattr(pf, "swimming", False) and random.random() < 0.4:
            KICK.append([pf.rect.centerx + random.randint(-10, 10), pf.rect.bottom - 4, random.uniform(-0.4, 0.4), random.uniform(-0.6, -0.2), 40, _KICK_COL.get(th, (210,230,170))])
    for p in KICK[:]:
        p[0] += p[2] + 0.6*wind_at(p[0] - cx, t); p[1] += p[3]; p[3] *= 0.97; p[4] -= 1
        if p[4] <= 0: KICK.remove(p); continue
        u = p[4]/40.0; r = int(3 + 6*(1 - u))
        g = _an_c(("kick", p[5]), lambda: _soft_blob(16, 16, p[5], 200, 5))
        g.set_alpha(int(190*u)); gs = pygame.transform.scale(g, (r*2 + 2, r*2 + 2))
        screen.blit(gs, (int(p[0] - cx) - r, int(p[1] - cy) - r))
    if th is None:
        draw_leaves(32, _LEAF_COLS[None]); draw_motes(18, (255,250,215), cx=cx)
    elif th == "candy":
        draw_leaves(26, _LEAF_COLS["candy"]); draw_motes(18, (255,215,240), cx=cx)
    elif th == "dungeon":
        draw_motes(26, (255,225,110), cx=cx, glow=True, tw=4); draw_motes(10, (170,160,180), cx=cx, tw=0)
    elif th == "space":
        draw_motes(20, (200,210,255), cx=cx, tw=14)
    elif th == "desert":
        for k in range(28):
            hh = _hash(k, 5); x = ((hh % WIDTH) + t*(0.12 + 0.5*wind_at(hh % WIDTH, t))) % (WIDTH + 40) - 20; y = (hh >> 8) % HEIGHT + 10*math.sin(t/900.0 + k)
            pygame.draw.line(screen, (240,215,160), (int(x), int(y)), (int(x) + 5, int(y)), 2)
        sw = _an_c("sandwisp", lambda: _soft_blob(160, 26, (245,220,170), 120, 6))
        for k in range(3):
            x = (k*600 + t*0.09*(1 + wind_at(k*300, t))) % (WIDTH + 300) - 150; y = 180 + k*190 + 16*math.sin(t/1200.0 + k)
            screen.blit(sw, (int(x), int(y)))
    elif th == "snow":
        for k in range(4):
            x = (k*520 + t*0.07*(1 + wind_at(k*400, t))) % (WIDTH + 200) - 100; y = 160 + k*150 + 20*math.sin(t/1500.0 + k)
            screen.blit(_WISP, (int(x), int(y))); screen.blit(_WISP, (int(x) - 40, int(y) + 10))
        draw_motes(0, (255,255,255), tw=10)
    if th not in ("space", "dungeon"):
        draw_wind_trails(col=(240,220,170) if th == "desert" else (255,255,255))
# ---------- indoor life: sunbeams with dust motes, firelight, cave fireflies ----------
def draw_indoor_anim(kind):
    t = pygame.time.get_ticks()
    if kind in ("house", "cafe", "shop"):
        beam = _an_c("beam", lambda: pygame.transform.rotate(_soft_blob(220, 900, (255,240,200), 60, 10), 32))
        beam.set_alpha(int(90 + 50*math.sin(t/2400.0)))
        R = globals().get("ROOM"); screen.set_clip(R)   # light stays inside the room
        screen.blit(beam, ((R.x if R else 0) + 40 + int(20*math.sin(t/5000.0)), (R.y if R else 0) - 300))
        draw_motes(26, (255,245,210), tw=6)
        screen.set_clip(None)
    else:   # caves: glowing fireflies + soft drifting dust
        draw_motes(24, (255,230,120), glow=True, tw=5); draw_motes(8, (200,200,220), tw=0)
def draw_embers(fx, fy, n=9, rise=80):   # soft glowing embers floating up from a fire
    t = pygame.time.get_ticks()
    g = _an_c("ember", lambda: _soft_blob(12, 12, (255,190,90), 255, 5))
    for k in range(n):
        per = 1400 + k*170; u = ((t + k*397) % per)/per
        x = fx + int(10*math.sin(k*2.3) + 8*math.sin(u*5 + k) + 10*wind_at(fx)*u); y = fy - 10 - int(rise*u)
        g.set_alpha(int(240*(1 - u))); screen.blit(g, (x - 6, y - 6))
# ---------- the start menu: light, wind trails, leaves and pollen ----------
def draw_menu_anim():
    draw_light(0, 0, scroll=False)
    draw_leaves(30, _LEAF_COLS["menu"]); draw_motes(16, (255,250,215), tw=8)
    draw_wind_trails()

# ---------- Faroe Nov 2: every level nudges Fox Village (with its statue), the Secret Cave and the warp zone a little ----------
# (small fixed nudges, ~100-300 px, a different spot on every level - never random). Level 1 keeps the original spots.
_LAYOUT_BASE = dict(village=VILLAGE_RECT.topleft, cave=CAVE_RECT.center, warp=WARP_RECT.topleft)
VILLAGE_NUDGE = [(0,0), (-200,120), (160,220), (-140,-160), (260,-90), (-280,40), (120,-200), (-60,260), (220,140), (-240,-60), (80,180)]
CAVE_NUDGE    = [(0,0), (220,-120), (-180,160), (140,240), (-260,-80), (280,90), (-120,-220), (60,280), (-240,200), (200,-260), (-90,140)]
WARP_NUDGE    = [(0,0), (180,60), (60,200), (260,140), (120,280), (300,20), (20,120), (220,240), (140,100), (280,260), (90,40)]   # only right/down: it stays in the top-left corner, below the HUD
def level_layout(n):   # -> (village topleft, cave center, warp topleft) for level n
    k = (n - 1) % len(VILLAGE_NUDGE)
    (vx, vy), (cx, cy), (wx, wy) = _LAYOUT_BASE["village"], _LAYOUT_BASE["cave"], _LAYOUT_BASE["warp"]
    return ((vx + VILLAGE_NUDGE[k][0], vy + VILLAGE_NUDGE[k][1]), (cx + CAVE_NUDGE[k][0], cy + CAVE_NUDGE[k][1]),
            (wx + WARP_NUDGE[k][0], wy + WARP_NUDGE[k][1]))
def apply_level_layout(n):   # moves the rects IN PLACE, so everything that uses them follows along
    global VILLAGE_X, VILLAGE_Y, WARP_DEST
    (vx, vy), cave_c, warp_tl = level_layout(n)
    dx, dy = vx - VILLAGE_RECT.x, vy - VILLAGE_RECT.y
    for R in (VILLAGE_RECT, STATUE_RECT, VILLAGE_WALK, GUARD_ZONE): R.move_ip(dx, dy)   # the statue moves WITH the village
    VILLAGE_X += dx; VILLAGE_Y += dy
    CAVE_RECT.center = cave_c
    CAVE_DOOR.topleft = (CAVE_RECT.centerx - 50, CAVE_RECT.bottom - 30)
    WARP_RECT.topleft = warp_tl
    WARP_DEST = (CAVE_DOOR.centerx, CAVE_DOOR.bottom + 150)              # the warp still lands just outside the Secret Cave
    WARP_LAND.center = (WARP_DEST[0], WARP_DEST[1] + 20)
# ================= ANIMATED (Faroe Nov 3): classic CARTOON animation - NOT anime =================
# Looks only. Frame-by-frame cartoon life for every character: walk cycles with knees and planted feet,
# swinging arms, body bob, blinks, chomping / talking mouths, ear twitches, tail bounce, wing flaps,
# a lean when chasing and a little squash before turning. Built ON TOP of the BotW wind + clay passes.
# Same sizes, same hitboxes, same speeds, same levels - only how things look while they move.
_TOON = {}
def _toon_c(key, make):
    if key not in _TOON:
        if len(_TOON) > 3000: _TOON.clear()
        _TOON[key] = make()
    return _TOON[key]
def toon_blink(seed, t=None, per=3300):   # 0 = open, 1 = half shut, 2 = shut  (a quick ~0.17 s blink, some do a double-blink)
    if t is None: t = pygame.time.get_ticks()
    p = per + (seed*389) % 1700; u = (t + seed*211) % p
    for st in ((0, 230) if seed % 3 == 0 else (0,)):
        v = u - st
        if 0 <= v < 170: return 2 if 45 <= v < 125 else 1
    return 0
def toon_ear(seed, t=None):   # a quick double ear-flick now and then
    if t is None: t = pygame.time.get_ticks()
    u = (t + seed*523) % (4100 + (seed*97) % 1500)
    return u < 90 or 170 <= u < 250
def toon_talk_mood(n): return "talk" if (n // 6) % 2 else "happy"   # mouth opens and shuts while chatting
def _half_clip(s, rect, fn):   # draw only inside rect (for half-shut lids)
    old = s.get_clip(); s.set_clip(rect); fn(); s.set_clip(old)

# ---------- FOXES: cartoon fox (same 56x42 size) - 8-step walk cycle, body + head bob, bendy knees, cartoon eyes ----------
def _toon_draw_fox(FOX, DARK, pose, mood="n", blink=0, ear=False):
    s = pygame.Surface((56,42), pygame.SRCALPHA)
    FOX = _vivid(FOX, 1.3); DARK = _vivid(DARK, 1.3)
    CREAM = (255,247,232); PAW = _lerp(DARK, FOX, 0.2); FUR = _light(FOX, 12); INKC = _vivid(_dark(DARK, 100), 1.4)
    walk = pose >= 10 or 1 <= pose <= 4
    ph = (((pose - 10)/8.0) if pose >= 10 else ((pose - 1)/4.0))*2*math.pi if walk else 0.0
    by = int(round(1.5*abs(math.sin(ph)))) if walk else 0           # body dips when the legs are spread (contact), rises as they pass
    hy = int(round(1.5*abs(math.sin(ph - 0.7)))) if walk else 0     # the head follows a moment later (overlapping action)
    happy = mood in ("happy", "talk")
    for i, (lx, ly) in enumerate(((19,30),(25,31),(32,31),(38,30))):   # legs: diagonal pairs, hip -> knee -> paw
        if pose in (5, 6) and i == 3: continue
        if pose == 7 and i in (2, 3): continue
        sw = lift = 0.0
        if walk:
            a = ph + (0 if i in (0, 3) else math.pi)
            sw = 3.6*math.sin(a); lift = max(0.0, 2.8*math.cos(a))
        hip = (lx, ly + by); foot = (lx + sw, 37 - lift)
        kb = 1.0*lift if i >= 2 else -1.0*lift                          # front knees bend forward, back legs bend back
        knee = ((hip[0] + foot[0])/2 + kb, (hip[1] + foot[1])/2 - 0.3*lift)
        pygame.draw.lines(s, PAW, False, [hip, knee, foot], 5); pygame.draw.circle(s, PAW, (int(knee[0]), int(knee[1])), 2)
        if lift < 0.5: pygame.draw.ellipse(s, PAW, (foot[0] - 4, 35, 9, 5))          # paw planted flat (a bit wider = squash)
        else: pygame.draw.ellipse(s, PAW, (foot[0] - 3, 34.5 - lift, 7, 5))          # paw tipped up mid-step
    tb = int(round(1.6*math.sin(ph + 1.3))) if walk else 0          # the tail bounces a beat after the body
    if happy: tb -= 2                                                # happy: tail up!
    for tx, ty, tr, k in ((14,18,9,0.4),(8,13,7,1.0),(19,13,6,0.6)): pygame.draw.circle(s, FUR, (tx, int(ty + by + tb*k)), tr)   # big fluffy tail
    pygame.draw.circle(s, CREAM, (5, 10 + by + tb), 5); pygame.draw.circle(s, CREAM, (8, 7 + by + tb), 3)                    # white tail tip
    pygame.draw.ellipse(s, FUR, (15,18 + by,27,15)); pygame.draw.ellipse(s, CREAM, (22,25 + by,15,7))                        # body + belly
    if ear:   # back ear flicks
        pygame.draw.polygon(s, FUR, [(30,12+hy),(26,2+hy),(38,7+hy)]); pygame.draw.polygon(s, (255,160,185), [(31,10+hy),(28,4+hy),(35,8+hy)])
    else:
        pygame.draw.polygon(s, FUR, [(30,12+hy),(31,0+hy),(39,6+hy)]); pygame.draw.polygon(s, (255,160,185), [(32,9+hy),(32.5,3+hy),(37,7+hy)])
    pygame.draw.polygon(s, FUR, [(43,6+hy),(50,0+hy),(52,12+hy)]); pygame.draw.polygon(s, (255,160,185), [(45,7+hy),(49,3+hy),(50,10+hy)])
    pygame.draw.circle(s, FUR, (41,17+hy), 12)                                                                                 # head
    pygame.draw.ellipse(s, CREAM, (37,19+hy,16,10)); pygame.draw.polygon(s, CREAM, [(30,21+hy),(27,27+hy),(35,24+hy)])        # face + cheek fluff
    pygame.draw.polygon(s, CREAM, [(47,17+hy),(55,21+hy),(47,25+hy)])                                                         # snout
    if pose == 5:    # paw up and back holding a little axe (wind-up)
        pygame.draw.line(s, (150,105,60), (28,10), (23,0), 4); pygame.draw.line(s, (200,155,100), (28,10), (23,0), 2)
        pygame.draw.polygon(s, (200,205,215), [(20,0),(27,0),(26,5),(20,4)])
        pygame.draw.line(s, FUR, (34,25), (29,11), 5); pygame.draw.circle(s, PAW, (28,10), 3)
    elif pose == 6:  # paw swung forward (follow-through)
        pygame.draw.line(s, FUR, (36,27), (49,32), 5); pygame.draw.circle(s, PAW, (50,32), 3)
    elif pose == 7:  # VICTORY: both paws up!
        pygame.draw.line(s, FUR, (30,25), (24,8), 5); pygame.draw.circle(s, PAW, (24,7), 3)
        pygame.draw.line(s, FUR, (36,27), (29,5), 5); pygame.draw.circle(s, PAW, (29,4), 3)
    _hard_cel(s, 0.6)
    _rim(s, (255,250,215), 200)
    pygame.draw.ellipse(s, _light(FUR, 60), (20,19 + by,13,3))
    s = _ink(s, INKC, 2)
    pygame.draw.circle(s, (75,25,40), (54,21+hy), 2)                                                 # nose
    ex, ey = 43, 15 + hy                                                                              # classic cartoon eye
    if happy:
        pygame.draw.arc(s, INKC, (ex-4, ey-2, 9, 8), 0.25, math.pi - 0.25, 2)                       # happy closed eye
    elif blink == 2:
        pygame.draw.arc(s, INKC, (ex-5, ey-4, 11, 7), math.pi + 0.3, 2*math.pi - 0.3, 2)             # shut: a soft curved line
    elif mood == "hit":
        pygame.draw.ellipse(s, INKC, (ex-5, ey-6, 10, 12)); pygame.draw.ellipse(s, WHITE, (ex-4, ey-5, 8, 10))
        pygame.draw.circle(s, (25,15,20), (ex+1, ey), 1)                                            # wide "yikes" eye, tiny pupil
        pygame.draw.line(s, INKC, (ex-3, ey-9), (ex+3, ey-10), 1)                                   # raised brow
    else:
        pygame.draw.ellipse(s, INKC, (ex-5, ey-6, 10, 12)); pygame.draw.ellipse(s, WHITE, (ex-4, ey-5, 8, 10))   # cute eyes: a bit bigger + rounder
        pygame.draw.ellipse(s, (25,15,20), (ex-1, ey-3, 5, 7))                                      # big round dark pupil looking ahead
        s.fill(WHITE, (ex, ey-2, 2, 2)); s.set_at((ex+2, ey+2), WHITE)                               # 2px catchlight + tiny 1px glint
        if blink == 1 or mood == "run":                                                              # half lid (blinking / determined)
            pygame.draw.polygon(s, FUR, [(ex-5, ey-7), (ex+6, ey-7), (ex+6, ey-1 if blink == 1 else ey-2), (ex-5, ey-1 if blink == 1 else ey-3)])
            pygame.draw.line(s, INKC, (ex-5, ey-1 if blink == 1 else ey-3), (ex+5, ey-1 if blink == 1 else ey-2), 1)
    if mood == "talk":   # open mouth, little tongue
        pygame.draw.ellipse(s, (90,30,40), (47,22+hy,6,5)); pygame.draw.ellipse(s, (240,110,130), (48,24+hy,4,2))
    elif mood == "happy": pygame.draw.arc(s, INKC, (46,21+hy,8,5), math.pi, 2*math.pi, 1)
    elif mood == "hit": pygame.draw.ellipse(s, INKC, (48,24+hy,4,4))
    else: pygame.draw.line(s, INKC, (48,25+hy), (51,24+hy), 1)
    bl = pygame.Surface((7,4), pygame.SRCALPHA); pygame.draw.ellipse(bl, (255,120,150,110), (0,0,7,4)); s.blit(bl, (36,22+hy))   # soft rosy cheek
    return s
_LIVE_FOX = [None]
def _fox_seed(FOX): return (FOX[0]*7 + FOX[1]*13 + FOX[2]*3) % 997
def make_fox(FOX=(255,130,20), DARK=(200,85,0), pose=0, mood="n", blink=None, ear=None):
    sd = _fox_seed(FOX); live = _LIVE_FOX[0] is not None
    if blink is None: blink = toon_blink(sd) if live else 0
    if ear is None: ear = toon_ear(sd) if live else False
    if mood in ("happy", "talk", "hit"): blink = 0
    key = (tuple(FOX), tuple(DARK), pose, mood, blink, bool(ear))
    if key not in _FOX_CACHE: _FOX_CACHE[key] = _ready(_toon_draw_fox(FOX, DARK, pose, mood, blink, ear))
    return _FOX_CACHE[key]
_FOX_CACHE.clear()
_fox_update_old = Fox.update
def _toon_fox_update(self, keys, throw):
    _LIVE_FOX[0] = self
    try: return _fox_update_old(self, keys, throw)
    finally: _LIVE_FOX[0] = None
def _toon_pose_index(self, moving):
    if self.throw_t > 12: return 5          # wind-up with the axe
    if self.throw_t > 0: return 6           # follow-through
    if moving: return 10 + int(self.step / 8) % 8   # 8-step walk cycle (same speed as before, twice the in-betweens)
    return 0
def _toon_fox_pose(self, dx, dy):   # indoors (houses / caves)
    if dx < 0: self.face_left = True
    elif dx > 0: self.face_left = False
    moving = bool(dx or dy)
    self.step = self.step + 6 if moving else 0
    if self.throw_t > 0: self.throw_t -= 1
    _LIVE_FOX[0] = self
    try: img = make_fox(*self.colors, pose=self.pose_index(moving))
    finally: _LIVE_FOX[0] = None
    self.image = pygame.transform.flip(img, True, False) if self.face_left else img
Fox.update = _toon_fox_update; Fox.pose_index = _toon_pose_index; Fox.pose = _toon_fox_pose
for _pf in (fox, fox2): _pf.frames = [make_fox(*_pf.colors, pose=k) for k in range(7)]
shopkeeper_img = make_fox((200,120,60), (150,80,30))
def _vf_seed(v): return _fox_seed(v.cols[0]) + len(v.name)*31
def _toon_vf_update(self):   # village foxes: 8-step walk, blinks + ear flicks while they stand around
    sd = _vf_seed(self)
    if self.talk_frames > 0 or self.wait > 0:
        img = make_fox(*self.cols, pose=0, blink=toon_blink(sd), ear=toon_ear(sd))
        self.image = pygame.transform.flip(img, True, False) if self.left else img
    if self.talk_frames > 0: self.talk_frames -= 1; return
    if self.wait > 0: self.wait -= 1; return
    dx, dy = self.target[0]-self.x, self.target[1]-self.y
    d = math.hypot(dx, dy)
    if d < 3:
        self.target = self.pick_spot(); self.wait = random.randint(60,240); return
    self.x += dx/d*1.3; self.y += dy/d*1.3
    self.left = dx <= 0; self.step += 1
    img = make_fox(*self.cols, pose=10 + (self.step // 3) % 8, blink=toon_blink(sd))
    self.image = img if dx > 0 else pygame.transform.flip(img, True, False)
    self.rect.center = (int(self.x), int(self.y))
def _toon_hf_update(self):
    if self.sits:   # sitting by the fire or table: blinks, ear flicks, chats
        if self.talk_frames > 0: self.talk_frames -= 1
        sd = _vf_seed(self); self.image = make_fox(*self.cols, pose=0, blink=toon_blink(sd), ear=toon_ear(sd)); return
    VillageFox.update(self)
VillageFox.update = _toon_vf_update; HouseFox.update = _toon_hf_update
def toon_live_fox(fur, dark, seed):   # a standing fox that blinks and flicks an ear (cafe worker etc.)
    return make_fox(fur, dark, pose=0, blink=toon_blink(seed), ear=toon_ear(seed))
def toon_menu_fox(second=False):
    sd = 5 if second else 3; b = toon_blink(sd); e = toon_ear(sd)
    def mk():
        im = pygame.transform.smoothscale(make_fox((215,215,225), (140,140,155), blink=b, ear=e) if second else make_fox(blink=b, ear=e), (168,126))
        return pygame.transform.flip(im, True, False) if second else im
    return _toon_c(("menufox", second, b, e), mk)
MENU_FOX = toon_menu_fox(False); MENU_FOX2 = toon_menu_fox(True)
_TOON_PUFF = {}
def _toon_puff(r):   # a round cartoon dust cloud (3 bumps, soft outline)
    if r not in _TOON_PUFF:
        s = pygame.Surface((2*r + 8, 2*r + 8), pygame.SRCALPHA); c = r + 4
        for (dx, dy, k) in ((-r*0.45, r*0.15, 0.7), (r*0.45, r*0.2, 0.65), (0, -r*0.2, 0.85)):
            pygame.draw.circle(s, (205,190,175), (int(c + dx), int(c + dy)), int(r*k) + 1)
        for (dx, dy, k) in ((-r*0.45, r*0.15, 0.7), (r*0.45, r*0.2, 0.65), (0, -r*0.2, 0.85)):
            pygame.draw.circle(s, (250,245,235), (int(c + dx), int(c + dy)), max(1, int(r*k)))
        _TOON_PUFF[r] = s
    return _TOON_PUFF[r]
def toon_dash_puffs(pf, cx, cy):   # dashing: classic cartoon dust clouds kicked up behind her (instead of speed lines)
    d = pf.direction; tk = pygame.time.get_ticks()
    for k in range(4):
        u = ((tk/240.0) + k/4.0) % 1.0; dist = 20 + 36*u
        bx = pf.rect.centerx - cx - d.x*dist + 5*math.sin(k*2.1); by = pf.rect.bottom - cy - 6 - d.y*dist - 8*u
        r = int(4 + 7*u); g = _toon_puff(r); g.set_alpha(int(220*(1 - u)))
        screen.blit(g, (int(bx) - r - 4, int(by) - r - 4))
def _toon_star(surf, x, y, r, col=(255,225,70)):   # a little 5-point cartoon star
    pts = []
    for i in range(10):
        a = -math.pi/2 + i*math.pi/5; rr = r if i % 2 == 0 else r*0.45
        pts.append((x + rr*math.cos(a), y + rr*math.sin(a)))
    pygame.draw.polygon(surf, (150,95,20), pts, 0); pygame.draw.polygon(surf, col, [((p[0] - x)*0.78 + x, (p[1] - y)*0.78 + y) for p in pts])
def toon_ouch_stars(x, y, inv):   # bonked: little stars circling her head (classic cartoon, instead of a sweat drop)
    t = pygame.time.get_ticks()
    for k in range(3):
        a = t/170.0 + k*2.094
        _toon_star(screen, x + 16*math.cos(a), y - 4 + 5*math.sin(a), 5 if math.sin(a) > 0 else 4)
def anime_bubble(surf, b, tail_x, edge=(90,50,20), fill=WHITE):   # (name kept) now a classic cartoon speech bubble: round, bold edge, tail - no gloss, no sparkle
    pygame.draw.polygon(surf, edge, [(tail_x-10, b.bottom-3), (tail_x+10, b.bottom-3), (tail_x-3, b.bottom+14)])
    pygame.draw.rect(surf, edge, b.inflate(6, 6), border_radius=18)
    pygame.draw.rect(surf, fill, b, border_radius=15)
    pygame.draw.polygon(surf, fill, [(tail_x-7, b.bottom-4), (tail_x+7, b.bottom-4), (tail_x-3, b.bottom+8)])

# ---------- TROLLS (+ yetis, aliens, scorpions, peppermint trolls): walk cycle, arm swing, bob, blink, mouth, lean, turn squash ----------
def _troll_eye_dx(t): return int(5*math.sin(pygame.time.get_ticks()/180)) if t.searching else 0
def toon_troll_base(t):   # -> (cache key, picture): the SAME troll art as before, from caches
    th = THEME[0]; mean = isinstance(t, GreenTroll); eye = _troll_eye_dx(t); tk = pygame.time.get_ticks()
    if th == "candy":
        ang = (t.step // 4) % 24; return ("pep", mean, ang, eye), candy_troll_image(t)
    if th == "space":
        f = ((tk + (id(t) % 500))//90) % 8
        return ("alien", mean, eye, f), _th_c(("troll_t", th, mean, eye, f), lambda: _toon_alien(mean, eye, troll_cols(t), f))
    if th == "desert":
        lf = (t.step // 2) % 6 if t.moving else 0
        tf = int(round(3 + 3*math.sin(tk/320.0 + id(t) % 13)))
        return ("scorp", mean, eye, lf, tf), _th_c(("troll_t", th, mean, eye, lf, tf), lambda: _toon_scorpion(mean, eye, troll_cols(t), lf, tf))
    if th == "snow":
        return ("yeti", mean, eye), _th_c(("troll", th, mean, eye), lambda: _make_theme_troll(th, mean, eye, troll_cols(t)))
    cols = t.cols if mean else ((70,70,70), (120,120,120), (150,150,150))
    img = troll_face_img(cols, eye)
    if th == "dungeon" and not mean:
        def stone():
            im = img.copy(); im.fill((150,150,170,255), special_flags=pygame.BLEND_RGBA_MULT)
            g = pygame.Surface(im.get_size(), pygame.SRCALPHA); g.fill((18,18,26,0)); im.blit(g, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
            return im
        return ("stone", eye), _th_c(("stone_t", eye), stone)
    return ("cls", cols, eye), img
def _toon_alien(mean, eye, cols, f):   # the same silly alien, antennae bobbling (8 frames)
    line, body, light = cols
    s = pygame.Surface((64,64), pygame.SRCALPHA)
    for k_, ax in enumerate((20, 44)):
        w = 2.5*math.sin(f/8.0*2*math.pi + k_*1.9); tip = (int(ax + w), int(5 + 0.6*abs(w)))
        pygame.draw.line(s, line, (32 + (ax-32)//3, 14), tip, 3)
        for k in range(3): pygame.draw.circle(s, (255,255,120, 60 + k*50), tip, 7 - k*2)
        pygame.draw.circle(s, (255,250,170), tip, 3)
    pygame.draw.ellipse(s, body, (12,12,40,48)); pygame.draw.ellipse(s, light, (18,16,16,12))
    pygame.draw.ellipse(s, light, (20,40,24,14))
    pygame.draw.ellipse(s, line, (12,12,40,48), 2)
    if mean:
        for (x, y, r) in ((22,26,5), (32,21,6), (42,26,5)): _googly(s, x + eye//2, y, r, eye)
    else: _googly(s, 32 + eye//2, 26, 9, eye)
    pygame.draw.arc(s, line, (24,32,16,10), 3.5, 5.9, 2)
    return s.convert_alpha()
def _toon_scorpion(mean, eye, cols, lf, tf):   # the same cartoon scorpion: legs scuttle (6 frames), tail sways (7 frames)
    line, body, light = cols
    s = pygame.Surface((64,64), pygame.SRCALPHA)
    for k in range(3):   # scuttling legs: each pair is a step apart (a ripple down the side)
        for sd in (-1, 1):
            a = lf/6.0*2*math.pi + k*2.1 + (0 if sd < 0 else math.pi)
            hip = (32 + sd*10, 38 + k*6); knee = (32 + sd*17 + sd*1.5*math.cos(a), 36 + k*6 - 1.5*max(0, math.sin(a)))
            foot = (32 + sd*21 + sd*2.5*math.cos(a), 43 + k*7 - 2.5*max(0, math.sin(a)))
            pygame.draw.lines(s, line, False, [hip, knee, foot], 3)
    pygame.draw.ellipse(s, body, (16,30,32,26)); pygame.draw.ellipse(s, light, (21,33,14,8))
    for y in (40, 46): pygame.draw.arc(s, line, (18, y-6, 28, 12), 3.4, 6.0, 1)
    pygame.draw.ellipse(s, line, (16,30,32,26), 2)
    sw = (tf - 3)/3.0
    pts = [(40,52), (48,44), (52,32), (50,20), (44,12), (36,10)]
    pts = [(p[0] + sw*1.3*k, p[1] - abs(sw)*0.4*k) for k, p in enumerate(pts)]   # the tail sways, more at the tip
    for k, p in enumerate(pts):
        r = 6 - k//2; p = (int(p[0]), int(p[1]))
        pygame.draw.circle(s, line, p, r + 1); pygame.draw.circle(s, body, p, r); pygame.draw.circle(s, light, (p[0]-1, p[1]-1), max(1, r//2))
    tx, ty = pts[-1]
    pygame.draw.polygon(s, (120,40,20), [(tx, ty - 4), (tx - 6, ty + 2), (tx + 1, ty + 4)])
    pygame.draw.ellipse(s, body, (20,24,24,16)); pygame.draw.ellipse(s, line, (20,24,24,16), 2)
    for x in (27, 37):
        pygame.draw.circle(s, (30,20,20), (x + eye//2, 31), 3); pygame.draw.circle(s, WHITE, (x + eye//2 - 1, 30), 1)
    if mean: pygame.draw.line(s, (90,30,10), (24,26), (30,28), 2); pygame.draw.line(s, (90,30,10), (40,26), (34,28), 2)
    return s.convert_alpha()
def _troll_face_spec(th, mean):   # eyes [(x, y, r)], how far the eyes slide, mouth (x, y, w)
    if th == "space": return ([(22,26,5), (32,21,6), (42,26,5)] if mean else [(32,26,9)]), 0.5, (32,38,10)
    if th == "desert": return [(27,31,3), (37,31,3)], 0.5, (32,38,6)
    if th == "snow": return [(27,17,3), (37,17,3)], 0.5, (32,24,8)
    return [(26,17,4), (38,17,4)], 1.0, (32,28,10)
def _toon_troll_face(bkey, base, th, mean, cols, eye, blink, oh):
    def mk():
        s = base.copy(); eyes, ek, (mx, my, mw) = _troll_face_spec(th, mean)
        ink = _dark(cols[0], 20) if th not in ("candy",) else (120,40,50)
        if th in ("space", "desert"): lid0 = cols[1]
        elif th == "snow": lid0 = (80,120,200) if mean else (110,160,225)
        else: lid0 = None   # trolls / peppermints: the eyelid is the same color as the head just above the eye
        if blink:
            for (x, y, r) in eyes:
                x = int(x + eye*ek)
                lid = lid0 or tuple(base.get_at((x, max(0, y - r - 2))))[:3]
                if blink == 2:
                    pygame.draw.circle(s, lid, (x, y), r + 1)
                    pygame.draw.arc(s, ink, (x - r, y - r//2 - 1, 2*r, r + 2), math.pi + 0.2, 2*math.pi - 0.2, 2)
                else:
                    _half_clip(s, pygame.Rect(x - r - 2, y - r - 2, 2*r + 4, r + 2), lambda: pygame.draw.circle(s, lid, (x, y), r + 1))
                    pygame.draw.line(s, ink, (x - r, y), (x + r, y), 2)
        if th == "desert":   # little mandibles clicking open and shut
            o = oh*0.8
            for sd in (-1, 1):
                pygame.draw.line(s, ink, (mx + sd*2, my - 1), (mx + sd*(3 + o), my + 4), 2)
        elif oh <= 1 and th not in ("space", "snow"):
            pygame.draw.arc(s, ink, (mx - mw//2 + 1, my - 1, mw - 2, 5), 0.35, math.pi - 0.35, 2)   # closed grumpy mouth
        elif oh >= 2:
            h = oh + 1; r = pygame.Rect(mx - mw//2, my - h//2, mw, h)
            pygame.draw.ellipse(s, (70,18,30), r)
            if oh >= 4: pygame.draw.ellipse(s, (230,100,120), (r.x + 2, r.bottom - 3, r.w - 4, 3))   # tongue
            pygame.draw.polygon(s, WHITE, [(r.x + 2, r.y + 1), (r.x + 4, r.y + 1), (r.x + 3, r.y + min(4, h - 1))])   # little fangs
            pygame.draw.polygon(s, WHITE, [(r.right - 4, r.y + 1), (r.right - 2, r.y + 1), (r.right - 3, r.y + min(4, h - 1))])
            pygame.draw.ellipse(s, ink, r, 1)
        return s
    return _toon_c(("tface", bkey, blink, oh), mk)
TURN_FR = 9
def toon_troll_anim(t):   # per-troll animation state, updated once a frame: facing, turn squash, springy lean
    tk = pygame.time.get_ticks(); a = t.__dict__.get("_toon")
    if a is None: a = t._toon = {"tk": -1, "face": 1, "turn": 0, "lean": 0.0, "lv": 0.0, "chase": False, "pl": [0.0, 0.0]}
    if a["tk"] == tk: return a
    a["tk"] = tk
    vx, vy = clay_vel(t)
    if abs(vx) > 0.25:
        f = 1 if vx > 0 else -1
        if f != a["face"]: a["face"] = f; a["turn"] = TURN_FR   # changing direction: a quick squash, then stretch
    if a["turn"] > 0: a["turn"] -= 1
    a["chase"] = is_mean(t) and t.moving and not t.searching
    lunging = getattr(t, "lunge", 0) > 0
    tgt = -a["face"]*(11.0 if (a["chase"] or lunging) else 3.0) if (t.moving and abs(vx) > 0.25) else 0.0   # mean trolls lean INTO the chase
    a["lv"] = a["lv"]*0.72 + (tgt - a["lean"])*0.16; a["lean"] += a["lv"]
    return a
def toon_mouth(t, an):   # how open the mouth is (0..6)
    tk = pygame.time.get_ticks()
    if getattr(t, "grr_t", 0) > 0: return 6
    if getattr(t, "crouch", 0) > 0: return 1                              # anticipation: mouth clamped shut
    if getattr(t, "lunge", 0) > 0: return 6
    if an["chase"]: return 2 + int(round(4*abs(math.sin(tk/85.0 + id(t) % 7))))   # chomp chomp
    if t.searching: return 2 if (tk//400) % 3 == 0 else 1
    if t.moving: return int(round(1 + 2*abs(math.sin(t.step*0.14))))     # huffing along with the steps
    return 1 if math.sin(tk/900.0 + id(t) % 11) < 0.85 else 2             # idle: closed, a little "hmph" now and then
def _toon_limb(p0, p1, side, k, c_out, c_in, w_out, w_in, bend=3.0):   # two-part arm / leg with a bendy joint
    mx, my = (p0[0] + p1[0])/2.0, (p0[1] + p1[1])/2.0
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]; L = math.hypot(dx, dy) or 1
    j = (mx - dy/L*bend*side*k, my + dx/L*bend*side*k)
    for col, w in ((c_out, w_out), (c_in, w_in)):
        pygame.draw.line(screen, col, p0, j, w); pygame.draw.line(screen, col, j, p1, w)
        pygame.draw.circle(screen, col, (int(j[0]), int(j[1])), max(1, w//2))
    return j
def draw_troll_legs(t, cx, cy, k=1.0, bob=0, lean=0.0):   # walk cycle: hip -> knee -> foot, feet plant (squash) and lift (tip-toe)
    ph = t.step * 0.28; an = t.__dict__.get("_toon"); th = THEME[0]
    for i, side in enumerate((-1, 1)):
        a = ph + (0 if side < 0 else math.pi)
        lift = max(0.0, 4.5*math.sin(a))*k if t.moving else 0
        sw = 3.5*math.cos(a)*k if t.moving else 0
        hx, hy = t.rect.centerx + side*9*k - cx - 0.2*lean, t.rect.y + 52*k - cy + bob*0.7
        fx, fy = hx + sw + 0.2*lean, t.rect.y + 68*k - lift - cy
        if an is not None:   # a little dust puff when a foot stomps down
            pl = an["pl"][i]; an["pl"][i] = lift
            if t.moving and pl > 0.8 and lift <= 0.8 and len(KICK) < 14 and th not in ("space",):
                KICK.append([fx + cx, fy + cy + 2, side*0.5, -0.3, 26, _KICK_COL.get(th, (210,230,170))])
        planted = lift < 0.8
        fw, fh = (20*k, 9*k) if planted else (15*k, 10*k)
        if CANDY[0] and isinstance(t, Troll):   # peppermint legs with round mint feet
            st_, rim_ = mint_cols(t)
            kx, ky = (hx + fx)/2 + side*2*k, (hy + fy)/2 - lift*0.3
            candy_stick((hx, hy), (kx, ky), int(7*k), st_, rim_); candy_stick((kx, ky), (fx, fy), int(7*k), st_, rim_)
            pygame.draw.ellipse(screen, rim_, (fx-fw/2-1, fy-fh/2, fw+2, fh+2)); pygame.draw.ellipse(screen, WHITE, (fx-fw/2, fy-fh/2+1, fw, fh))
            pygame.draw.line(screen, st_, (fx-4*k, fy-2*k), (fx+2*k, fy+4*k), max(1, int(3*k)))
            continue
        tc = troll_cols(t) if isinstance(t, Troll) else getattr(t, "cols", ((70,70,70), (120,120,120), (150,150,150)))
        _toon_limb((hx, hy), (fx, fy), side, k, tc[0], tc[1], int(9*k), int(6*k), bend=1.5 + lift*0.5)
        pygame.draw.ellipse(screen, tc[0], (fx-fw/2-1, fy-fh/2-1, fw+2, fh+2))
        pygame.draw.ellipse(screen, tc[2], (fx-fw/2, fy-fh/2, fw, fh))   # round foot: flat + wide when planted, tipped when lifted
def blit_troll(timg, x, y, t_):   # clay squash + breathing + boil (kept), PLUS turn squash and the chase lean
    t = pygame.time.get_ticks(); sd = id(t_) % 97
    sx, sy = clay_squash(t_, t_.moving, getattr(t_, "step", 0)*0.28, walk=0.05, breath=0.045)
    an = t_.__dict__.get("_toon")
    if an and an["turn"] > 0:
        u = 1 - an["turn"]/float(TURN_FR); q = 0.15*math.sin(2*math.pi*u)*(1 - 0.5*u); sx *= 1 + q; sy *= 1 - q
    bx, by = clay_boil(sd + 31, 0.9, t)
    sway = (0.5 if t_.moving else 1.6)*math.sin(t/1270.0 + sd)
    im = clay_scaled(timg, sx, sy); w, h = timg.get_size(); iw, ih = im.get_size()
    X = x + w/2.0 + sway + bx; Y = y + h - ih/2.0 + by
    lean = int(round(an["lean"])) if an else 0
    if lean:
        im = pygame.transform.rotate(im, lean); X -= (ih/2.0)*math.sin(math.radians(lean))   # pivot on the feet
    r = im.get_rect(center=(int(round(X)), int(round(Y)))); screen.blit(im, r)
def draw_troll_hand(hx, hy, sx, sy, tc, grabby, tick_now, side, ph=None):   # Nov 4: troll hands have THREE chunky 8-bit cartoon fingers
    ga = math.atan2(hy - sy, hx - sx)                                     # fingers point along the forearm (they follow the arm swing)
    if grabby: op = 0.52 + 0.20*math.sin(tick_now/60.0 + side)            # grabby: the fingers open and close
    elif ph is not None: op = 0.50 + 0.08*math.sin(ph + 1.2)              # walking: a little flex with each swing
    else: op = 0.48 + 0.04*math.sin(tick_now/650.0 + side)                # idle: relaxed, breathing
    hx_, hy_ = int(hx), int(hy)
    tips = []
    for fs in (-1, 0, 1):
        fa = ga + fs*op; L = 10 if fs == 0 else 9
        tips.append((hx + L*math.cos(fa), hy + L*math.sin(fa)))
    for (px, py) in tips:                                                  # dark outline first, then the light fill (bold 8-bit look)
        pygame.draw.line(screen, tc[0], (hx_, hy_), (int(px), int(py)), 6); pygame.draw.circle(screen, tc[0], (int(px), int(py)), 4)
    for (px, py) in tips:
        pygame.draw.line(screen, tc[2], (hx_, hy_), (int(px), int(py)), 3); pygame.draw.circle(screen, tc[2], (int(px), int(py)), 3)
    pygame.draw.circle(screen, tc[0], (hx_, hy_), 6); pygame.draw.circle(screen, tc[2], (hx_, hy_), 5)   # palm on top

def draw_troll_full(t, cx, cy, players, tick_now):   # one troll, every animated part (looks only)
    if not (-160 < t.rect.x - cx < WIDTH + 160 and -160 < t.rect.y - cy < HEIGHT + 160): return
    an = toon_troll_anim(t); th = THEME[0]; mean = isinstance(t, GreenTroll)
    ph = t.step * 0.28
    bob = -int(round((3.2 if an["chase"] else 2.2)*abs(math.sin(ph)))) if t.moving else int(round(0.8*math.sin(tick_now/700.0 + id(t) % 13)))
    lean = an["lean"]
    near = min(players, key=lambda pf: math.hypot(pf.rect.centerx-t.rect.centerx, pf.rect.centery-t.rect.centery))
    ddx, ddy = near.rect.centerx-t.rect.centerx, near.rect.centery-t.rect.centery
    dist = math.hypot(ddx, ddy) or 1
    for side in (-1, 1):
        a = ph + (0 if side < 0 else math.pi)
        sx, sy = t.rect.centerx + side*15 - cx - 0.45*lean, t.rect.y + 38 - cy + bob   # shoulder rides the body bob + lean
        RR = MEAN_NOTICE if is_mean(t) else TROLL_REACH
        grabby = dist < RR
        if grabby:
            reach = 14 + (RR - dist) / RR * 42
            ux, uy = ddx/dist, ddy/dist
            wig = 4*math.sin(tick_now/70 + side)
            hx = sx + ux*reach - uy*wig*side; hy = sy + uy*reach + ux*wig*side
        elif t.moving:   # arms swing opposite to the legs
            sa = math.sin(a)
            hx, hy = sx + side*(8 + 3*max(0.0, -sa)), sy + 20 + 5*sa
            if an["chase"]: hy -= 4
        else:            # idle: arms hang and breathe
            br = math.sin(tick_now/650.0 + side*0.6 + id(t) % 7)
            hx, hy = sx + side*(8 + 1.2*br), sy + 20 + 1.5*br
        if CANDY[0]:
            st_, rim_ = mint_cols(t); candy_stick((sx, sy), (hx, hy), 6, st_, rim_)
            pygame.draw.circle(screen, rim_, (int(hx), int(hy)), 6); pygame.draw.circle(screen, WHITE, (int(hx), int(hy)), 5)
            pygame.draw.circle(screen, st_, (int(hx), int(hy)), 2)
            continue
        tc = troll_cols(t)
        if th == "desert": draw_pincer(hx, hy, hx - sx, hy - sy, tc); continue
        _toon_limb((sx, sy), (hx, hy), side, 1.0, tc[0], tc[1], 9, 6, bend=3.0)   # elbow
        draw_troll_hand(hx, hy, sx, sy, tc, grabby, tick_now, side, a if t.moving else None)   # THREE chunky fingers
    if th != "desert": draw_troll_legs(t, cx, cy, bob=bob, lean=lean)
    bkey, base = toon_troll_base(t)
    tb = toon_blink(id(t) % 89 + 3, tick_now)
    if t.searching and tb == 0 and (tick_now // 140) % 9 == 0: tb = 1   # squinting around while it looks for you
    oh = toon_mouth(t, an)
    timg = _toon_troll_face(bkey, base, th, mean, troll_cols(t), _troll_eye_dx(t), tb, oh)
    hf = getattr(t, "hit_flash", 0); wob = 0
    if hf > 0:
        wob = int(5*math.sin(hf*1.3))
        if (hf//4) % 2 == 0: timg = timg.copy(); timg.fill((140,140,140), special_flags=pygame.BLEND_RGB_ADD)
    cr_, lg_ = getattr(t, "crouch", 0), getattr(t, "lunge", 0); oy_ = 0
    if cr_ > 0 or lg_ > 0:   # telegraphed lunge: squash down low (anticipation), then stretch out
        w_, h_ = timg.get_size(); k_ = (1.18, 0.80) if cr_ > 0 else (0.88, 1.12)
        timg = pygame.transform.smoothscale(timg, (int(w_*k_[0]), int(h_*k_[1])))
        wob += (w_ - timg.get_width())//2; oy_ = h_ - timg.get_height()
    blit_troll(timg, t.rect.x-cx+wob, t.rect.y-cy+oy_+bob, t)
    if cr_ > 0:
        ex_ = EX_FONT.render("!", True, (255,70,50))
        screen.blit(ex_, (t.rect.centerx-cx-ex_.get_width()//2, t.rect.y-cy-ex_.get_height()-4 - (cr_ % 6 < 3)*3))
    if getattr(t, "max_hp", 1) > 1:
        for k in range(t.max_hp):
            px, py = t.rect.centerx-cx - (t.max_hp-1)*7 + k*14, t.rect.y-cy - 8
            pygame.draw.circle(screen, WHITE, (px, py), 6); pygame.draw.circle(screen, (60,200,90) if k < t.hp else (190,190,200), (px, py), 4)
    if t.searching:
        screen.blit(font.render("?",True,YELLOW),(t.rect.centerx-cx-8,t.rect.y-cy-36 + int(3*math.sin(tick_now/150.0))))   # the "?" bobs

# ---------- BOSS TROLL: stomping body bob + blinks ----------
def toon_boss_bob(b):
    if b.moving: return -int(round(4*abs(math.sin(b.step*0.18))))
    return int(round(1.5*math.sin(pygame.time.get_ticks()/600.0)))
_boss_eyes_old = Boss.draw_eyes
def _toon_boss_eyes(self, cx, cy, glow=False):
    _boss_eyes_old(self, cx, cy, glow)
    bl = toon_blink(71, per=2900)
    if not bl: return
    bx, by = self.rect.centerx-80-cx, self.rect.centery-85-cy + toon_boss_bob(self)
    for ex in (66, 94):
        r = pygame.Rect(bx+ex-10, by+43, 20, 18 if bl == 2 else 9)
        pygame.draw.ellipse(screen, (68,150,56), r) if bl == 2 else pygame.draw.rect(screen, (68,150,56), r, border_top_left_radius=9, border_top_right_radius=9)
        pygame.draw.line(screen, (35,90,30), (bx+ex-9, by+52 if bl == 2 else by+51), (bx+ex+9, by+52 if bl == 2 else by+51), 3)
Boss.draw_eyes = _toon_boss_eyes

# ---------- SMOG THE DRAGON: 8-frame eased wing flap (slow lift, fast downstroke), body rides the flaps, blinks ----------
DRAGON_WY = [2, -4, -10, -16, -21, -24, -13, -3]
DRAGON_LIFT = [1, 0, -1, -1, -2, -2, 1, 3]   # body sinks as the wings lift, jumps up on the downstroke
def toon_dragon_flap(t): return (t // 70) % 8
def toon_dragon_img(flap, fc, t):
    bl = toon_blink(29, t, 3600)
    def mk():
        s = _make_dragon(flap).copy()
        if bl:
            for x in (104, 136):
                if bl == 2: pygame.draw.circle(s, (150,70,190), (x, 55), 11)
                else: _half_clip(s, pygame.Rect(x - 12, 43, 24, 12), lambda: pygame.draw.circle(s, (150,70,190), (x, 55), 11))
                pygame.draw.line(s, (90,35,120), (x - 9, 55), (x + 9, 55), 3)
        return pygame.transform.flip(s, True, False) if fc < 0 else s
    return _toon_c(("dragon_t", flap, bl, fc < 0), mk)

# ---------- DORFGHAN: cartoon eyes, beard + hat tip sway, breathing, mouth moves when he talks ----------
def _toon_make_wizard(blink, sw, mouth):
    s = pygame.Surface((90,120), pygame.SRCALPHA)
    ROBE, ROBE2 = (90,80,200), (130,120,235)
    pygame.draw.polygon(s, ROBE, [(45,40),(72,116),(18,116)])
    pygame.draw.polygon(s, ROBE2, [(45,40),(52,116),(30,116)])
    pygame.draw.circle(s, (200,195,205), (45,38), 15)
    pygame.draw.polygon(s, (200,195,205), [(32,32),(30,18),(40,28)]); pygame.draw.polygon(s, (200,195,205), [(58,32),(60,18),(50,28)])
    pygame.draw.polygon(s, WHITE, [(33,44),(57,44),(45 + sw,80)])                                 # long white beard (sways)
    pygame.draw.polygon(s, (80,70,190), [(22,30),(68,30),(50 + sw*0.8,0),(46 + sw*0.8,0)])       # pointy hat (tip flops)
    pygame.draw.ellipse(s, (70,60,170), (16,24,58,12))
    pygame.draw.rect(s, (130,80,40), (76,30,5,86), border_radius=2)
    pygame.draw.circle(s, (225,230,240), (78,80), 6); pygame.draw.circle(s, (225,230,240), (24,80), 6)
    _shade(s, 190)
    s = _outline(s)
    for sx, sy in ((40 + int(sw*0.3),14),(52,22),(33,26)):
        pygame.draw.polygon(s, GOLD, [(sx,sy-4),(sx+1,sy-1),(sx+4,sy),(sx+1,sy+1),(sx,sy+4),(sx-1,sy+1),(sx-4,sy),(sx-1,sy-1)])
    for sx, sy in ((34,96),(52,104),(44,84)): pygame.draw.circle(s, GOLD, (sx,sy), 2)
    for ex in (39, 51):   # classic cartoon eyes: white, round black pupil (no anime shine)
        if blink == 2: pygame.draw.arc(s, (60,60,90), (ex-3, 34, 7, 6), math.pi + 0.3, 2*math.pi - 0.3, 2)
        else:
            pygame.draw.ellipse(s, (60,60,90), (ex-3, 33, 7, 9)); pygame.draw.ellipse(s, WHITE, (ex-2, 34, 5, 7))
            pygame.draw.circle(s, (20,20,40), (ex, 38), 2)
            if blink == 1: pygame.draw.rect(s, (200,195,205), (ex-3, 33, 7, 4)); pygame.draw.line(s, (60,60,90), (ex-3, 37), (ex+3, 37), 1)
    pygame.draw.line(s, (120,115,130), (35,31), (42,32), 2); pygame.draw.line(s, (120,115,130), (48,32), (55,31), 2)   # bushy brows
    pygame.draw.circle(s, (40,25,35), (45,44), 2)
    if mouth: pygame.draw.ellipse(s, (90,40,60), (42,47,7,5))   # talking
    else: pygame.draw.line(s, (150,140,160), (42,48), (48,48), 1)
    return s
def toon_wizard_img(t):
    bl = toon_blink(41, t, 3200); sw = int(round(3*math.sin(t/650.0)))
    mo = globals().get("wizard_talk", 0) > 0 and (t // 120) % 2 == 0
    return _toon_c(("wiz", bl, sw, mo), lambda: _ready(_toon_make_wizard(bl, sw, mo)))
def toon_breath_blit(img, x, y, obj, amp=0.025, per=520.0):   # weighty eased breathing, standing on the same feet
    u = _ease(0.5 + 0.5*math.sin(pygame.time.get_ticks()/per + (id(obj) % 13)))
    clay_blit(screen, img, x, y, 1 - 0.5*amp*(2*u - 1), 1 + amp*(2*u - 1))

# ---------- FROGS: cartoon eyes, throat puffing in and out, blinks ----------
_FROG2 = {}
def frog_img(col, blink, puff=0):
    key = (col, blink, puff)
    if key not in _FROG2:
        s = pygame.Surface((44,36), pygame.SRCALPHA)
        pygame.draw.ellipse(s, col, (4,12,36,22))
        pygame.draw.ellipse(s, _light(col, 60), (12,20,20,12))
        for ex in (13, 31): pygame.draw.circle(s, col, (ex, 12), 8)
        pygame.draw.ellipse(s, _dark(col, 30), (0,26,14,8)); pygame.draw.ellipse(s, _dark(col, 30), (30,26,14,8))
        if puff: pygame.draw.ellipse(s, _light(col, 95), (22 - 4 - puff*2, 24 - puff, 8 + puff*4, 5 + puff*2))   # throat puffs out
        _shade(s, 185); s = _outline(s)
        for ex in (13, 31):
            if blink: pygame.draw.arc(s, (40,100,45), (ex-5, 9, 10, 6), math.pi + 0.3, 2*math.pi - 0.3, 2)
            else:
                pygame.draw.circle(s, (40,90,45), (ex, 12), 6); pygame.draw.circle(s, WHITE, (ex, 12), 5)
                pygame.draw.circle(s, (20,20,25), (ex + (1 if ex > 22 else -1), 13), 2)
        pygame.draw.arc(s, (40,100,45), (16,18,12,8), math.pi+0.3, 2*math.pi-0.3, 2)
        _FROG2[key] = s
    return _FROG2[key]
def toon_throat(t): return (0, 1, 2, 3, 3, 2, 1, 0, 0, 0, 0, 0)[(t // 110) % 12]

# ---------- SHOO BALL + the pet ball: cartoon eyes, blinks, squash when she lands, mouth talks ----------
def _toon_make_shoo(shoo, blink, talk):
    S = 4; R = 22*S; W = R*2 + 8*S
    s = pygame.Surface((W, W), pygame.SRCALPHA); c = W//2
    pygame.draw.circle(s, (40,120,50), (c, c), R + 5*S)
    pygame.draw.circle(s, (70,200,80), (c, c), R)
    pygame.draw.circle(s, (110,235,110), (c - 4*S, c - 4*S), R - 4*S)
    pygame.draw.ellipse(s, (190,255,180), (c - R*0.62, c - R*0.78, R*0.7, R*0.38))
    ey = c - 3*S
    for ex in (c - 9*S, c + 9*S):   # classic cartoon eyes: white ovals, black pupils
        if blink == 2: pygame.draw.arc(s, (30,40,60), (ex - 5*S, ey - 3*S, 10*S, 6*S), math.pi + 0.3, 2*math.pi - 0.3, 2*S)
        else:
            pygame.draw.ellipse(s, (30,40,60), (ex - 5*S, ey - 7*S, 10*S, 14*S)); pygame.draw.ellipse(s, WHITE, (ex - 4*S, ey - 6*S, 8*S, 12*S))
            pygame.draw.ellipse(s, (20,25,40), (ex - 2*S, ey - 2*S, 5*S, 7*S))
            if blink == 1: pygame.draw.rect(s, (110,235,110), (ex - 5*S, ey - 8*S, 10*S, 7*S)); pygame.draw.line(s, (30,40,60), (ex - 5*S, ey - S), (ex + 5*S, ey - S), S)
    blush = pygame.Surface((10*S, 5*S), pygame.SRCALPHA); pygame.draw.ellipse(blush, (255,120,150,140), blush.get_rect())
    s.blit(blush, (c - 19*S, c + 4*S)); s.blit(blush, (c + 9*S, c + 4*S))
    my = c + 7*S
    if shoo or talk:
        pygame.draw.ellipse(s, (120,30,50), (c - 5*S, my - 3*S, 10*S, 10*S if shoo else 6*S))
        pygame.draw.ellipse(s, (255,120,140), (c - 3*S, my + (2*S if shoo else 0), 6*S, 4*S if shoo else 3*S))
    else: pygame.draw.arc(s, (40,90,45), (c - 4*S, my - 4*S, 8*S, 6*S), math.pi, 2*math.pi, 2*S)
    k = SHOO_R / (22*S); s = pygame.transform.smoothscale(s, (max(1, int(W*k)), max(1, int(W*k))))
    return _ready(s)
def toon_draw_shoo(shoo, talking, x, y, bob):
    t = pygame.time.get_ticks(); bl = toon_blink(13, t)
    tk = talking and (t // 130) % 2 == 0
    img = _toon_c(("shoo", shoo, bl, tk), lambda: _toon_make_shoo(shoo, bl, tk))
    amp = 6 if (shoo or talking) else 3; q = max(0.0, 1 - bob/(0.35*amp + 0.01))   # squash as she touches down
    sx, sy = 1 + 0.12*q, 1 - 0.12*q + 0.04*(1 - q)
    im = clay_scaled(img, sx, sy)
    screen.blit(im, (x - im.get_width()//2, int(y + img.get_height()//2 - im.get_height() - bob)))
_SPIRIT = {}
def toon_draw_spirit(cx, cy):   # the pet ball: hops, blinks
    t = pygame.time.get_ticks(); bl = toon_blink(17, t)
    if bl not in _SPIRIT:
        s = spirit.image.copy()
        if bl:
            for ex in (12, 24):
                pygame.draw.circle(s, (110,220,110), (ex, 15), 6)
                pygame.draw.arc(s, (60,35,80), (ex-4, 12, 8, 6), math.pi + 0.3, 2*math.pi - 0.3, 2) if bl == 2 else pygame.draw.line(s, (60,35,80), (ex-4, 15), (ex+4, 15), 2)
        _SPIRIT[bl] = s
    b = abs(math.sin(t/260.0)); hop = int(round(5*b)); q = max(0.0, 1 - b/0.3)
    clay_blit(screen, _SPIRIT[bl], spirit.rect.x - cx, spirit.rect.y - cy - hop, 1 + 0.1*q, 1 - 0.1*q)

# ---------- ELEMENTS ----------
def draw_statue_wink(st):   # the golden fox statue winks at you now and then
    u = pygame.time.get_ticks() % 7000
    if u > 420: return
    ex, ey = st.x + st.w//2 + 7, st.y + 19
    col = STATUE_IMG.get_at((20 + st.w//2 + 7 + 5, 20 + 23))[:3]
    pygame.draw.ellipse(screen, col, (ex - 4, ey - 1, 8, 10))
    pygame.draw.arc(screen, (90,50,20), (ex - 4, ey + 1, 8, 6), 0.3, math.pi - 0.3, 2)
_house_anim_old = draw_house_anim
def draw_house_anim(o, x, y):   # + the front door swings open when a fox walks up (looks only - the door spot is the same)
    _house_anim_old(o, x, y)
    if not isinstance(o, House): return
    if not (-150 < x < WIDTH + 20 and -150 < y < HEIGHT + 20): return
    pl = [fox] + ([fox2] if globals().get("two_player") else [])
    dc = o.door.center
    near = any(math.hypot(p.rect.centerx - dc[0], p.rect.centery - dc[1]) < 120 for p in pl)
    d = getattr(o, "_door", 0.0); v = getattr(o, "_doorv", 0.0)
    v = v*0.7 + ((1.0 if near else 0.0) - d)*0.2; d = max(0.0, min(1.0, d + v)); o._door, o._doorv = d, v   # springy swing
    if d < 0.03: return
    dx, dy, w, h = x + 46, y + 74, 28, 36
    pygame.draw.rect(screen, (70,40,35), (dx, dy, w, h), border_top_left_radius=14, border_top_right_radius=14)   # dark doorway
    g = _toon_c("doorglow", lambda: _soft_blob(28, 30, (255,200,120), 170, 6)); screen.blit(g, (dx, dy + 8))
    wd = max(4, int(round(w*(1 - 0.78*d))))
    pygame.draw.rect(screen, (140,88,52), (dx - 1, dy - 1, wd + 2, h + 1), border_top_left_radius=12, border_top_right_radius=3)
    pygame.draw.rect(screen, (175,115,70), (dx, dy, wd, h), border_top_left_radius=12, border_top_right_radius=2)
    if wd > 8: pygame.draw.circle(screen, (255,215,90), (dx + wd - 4, dy + h//2 + 3), 2)
_blit_item_clay = blit_item
def blit_item(s, cx, cy):   # + the dizzy cupcakes / mushrooms wobble like jelly, sticks and stones give a little hop now and then
    if s.type == "mushroom":
        x, y = s.rect.x - cx, s.rect.y - cy
        if not (-60 < x < WIDTH + 30 and -60 < y < HEIGHT + 30): return
        t = pygame.time.get_ticks(); col = _GLOW_KIND.get(s.type)
        if col:
            g = _an_c(("iglow2", col), lambda: _soft_blob(70, 70, col, 120, 9))
            g.set_alpha(int(90 + 140*_ease(0.5 + 0.5*math.sin(t/650.0 + s.rect.x*0.03))))
            screen.blit(g, (s.rect.centerx - cx - 35, s.rect.centery - cy - 35))
        b = abs(math.sin(t/760.0 + s.rect.x*0.05)); bob = -int(round(3.5*b))
        q = max(0.0, 1 - b/0.3)
        im = clay_scaled(s.image, 1 + 0.08*q, 1 - 0.08*q)
        ang = int(round(7*math.sin(t/230.0 + s.rect.x)))   # dizzy jelly wobble
        if ang: im = pygame.transform.rotate(im, ang)
        w, h = s.image.get_size()
        screen.blit(im, im.get_rect(midbottom=(x + w//2, y + h + bob))); return
    if s.type in ("stone", "stick"):
        t = pygame.time.get_ticks(); u = (t + s.rect.x*31 + s.rect.y*7) % 5200
        if u < 360:   # boing!
            hop = int(round(6*math.sin(math.pi*u/360.0)))
            ry = s.rect.y; s.rect.y -= hop
            try: return _blit_item_clay(s, cx, cy)
            finally: s.rect.y = ry
    return _blit_item_clay(s, cx, cy)

# ================= SNOWY FOX VILLAGE (Faroe Nov 3) - level 6 (snow) ONLY: ice-brick buildings + snowy pine trees =================
# Looks only: every picture is the SAME size as before, so positions, hitboxes and doors are exactly the same.
ICE_LINE = (70,100,140)
def _ice_tint(wall):   # each house keeps a faint hint of its old wall color, so they still look different
    return _lerp((206,230,248), wall, 0.12)
def _ice_bricks(w, h, rect, base_col, bh=10, bw=20, seed=0, curve=None):
    lay = pygame.Surface((w, h), pygame.SRCALPHA); rr = random.Random(seed)
    mort = _lerp(base_col, (140,180,220), 0.55)
    lay.fill(mort + (255,), rect)
    for row, y in enumerate(range(rect.y, rect.bottom, bh)):
        off = (bw//2 if row % 2 else 0)
        for x in range(rect.x - off, rect.right, bw):
            c = _lerp(base_col, (240,250,255), rr.uniform(0.0, 0.35))
            r = pygame.Rect(x + 1, y + 1, bw - 2, bh - 2)
            pygame.draw.rect(lay, c, r, border_radius=3)
            pygame.draw.line(lay, (250,253,255), (r.x + 2, r.y + 1), (r.right - 4, r.y + 1), 1)                 # frosty top edge
            pygame.draw.line(lay, _lerp(c, (120,165,210), 0.45), (r.x + 2, r.bottom - 1), (r.right - 2, r.bottom - 1), 1)
            if rr.random() < 0.25: pygame.draw.line(lay, (255,255,255), (r.x + 4, r.y + 3), (r.x + 7, r.y + 6), 1)   # little shine in the ice
    return lay
def _ice_cottage(w, h, wall, roof, base=52, roof_h=46, chimney_x=None):   # same shape as the cottage, built from ice bricks
    s = pygame.Surface((w, h), pygame.SRCALPHA); ice = _ice_tint(wall)
    if chimney_x is not None:   # ice-block chimney
        cx = chimney_x; top = int(_roof_y(cx, w, base, roof_h)) - 14
        pygame.draw.rect(s, (150,190,225), (cx, top, 14, 26), border_radius=3); pygame.draw.rect(s, (215,236,252), (cx, top, 6, 26), border_radius=3)
        pygame.draw.line(s, (150,190,225), (cx, top + 9), (cx + 13, top + 9), 1)
        pygame.draw.rect(s, (250,252,255), (cx - 3, top - 4, 20, 7), border_radius=4)   # snow on the chimney
    wr = pygame.Rect(8, base - 6, w - 16, h - base + 4)
    m = pygame.Surface((w, h), pygame.SRCALPHA); pygame.draw.rect(m, (255,255,255,255), wr, border_radius=14)
    lay = _ice_bricks(w, h, wr, ice, seed=w*7 + sum(wall)); lay.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN); s.blit(lay, (0, 0))
    sh = pygame.Surface((w, h), pygame.SRCALPHA); pygame.draw.rect(sh, (60,100,160,45), (wr.right - 22, wr.y, 22, wr.h)); sh.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN); s.blit(sh, (0, 0))
    pygame.draw.rect(s, (235,248,255), (wr.x + 4, wr.bottom - 7, wr.w - 8, 5), border_radius=3)   # snow banked at the bottom
    # domed ice-brick roof with a thick snow cap
    pts = [(x, _roof_y(x, w, base, roof_h)) for x in range(0, w + 1, 3)]
    rm = pygame.Surface((w, h), pygame.SRCALPHA); pygame.draw.polygon(rm, (255,255,255,255), pts + [(w, base + 2), (0, base + 2)])
    rlay = _ice_bricks(w, h, pygame.Rect(0, int(base - roof_h), w, roof_h + 4), _lerp((190,220,245), roof, 0.10), bh=8, bw=16, seed=w + 3)
    rlay.blit(rm, (0, 0), special_flags=pygame.BLEND_RGBA_MIN); s.blit(rlay, (0, 0))
    snow = [(x, y - 1) for x, y in pts]
    pygame.draw.lines(s, (250,253,255), False, snow, 7)
    for x in range(4, w - 3, 9):   # lumpy snow on top
        pygame.draw.circle(s, (250,253,255), (x, int(_roof_y(x, w, base, roof_h)) + 1), 4)
    pygame.draw.ellipse(s, (255,255,255), (w*0.2, base - roof_h*0.85, w*0.25, roof_h*0.22))
    pygame.draw.lines(s, (150,190,225), False, [(x, y + 3) for x, y in pts], 1)
    pygame.draw.rect(s, (180,212,240), (2, base - 2, w - 4, 7), border_radius=4)   # icy eave
    pygame.draw.rect(s, (250,253,255), (3, base - 3, w - 6, 4), border_radius=3)   # snow along it
    for k, x in enumerate(range(8, w - 6, 9)):   # icicles
        L = 4 + (k*5) % 7
        pygame.draw.polygon(s, (200,232,255), [(x - 2, base + 4), (x + 2, base + 4), (x, base + 4 + L)])
        pygame.draw.line(s, WHITE, (x - 1, base + 5), (x - 1, base + 3 + L//2), 1)
    return s
def _snow_box(s, x, y, w):   # window sill heaped with snow (instead of a flower box)
    pygame.draw.rect(s, (160,200,232), (x, y + 2, w, 6), border_radius=3); pygame.draw.rect(s, (215,236,252), (x, y, w, 5), border_radius=3)
    for fx in range(x + 3, x + w - 1, 5): pygame.draw.circle(s, (252,254,255), (fx, y - 1), 3)
def _with_ice(fn):   # build a picture with the same code, but ice bricks + snowy sills
    g = globals(); old = (g["_cottage"], g["_flower_box"])
    g["_cottage"], g["_flower_box"] = _ice_cottage, _snow_box
    try: return fn()
    finally: g["_cottage"], g["_flower_box"] = old
_ICE_ART = {}
def ice_house_image(wall):
    key = ("house", tuple(wall))
    if key not in _ICE_ART:
        def mk():
            roof = ROOF_COLS.get(tuple(wall), (250,160,170))
            s = _ice_cottage(120, 110, wall, roof, chimney_x=84)
            for wx in (28, 92): _round_window(s, wx, 76, 10); _snow_box(s, wx - 12, 88, 24)
            _cottage_door(s, 46, 74, 28, 36)
            _lantern(s, 80, 80)
            pygame.draw.ellipse(s, (215,232,248), (40, 104, 40, 6)); pygame.draw.ellipse(s, (250,253,255), (44, 104, 32, 3))   # snowy door step
            s = _ink(s, ICE_LINE, 2); _th_glint(s, 18, 60, 3); _th_glint(s, 104, 30, 2)
            return _ready(s)
        _ICE_ART[key] = mk()
    return _ICE_ART[key]
def ice_shop_front():
    if "shop" not in _ICE_ART:
        im = _with_ice(_make_shop_front); im = _ink(im, ICE_LINE, 1); _th_glint(im, 14, 60, 3)
        _ICE_ART["shop"] = _ready(im)
    return _ICE_ART["shop"]
def ice_cafe_front():
    if "cafe" not in _ICE_ART:
        im = _with_ice(_make_cafe_front).copy(); im = _ink(im, ICE_LINE, 1); _th_glint(im, 136, 62, 3)
        _ICE_ART["cafe"] = _ready(im)
    return _ICE_ART["cafe"]
def snow_village_tree(i):   # the level's snowy pine tree, in the village tree's 80x110 picture (same trunk spot = same hitbox)
    key = ("vtree", i)
    if key not in _ICE_ART:
        pine = obstacle_image("y_tree", i % 3)
        big = pygame.transform.smoothscale(pine, (80, 103))
        s = pygame.Surface((80, 110), pygame.SRCALPHA); s.blit(big, (0, 7))
        _ICE_ART[key] = _ready(s)
    return _ICE_ART[key]
def snowify_village():   # level 6 only: swap the village pictures (same sizes, so nothing else moves)
    if THEME[0] != "snow": return
    walls = [(255,230,150), (180,220,255), (255,190,210), (200,255,200), (240,240,240)]
    for i, h in enumerate(houses):
        im = ice_house_image(walls[i % len(walls)]); assert im.get_size() == h.image.get_size(); h.image = im
    j = 0
    for o in obstacles:
        if isinstance(o, VillageTree):
            im = snow_village_tree(j % 3); assert im.get_size() == o.image.get_size(); o.image = im; j += 1
    for b, mk in ((shop, ice_shop_front), (cafe, ice_cafe_front)):
        if b is not None:
            im = mk(); assert im.get_size() == b.image.get_size(); b.image = im
# ================= BACKGROUND MUSIC (Nov 3): "Fox Friends' Stroll" - an original, whimsical 8-bit tune made in code =================
# 6/8 skippy fairy-tale stroll in G major: pulse-wave melody, quiet pulse after-beats, bouncy triangle bass, soft ticks.
# 24 bars = 28.8 s, loops seamlessly. Built in a background thread so the game starts just as fast. S = music on/off.
import threading
from array import array
PREFS_FILE = os.path.expanduser('~/.jungle_foxes_prefs.json')   # tiny separate settings file (NOT the items save)
def load_prefs():
    try:
        if sys.platform == 'emscripten': d = json.loads(platform.window.localStorage.getItem('forestfox_prefs') or '{}')
        else:
            with open(PREFS_FILE) as fh: d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except Exception: return {}
def save_prefs(p):
    try:
        if sys.platform == 'emscripten': platform.window.localStorage.setItem('forestfox_prefs', json.dumps(p))
        else:
            with open(PREFS_FILE, 'w') as fh: json.dump(p, fh)
    except Exception: pass
MUSIC = {"on": bool(load_prefs().get("music", True)), "snd": None, "ok": False, "vol": 0.35}
MUSIC_SR, MUSIC_EIGHTH = 22050, 4410   # 0.2 s per eighth note (dotted quarter = 100 bpm), so bars land on exact samples
# melody: (midi note or None, length in eighths); every bar is 6 eighths
_MEL = [
    (71,2),(74,1),(79,2),(74,1),  (76,2),(72,1),(67,2),(72,1),  (78,2),(76,1),(74,1),(72,1),(69,1),  (71,2),(67,1),(74,3),
    (76,1),(78,1),(79,1),(83,2),(79,1),  (76,2),(72,1),(76,1),(79,1),(76,1),  (73,2),(76,1),(81,2),(79,1),  (78,1),(76,1),(74,1),(69,3),
    (79,1),(76,1),(72,1),(79,1),(76,1),(72,1),  (71,2),(74,1),(79,3),  (81,1),(79,1),(76,1),(72,2),(76,1),  (78,2),(81,1),(74,3),
    (74,2),(78,1),(83,2),(81,1),  (79,2),(76,1),(71,3),  (72,1),(76,1),(79,1),(78,1),(81,1),(86,1),  (79,3),(None,1),(74,1),(71,1),
    (67,2),(71,1),(74,2),(79,1),  (80,2),(76,1),(74,2),(71,1),  (72,2),(76,1),(81,2),(76,1),  (78,1),(79,1),(81,1),(78,2),(74,1),
    (83,2),(79,1),(74,2),(71,1),  (72,1),(76,1),(79,1),(76,2),(72,1),  (69,1),(72,1),(74,1),(78,1),(81,1),(84,1),  (83,2),(79,1),(74,1),(71,1),(69,1)]
# chords, one per half bar (3 eighths): (bass root, [two after-beat tones])
_G, _C, _D, _Em, _A7, _Am, _Bm, _E7, _D7 = (43,[59,62]), (48,[64,67]), (50,[66,69]), (52,[67,71]), (45,[61,67]), (45,[64,69]), (47,[62,66]), (40,[68,71]), (50,[66,72])
_CH = [_G,_G, _C,_C, _D,_D, _G,_G,  _Em,_Em, _C,_C, _A7,_A7, _D,_D,
       _C,_C, _G,_G, _Am,_Am, _D,_D,  _Bm,_Bm, _Em,_Em, _C,_D, _G,_G,
       _G,_G, _E7,_E7, _Am,_Am, _D,_D,  _G,_G, _C,_C, _D7,_D7, _G,_G]
def _hz(m): return 440.0 * 2 ** ((m - 69) / 12.0)
def _note(buf, start, n, midi, amp, kind, duty=0.25):
    f = _hz(midi); step = f / MUSIC_SR; ph = 0.0
    a_, r_ = 60, min(400, n // 3)   # tiny attack/release ramps = no clicks
    dec = 1.0 / max(1, n)
    for i in range(n):
        ph += step; ph -= int(ph)
        if kind == 0: w = 1.0 if ph < duty else -1.0                      # pulse (square) wave
        else: w = 4.0 * ph - 1.0 if ph < 0.5 else 3.0 - 4.0 * ph            # triangle wave
        e = (1.0 - 0.45 * i * dec)                                          # gentle decay, chiptune style
        if i < a_: e *= i / a_
        elif i > n - r_: e *= (n - i) / r_
        buf[start + i] += int(amp * e * w)
def build_theme():
    E = MUSIC_EIGHTH; N = len(_CH) * 3 * E; buf = [0] * N; t = 0
    for m, L in _MEL:   # skippy staccato melody
        if m is not None: _note(buf, t*E, int(L*E*0.62) if L > 1 else int(E*0.7), m, 6500, 0, 0.25)
        t += L
    assert t * E == N
    for k, (root, tones) in enumerate(_CH):   # bouncy "oom-pah-pah" in 6/8
        s = k * 3 * E
        _note(buf, s, int(E*0.8), root if k % 2 == 0 else root + 7, 9000, 1)          # bass on the beat (root, then fifth)
        _note(buf, s + 2*E, int(E*0.5), root + 12, 5500, 1)                           # little bass hop up an octave
        for j, tn in enumerate(tones): _note(buf, s + (1+j)*E, int(E*0.35), tn, 2200, 0, 0.125)   # soft after-beat chord
    rnd = random.Random(7); lv = 0
    for k in range(len(_CH) * 3 // 1):   # soft "tick" on every beat (noise), quieter in between
        s = k * E; amp = 1300 if k % 3 == 0 else 500
        for i in range(260):
            if i % 3 == 0: lv = rnd.choice((-1, 1))
            buf[s + i] += int(amp * lv * (1 - i / 260.0))
    return array('h', [max(-32767, min(32767, v)) for v in buf])
def _music_worker():
    try:
        data = build_theme()
        snd = pygame.mixer.Sound(buffer=data.tobytes()); snd.set_volume(MUSIC["vol"])
        MUSIC["snd"] = snd; MUSIC["ok"] = True
        if MUSIC["on"]: MUSIC["ch"] = snd.play(loops=-1)
    except Exception:
        MUSIC["ok"] = False
def start_music():
    try:
        if not pygame.mixer.get_init(): pygame.mixer.init()
        snd = pygame.mixer.Sound('theme.ogg')
        snd.set_volume(MUSIC['vol'])
        MUSIC['snd'] = snd; MUSIC['ok'] = True
        # Playback starts after a player's first touch (mobile browser audio rule).
    except Exception: MUSIC['ok'] = False
def toggle_music():
    MUSIC["on"] = not MUSIC["on"]; save_prefs(dict(load_prefs(), music=MUSIC["on"]))
    try:
        if MUSIC["snd"] is not None:
            if MUSIC["on"]: MUSIC["snd"].stop(); MUSIC["ch"] = MUSIC["snd"].play(loops=-1)
            else: MUSIC["snd"].stop()
    except Exception: pass
def music_label():
    return otext(tinyfont, "S: music " + ("on" if MUSIC["on"] else "off"), (170,230,255) if MUSIC["on"] else (200,200,215))
def draw_sprint_meter(right_x, y, players):   # Nov 8: kid-friendly SPRINT meter, right under the music label
    for k, pf in enumerate(players[:2]):
        e = getattr(pf, "sprint_e", SPRINT_MAX); rest = getattr(pf, "sprint_rest", 0)
        if rest > 0: txt, col, frac, bar = f"SPRINT resting {(rest+59)//60}s", (205,205,220), 1 - rest/SPRINT_REST, (150,160,195)
        elif getattr(pf, "sprinting", False): txt, col, frac, bar = "SPRINT!", (255,230,90), e/SPRINT_MAX, (255,170,40)
        elif e >= SPRINT_MAX: txt, col, frac, bar = "SPRINT ready!", (140,255,150), 1.0, (90,220,110)
        else: txt, col, frac, bar = "SPRINT", (205,240,205), e/SPRINT_MAX, (90,200,110)
        if len(players) > 1: txt = ("P1 " if pf is fox else "P2 ") + txt
        lab = otext(tinyfont, txt, col); w_ = 150
        yy = y + k*(lab.get_height() + 22)
        screen.blit(lab, (right_x - lab.get_width(), yy))
        r = pygame.Rect(right_x - w_, yy + lab.get_height() + 2, w_, 12)
        pygame.draw.rect(screen, (30,40,60), r, border_radius=6)
        if frac > 0: pygame.draw.rect(screen, bar, (r.x, r.y, max(8, int(w_*frac)), r.h), border_radius=6)
        pygame.draw.rect(screen, WHITE, r, 2, border_radius=6)
start_music()
# ================= WIN SCREEN (Nov 3): frozen timer + a happy fox dance party =================
WON_SECS = [None, 0]   # [frozen value shown on the 'won' screen, last value shown before it]
def hud_secs(secs):   # the top timer: on the 'you beat all the levels' screen it stays at the value it had
    if state == "won":
        if WON_SECS[0] is None: WON_SECS[0] = WON_SECS[1]
        return WON_SECS[0]
    WON_SECS[0] = None; WON_SECS[1] = secs
    return secs
_DANCE_CONF = [((k*97) % 1200, (k*53) % 200, [(255,90,150), (90,200,255), (255,220,60), (120,220,120), (190,140,255)][k % 5], 1 + k % 3) for k in range(40)]
def _dancers():
    d = [("fox", (255,130,20), (200,85,0))]
    if two_player: d.append(("fox", (215,215,225), (140,140,155)))
    d += [("fox", fur, dk) for (_n, fur, dk, _l) in VILLAGER_INFO[:3]] + [("wiz",)] + [("fox", fur, dk) for (_n, fur, dk, _l) in VILLAGER_INFO[3:]] + [("shoo",)]
    return d
def draw_win_dance():   # everyone dances together in a row under the win panel (looks only)
    t = pygame.time.get_ticks(); ds = _dancers(); n = len(ds)
    gap = min(130, (WIDTH - 80) // n); x0 = WIDTH//2 - gap*(n - 1)//2; base_y = 640
    for k, (x, y, c, s) in enumerate(_DANCE_CONF):   # confetti fluttering down behind the dancers
        yy = 505 + (y + t//(14 + s*3)) % 190; xx = (x + int(14*math.sin(t/400.0 + k))) % WIDTH
        w = 3 + s if (t//150 + k) % 2 else 2
        pygame.draw.rect(screen, c, (xx, yy, w, 6 - s))
    beat = t / 400.0   # one dance step every 0.4 s (matches the music: 2 eighths)
    for i, dv in enumerate(ds):
        x = x0 + i*gap; ph = beat + i*0.5; step = int(ph) % 8
        hop = abs(math.sin(ph*math.pi)) * (22 if step in (0, 1, 4, 5) else 10)   # bouncy hops
        sq = max(0.0, 1 - hop/6.0) * 0.12                                         # squash when landing
        if dv[0] == "fox":
            spin = step == 6                                                      # a quick spin every 8 steps
            img = make_fox(dv[1], dv[2], pose=10 + (int(ph*4) % 8), mood="happy" if step % 2 else "talk")   # paws + tail wag
            im = pygame.transform.scale(img, (img.get_width()*2, img.get_height()*2))
            left = (step // 2) % 2 == 1
            if spin:
                u = ph - int(ph); w = max(4, int(abs(math.cos(u*math.pi)) * im.get_width())); left = u > 0.5
                im = pygame.transform.scale(im, (w, im.get_height()))
            if left: im = pygame.transform.flip(im, True, False)
            im = pygame.transform.rotate(im, 8*math.sin(ph*math.pi*0.5))        # side-to-side sway
            if sq: im = pygame.transform.scale(im, (int(im.get_width()*(1 + sq)), int(im.get_height()*(1 - sq))))
        elif dv[0] == "wiz":
            im = toon_wizard_img(t); im = pygame.transform.rotate(im, 10*math.sin(ph*math.pi*0.5))
            if sq: im = pygame.transform.scale(im, (int(im.get_width()*(1 + sq)), int(im.get_height()*(1 - sq))))
            hop *= 0.6
        else:   # Shoo Ball bounces like a ball
            img = _toon_c(("shoo", False, 0, step % 2 == 0), lambda: _toon_make_shoo(False, 0, step % 2 == 0))
            q = max(0.0, 1 - hop/5.0); z = 62.0 / max(1, img.get_width())   # ball-sized next to the foxes
            im = pygame.transform.scale(img, (int(img.get_width()*z*(1 + 0.18*q)), int(img.get_height()*z*(1 - 0.18*q))))
            hop *= 1.4
        pygame.draw.ellipse(screen, (60,40,90), (x - 28 + hop//3, base_y - 4, 56 - hop//1.5, 10))   # shadow shrinks on the hop
        screen.blit(im, (x - im.get_width()//2, base_y - im.get_height() - int(hop)))
        if (t//300 + i) % 5 == 0: _th_glint(screen, x + 26, base_y - 70 - int(hop), 4)   # little sparkles
def new_game():
    global start_ticks, spirit_active, boss, troll_acc, storm_on, boss_banner
    boss_banner = 0
    L = LEVELS[level-1]
    apply_level_layout(level)   # this level's spots for the village, cave and warp zone
    THEME[0] = L.get("theme"); CANDY[0] = THEME[0] == "candy"   # level look: snow / space / desert / candy / dungeon
    st = (int(1400*WS), ROCK_BAND + int(260*WS)) if L.get("mountain_start") else (int(600*WS), WORLD_H - int(800*WS))
    fox.start = st; fox2.start = (st[0] + 80, st[1])
    fox.reset(); fox2.reset()
    fox.hearts_left = fox2.hearts_left = HEART_LIMIT   # 4 hearts back per game, fresh every new game
    collectibles.empty(); obstacles.empty(); trolls.empty(); axes.empty(); bombs.empty(); splats.clear()
    KICK.clear(); kos.clear(); clangs.clear(); ouches.clear(); boss_sparks.clear(); bolts.clear(); festive_fw.clear(); storm_on = False; troll_acc = 0.0
    # stones are scattered everywhere (berries grow on the trees now, and sticks lie next to them)
    for _ in range(max(0, round(N_STONES*AREA) - LESS_ITEMS)):   # 50 fewer stones
        collectibles.add(Collectible(random.randint(100,WORLD_W-100), random.randint(100,WORLD_H-100), "stone"))
    for _ in range(round(N_MOUNTAIN_STONES*AREA)):   # the rocky mountains get extra stones
        collectibles.add(Collectible(random.randint(100,WORLD_W-100), random.randint(MOUNTAIN_BAND+20, ROCK_BAND-40), "stone"))
    cz = pygame.Rect(0, 0, 300, 300); cz.center = CAVE_RECT.center
    safe_zones = [pygame.Rect(st[0]-200, st[1]-200, 400, 400), cz,
                  VILLAGE_RECT.inflate(200, 200), POND_RECT.inflate(200, 200), BERRY_CAVE_RECT.inflate(300, 300)]
    while len(obstacles) < round(N_OBSTACLES*AREA):
        o = Obstacle(random.randint(200,WORLD_W-200),random.randint(200,WORLD_H-200),random.choice(["tree","rock"]))
        if not any(o.rect.colliderect(z) for z in safe_zones):
            obstacles.add(o)
    extra = 0
    while extra < round(L.get("extra_rocks", 0)*AREA):   # Rocky Road: lots more rocks
        o = Obstacle(random.randint(200,WORLD_W-200),random.randint(200,WORLD_H-200),"rock")
        if not any(o.rect.colliderect(z) for z in safe_zones):
            obstacles.add(o); extra += 1
    houses.clear(); house_plates_eaten.clear(); CAFE_STOCK[0] = CAFE_MUFFINS; cocoa_steam[0] = 0   # every house's berry plate is full again
    # two rows of houses inside the village, with an open square in the middle
    spots = [(VILLAGE_RECT.x+180+i*280, VILLAGE_RECT.y+190) for i in range(4)] + \
            [(VILLAGE_RECT.x+180+i*280, VILLAGE_RECT.bottom-230) for i in range(4)]
    walls = [(255,230,150), (180,220,255), (255,190,210), (200,255,200), (240,240,240)]
    for i, (hx, hy) in enumerate(spots):
        h = House(hx, hy, walls[i % len(walls)])
        if CANDY[0]: h.image = ginger_house(i % 3)   # gingerbread houses in Candyland
        houses.append(h); obstacles.add(h)
    # trees between the houses (and at each end of the rows)
    shades = [(40,150,60),(60,170,70),(30,130,50)]
    for row_y in (spots[0][1], spots[4][1]):
        xs = [spots[0][0]-150] + [spots[i][0]+140 for i in range(3)] + [spots[3][0]+150]
        for j, tx in enumerate(xs):
            vt = VillageTree(tx, row_y, shades[j % 3])
            if CANDY[0]: vt.image = candy_village_tree(j % 3)
            obstacles.add(vt)
    for o in list(obstacles):   # keep the warp zone and its landing spot clear
        if o.rect.colliderect(WARP_RECT.inflate(160, 160)) or o.rect.colliderect(WARP_LAND): o.kill()
    for pt in POND_TREE_SPOTS():   # 2 trees right beside the Frog Pond (outside POND_SAFE, so swimming still works)
        pt_tree = Obstacle(pt[0], pt[1], "tree")
        for o in list(obstacles):
            if o.rect.colliderect(pt_tree.rect.inflate(30, 30)): o.kill()   # no overlapping rocks/trees
        obstacles.add(pt_tree)
    global shop
    shop = Shop(VILLAGE_RECT.centerx+420, VILLAGE_RECT.centery)
    obstacles.add(shop)
    global cafe   # the Fox Cafe: top-left part of the village, between the 1st and 2nd houses, above the road
    cafe = Cafe(VILLAGE_RECT.x+320, VILLAGE_RECT.y+305)
    obstacles.add(cafe)
    snowify_village()   # level 6 (snow) only: ice-brick village + snowy pines (same sizes/hitboxes)
    villagers.clear()
    for info in VILLAGER_INFO: villagers.append(VillageFox(*info))
    for c in list(collectibles):
        if pygame.sprite.spritecollideany(c, obstacles) or c.rect.collidelist(POND_BLOCKS) != -1 \
           or c.rect.collidelist([VILLAGE_RECT, CAVE_RECT.inflate(40,40), BERRY_CAVE_RECT.inflate(40,40), WARP_RECT.inflate(40,40)]) != -1:
            c.kill()
    grow_tree_berries(max(0, round(L.get("tree_berries", N_TREE_BERRIES)*AREA) - LESS_ITEMS), max(0, round(N_TREE_STICKS*AREA) - LESS_ITEMS))   # 50 fewer berries + sticks
    fill_berry_cave()
    place_specials(st)
    place_rubies(st); ruby_pops.clear()
    place_golden(st)   # golden berries are back (speed boost!)
    for _ in range(round(L["trolls"]*AREA) if TROLLS_ON else 0):
        while True:
            tp = (random.randint(int(1500*WS),WORLD_W-int(1500*WS)), random.randint(int(800*WS),WORLD_H-int(1500*WS)))
            if math.hypot(tp[0]-st[0], tp[1]-st[1]) > 700*WS: break   # never right next to the start
        trolls.add(Troll(*tp))
    gspots = []
    for _ in range(3 if TROLLS_ON and not L.get("no_trolls") else 0):   # 3 extra DARK GREEN trolls (none on level 2), spread out and away from the start
        for tries in range(400):
            tp = (random.randint(int(1500*WS), WORLD_W-int(1500*WS)), random.randint(int(800*WS), WORLD_H-int(1500*WS)))
            if math.hypot(tp[0]-st[0], tp[1]-st[1]) > 1500*WS and all(math.hypot(tp[0]-q[0], tp[1]-q[1]) > 2500*WS for q in gspots) \
               and not any(z.collidepoint(tp) for z in (VILLAGE_RECT.inflate(200,200), CAVE_RECT.inflate(200,200), BERRY_CAVE_RECT.inflate(200,200), POND_SAFE.inflate(100,100))):
                break
        gspots.append(tp); trolls.add(GreenTroll(*tp))
    boss = Boss() if L.get("finale") else None   # the BOSS TROLL only shows up on the finale (guarding Fox Village)
    theme_setup(st)   # decorations (and desert scorpion holes) for themed levels
    fox.cold = 0; fox2.cold = 0; fox.frozen = fox2.frozen = False; freeze_t[0] = 0; game_over_why[0] = ""
    warp_fx.clear(); warp_cd[0] = 0; dust.clear()   # fresh start on every (re)try
    fox.inventory["dagger"] = 0                     # the dagger never carries over: visit Dorfghan again
    globals()["wiz_was_near"] = False; globals()["wizard_talk"] = 0
    TASK["n"] = 0; TASK["done_t"] = 0; TASK["nag"] = 0; TASK["dagger"] = False
    LOCK["cd"] = LOCK["msg"] = LOCK["open"] = 0; barrier_sparks.clear()   # the barrier is back up (boss is back)
    for pf in (fox, fox2): pf.lock_bump = False; pf.lock_kick = 0; pf.lock_dir = (-1, 0)
    level_banner[0] = 300; rage_banner[0] = 0
    globals()["dagger_t"] = 0; globals()["dagger_cd"] = 0
    spirit_active = False
    globals().update(shoo_follow=False, shoo_room=None, shoo_talk=0, shoo_shout=False); shoo_xy[0], shoo_xy[1] = SHOO_POS   # Shoo Ball waits in the cave again
    fireworks.clear()
    start_ticks = pygame.time.get_ticks()

new_game()
camera_x = camera_y = 0
CAM_FOX_DOWN = 75   # Nov 3: camera shows the fox 75 px below the screen middle (looks only; edges still clamp)
state = "menu"
crafting_open = False
craft_pause_start = 0   # when crafting opened (game is frozen while crafting)
_HUD_BAR = []
picked_order = []   # most recent pickup is last

# (no drop button any more: items can't be dropped)
autosave_frames = 0
last_tick = pygame.time.get_ticks()

# Phone-only compatibility layer: original gameplay remains unchanged.
MOBILE_FINGERS = {}
MOBILE_HELD = set()
MOBILE_AUDIO_STARTED = False
MOBILE_FONT = pygame.font.Font(None, 29)
MOBILE_FONT_SMALL = pygame.font.Font(None, 25)
def mobile_buttons():
    if state == 'menu':
        return [(pygame.Rect(440,540,320,95),'PLAY!',pygame.K_SPACE),
                (pygame.Rect(1040,610,140,65),'Music',pygame.K_s)]
    buttons = [
      (pygame.Rect(25,590,94,88),'<',pygame.K_LEFT),
      (pygame.Rect(125,495,94,88),'UP',pygame.K_UP),
      (pygame.Rect(125,590,94,88),'DOWN',pygame.K_DOWN),
      (pygame.Rect(225,590,94,88),'>',pygame.K_RIGHT),
      (pygame.Rect(1035,575,145,100),'AXE',pygame.K_x),
      (pygame.Rect(880,575,145,100),'TALK',pygame.K_t),
      (pygame.Rect(725,575,145,100),'BOMB',pygame.K_b),
      (pygame.Rect(1035,495,145,70),'CRAFT',pygame.K_c),
      (pygame.Rect(880,495,145,70),'LEAVE',pygame.K_e),
      (pygame.Rect(725,495,145,70),'DAGGER',pygame.K_d),
      (pygame.Rect(335,610,115,65),'Pause',pygame.K_p),
      (pygame.Rect(455,610,115,65),'Music',pygame.K_s)]
    if state == 'playing' and not crafting_open:   # Nov 8: big SPRINT button (hold it with a second finger while running)
        buttons.append((pygame.Rect(580,495,138,180),'SPRINT',pygame.K_LSHIFT))
    if crafting_open or state == 'cafe':
        buttons += [(pygame.Rect(500,500,100,85),'1',pygame.K_1),(pygame.Rect(610,500,100,85),'2',pygame.K_2)]
    if crafting_open or state in ('shop','cafe','level_done','won','game_over','paused'):
        label, key = ('RETRY',pygame.K_r) if state in ('won','game_over') else ('RESUME',pygame.K_p) if state == 'paused' else ('BUY',pygame.K_SPACE) if state in ('shop','cafe') else ('CLOSE' if crafting_open else 'NEXT',pygame.K_SPACE)
        buttons = [b for b in buttons if b[2] != pygame.K_x]
        buttons.append((pygame.Rect(1035,575,145,100),label,key))
    return buttons

def mobile_key_at(pos):
    for rect,label,key in reversed(mobile_buttons()):
        if rect.collidepoint(pos): return key
    return None

def mobile_events():
    global MOBILE_HELD, MOBILE_AUDIO_STARTED
    incoming = pygame.event.get(); out=[]
    for event in incoming:
        old = set(MOBILE_FINGERS.values()) - {None}
        if event.type in (pygame.FINGERDOWN,pygame.FINGERMOTION):
            MOBILE_FINGERS[event.finger_id] = mobile_key_at((event.x*WIDTH,event.y*HEIGHT))
        elif event.type == pygame.FINGERUP:
            MOBILE_FINGERS.pop(event.finger_id,None)
        elif event.type in (pygame.MOUSEBUTTONDOWN,pygame.MOUSEBUTTONUP,pygame.MOUSEMOTION) and not getattr(event,'touch',False):
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1: MOBILE_FINGERS['mouse'] = mobile_key_at(event.pos)
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1: MOBILE_FINGERS.pop('mouse',None)
            elif event.type == pygame.MOUSEMOTION and 'mouse' in MOBILE_FINGERS: MOBILE_FINGERS['mouse']=mobile_key_at(event.pos)
        elif event.type in (getattr(pygame,'WINDOWFOCUSLOST',-999),pygame.ACTIVEEVENT):
            MOBILE_FINGERS.clear()
            out.append(event)
        else: out.append(event)
        new = set(MOBILE_FINGERS.values()) - {None}
        for key in new-old: out.append(pygame.event.Event(pygame.KEYDOWN,key=key,unicode=''))
        for key in old-new: out.append(pygame.event.Event(pygame.KEYUP,key=key))
        if (new or event.type==pygame.KEYDOWN) and not MOBILE_AUDIO_STARTED:
            MOBILE_AUDIO_STARTED=True
            try:
                if MUSIC['on'] and MUSIC['snd'] is not None: MUSIC['ch']=MUSIC['snd'].play(loops=-1)
            except Exception: pass
    MOBILE_HELD=set(MOBILE_FINGERS.values())-{None}
    # Never leave a fox running unseen under the rotate-phone message.
    if sys.platform == 'emscripten' and state == 'playing' and not crafting_open:
        try:
            if platform.window.innerHeight > platform.window.innerWidth or platform.document.hidden:
                MOBILE_FINGERS.clear(); MOBILE_HELD.clear()
                out.append(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_p,unicode=''))
        except Exception: pass
    return out

class MobileKeys:
    def __init__(self): self.physical=pygame.key.get_pressed()
    def __getitem__(self,key): return key in MOBILE_HELD or self.physical[key]

def draw_mobile_controls():
    overlay=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
    for rect,label,key in mobile_buttons():
        pressed=key in MOBILE_HELD
        pygame.draw.rect(overlay,(255,190,60,220) if pressed else (20,48,39,175),rect,border_radius=20)
        pygame.draw.rect(overlay,(255,227,146,240),rect,3,border_radius=20)
        if label == 'SPRINT':   # Nov 8: the button shows the sprint meter too
            e=getattr(fox,'sprint_e',SPRINT_MAX); rest=getattr(fox,'sprint_rest',0)
            if rest > 0: label, frac, bar = f'REST {(rest+59)//60}', 1-rest/SPRINT_REST, (150,160,195,235)
            else: frac, bar = e/SPRINT_MAX, ((255,170,40,240) if getattr(fox,'sprinting',False) else (90,220,110,235))
            br=pygame.Rect(rect.x+14,rect.bottom-34,rect.w-28,16)
            pygame.draw.rect(overlay,(20,30,45,230),br,border_radius=8)
            if frac > 0: pygame.draw.rect(overlay,bar,(br.x,br.y,max(10,int(br.w*frac)),br.h),border_radius=8)
            pygame.draw.rect(overlay,(255,227,146,240),br,2,border_radius=8)
            txt=MOBILE_FONT.render(label,True,(255,249,220)); overlay.blit(txt,txt.get_rect(center=(rect.centerx,rect.centery-18)))
            continue
        txt=MOBILE_FONT.render(label,True,(255,249,220)); overlay.blit(txt,txt.get_rect(center=rect.center))
    if state == 'menu':
        txt=MOBILE_FONT_SMALL.render('Phone edition - turn sideways - tap PLAY!',True,(255,245,205))
        overlay.blit(txt,txt.get_rect(center=(600,665)))
    screen.blit(overlay,(0,0))

async def main():
    global IN, T6, _, a, autosave_frames, axe, b, bob, c, cafe_msg_t, camera_x, camera_y, can, can2, cdot, cfx, cfy, col, cp, craft_pause_start, crafting_open, current_house, cx_, d, dx, dx2, dy, dy2, ef, elapsed, energize_t, event, fr, frame_dt, frozen_over, ft, fw, gaps, gr, gt, h, h2, has_d, hb, hf, hit, hl1, ht, hud, hx, hx0, hy, i, inv, item, k, kettle_full, kettle_msg_t, kettle_touch_prev, keys, kz, last_tick, lbl, level, lines, ln, lt, lv, m, mini, ml, mx, mx0, my, near, nh, now_tick, nt, o, odot, ok, on, ox, oy, pause_start, pdot, pet_shoo, pf, plate_msg_t, players, pn, pt, px, py, pz, r, rain_end, raindrops, rd, rt, s, secs, shade, shop_msg_frames, shop_sel, side, sp, spirit_active, st, start_ticks, state, storm_on, surf, sway_, sx_, sy_, t, throw, tick_now, time_left_ms, timer, tk, tk_, touching, troll_acc, troll_over, troll_steps, tw, two_player, tx, ty, v, vr, vt, was_storm, x, y, zone
    while True:
        throw = False
        now_tick = pygame.time.get_ticks(); frame_dt = now_tick - last_tick; last_tick = now_tick
        for event in mobile_events():
            if event.type == pygame.QUIT: save_items(fox.inventory); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s: toggle_music(); continue   # S = music on/off (any screen)
                if state == "menu" and event.key in (pygame.K_1, pygame.K_KP1, pygame.K_2, pygame.K_KP2):
                    two_player = event.key in (pygame.K_2, pygame.K_KP2)   # 1 = one player, 2 = two players
                    continue
                if event.key == pygame.K_SPACE and state == "menu":
                    level = 1; state = "playing"; new_game()          # SPACE on the menu starts Level 1
                elif event.key == pygame.K_SPACE and state == "level_done":
                    save_items(fox.inventory)
                    level += 1; state = "playing"; new_game()         # on to the next level
                if event.key == pygame.K_r and state in ("won","game_over"):
                    save_items(fox.inventory)
                    if state == "won": level = 1                       # beat them all: start over from Level 1
                    state = "playing"; new_game()                      # game over: try the same level again
                if event.key in (pygame.K_x, pygame.K_a) and state == "playing": throw = True   # X or A throws an axe
                if event.key == pygame.K_d and state == "playing": swing_dagger()   # D swings the Glowing Dagger
                if event.key in (pygame.K_e, pygame.K_ESCAPE) and state == "inside": leave_house()
                elif event.key in (pygame.K_e, pygame.K_ESCAPE) and state == "cave": leave_cave()
                elif event.key in (pygame.K_e, pygame.K_ESCAPE) and state == "berry_cave": leave_berry_cave()
                if event.key == pygame.K_p and state == "playing" and not crafting_open:
                    state = "paused"; pause_start = pygame.time.get_ticks()
                elif event.key == pygame.K_p and state == "paused":
                    start_ticks += pygame.time.get_ticks() - pause_start   # timer froze while paused
                    state = "playing"
                if event.key == pygame.K_t and state == "cave": talk_wizard(); talk_shoo_ball()
                if event.key == pygame.K_t and state == "inside":
                    near = [hf for hf in house_folks if math.hypot(hf.rect.centerx-inside_fox.centerx, hf.rect.centery-inside_fox.centery) < 100]
                    if near: min(near, key=lambda v: math.hypot(v.rect.centerx-inside_fox.centerx, v.rect.centery-inside_fox.centery)).talk_frames = 240
                if event.key == pygame.K_t and state == "playing":
                    near = [v for v in villagers + frogs if math.hypot(v.rect.centerx-fox.rect.centerx, v.rect.centery-fox.rect.centery) < 100]
                    if near:
                        v = min(near, key=lambda v: math.hypot(v.rect.centerx-fox.rect.centerx, v.rect.centery-fox.rect.centery))
                        v.talk_frames = 240
                if state == "cafe":
                    if event.key in (pygame.K_e, pygame.K_ESCAPE): leave_cafe()
                    elif event.key in (pygame.K_1, pygame.K_KP1): cafe_pick[0] = 0          # pick Muffin
                    elif event.key in (pygame.K_2, pygame.K_KP2): cafe_pick[0] = 1          # pick Cocoa
                    elif event.key == pygame.K_TAB: cafe_pick[0] = 1 - cafe_pick[0]
                    elif event.key in (pygame.K_b, pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE): buy_cafe()
                    continue
                if state == "shop":
                    if event.key in (pygame.K_e, pygame.K_ESCAPE): leave_shop()
                    if event.key == pygame.K_UP: shop_sel = (shop_sel - 1) % len(SHOP_ITEMS)
                    if event.key == pygame.K_DOWN: shop_sel = (shop_sel + 1) % len(SHOP_ITEMS)
                    for i in range(len(SHOP_ITEMS)):
                        if event.key in (getattr(pygame, f"K_{i+1}"), getattr(pygame, f"K_KP{i+1}")): shop_sel = i
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_b): buy(shop_sel)   # B buys too
                    continue
                if event.key in (pygame.K_c, pygame.K_m) and state == "playing":   # C or M opens crafting (game pauses)
                    if not crafting_open:
                        crafting_open = True; craft_pause_start = pygame.time.get_ticks()
                    else:
                        crafting_open = False; start_ticks += pygame.time.get_ticks() - craft_pause_start   # timer froze while crafting
                elif event.key == pygame.K_SPACE and state == "playing" and crafting_open:   # SPACE also closes crafting
                    crafting_open = False; start_ticks += pygame.time.get_ticks() - craft_pause_start
                if event.key in (pygame.K_1,pygame.K_KP1) and crafting_open:
                    if fox.inventory["sticks"]>=3 and fox.inventory["stones"]>=2:
                        fox.inventory["sticks"]-=3; fox.inventory["stones"]-=2; fox.inventory["axes"]+=1
                if event.key in (pygame.K_2,pygame.K_KP2) and crafting_open:
                    inv = fox.inventory
                    if inv["berries"]>=10 and inv["sticks"]>=5 and inv["stones"]>=3:   # berry bomb: 10 berries + 5 sticks + 3 stones
                        inv["berries"]-=10; inv["sticks"]-=5; inv["stones"]-=3; inv["bombs"]=inv.get("bombs",0)+1
                if event.key == pygame.K_b and state == "playing" and fox.inventory.get("bombs",0) > 0:
                    bombs.add(BerryBomb(fox.rect.centerx, fox.rect.centery, fox.direction))
                    fox.inventory["bombs"] -= 1

        players = [pf for pf in ([fox, fox2] if two_player else [fox]) if not pf.out] or [fox]   # a ghost fox sits out
        if energize_t > 0: energize_t -= 1
        if state != "playing" and state != "paused": storm_on = False
        if state == "playing" and not crafting_open:   # crafting pauses everything: no monster can attack
            if any(pf.rect.colliderect(VILLAGE_RECT) for pf in players):
                start_ticks += frame_dt   # the timer stays frozen while the fox is in Fox Village
            elapsed = pygame.time.get_ticks() - start_ticks
            time_left_ms = max(0, level_time_ms() - elapsed)
            # LIGHTNING: every 60 s of game time (same clock as the countdown) comes a 5-second storm
            was_storm = storm_on
            storm_on = elapsed >= 60000 and elapsed % 60000 < 5000 and not LEVELS[level-1].get("no_storm")
            if storm_on and not was_storm: start_storm()
            troll_acc += LEVELS[level-1]["speed"] * (2 if storm_on else 1)
            troll_steps = int(troll_acc); troll_acc -= troll_steps

            keys = MobileKeys()
            if not fox.out: fox.update(keys, throw)
            if two_player and not fox2.out: fox2.update(keys, False)
            village_lock_step(players)
            autosave_frames += 1
            if autosave_frames % 180 == 0:   # save items every 3 seconds
                save_items(fox.inventory)
            for h in houses:
                if any(pf.rect.colliderect(h.door) for pf in players):
                    state = "inside"; current_house = h; enter_house_folks(h)
                    kettle_full = True; kettle_touch_prev = False; kettle_msg_t = 0   # fresh tea every visit
                    pause_start = pygame.time.get_ticks()
                    inside_fox.center = (ROOM.centerx, ROOM.bottom - 90)
                    inside_fox2.center = (ROOM.centerx + 80, ROOM.bottom - 90)
                    break
            if shop and any(pf.rect.colliderect(shop.door) for pf in players) and state == "playing":
                state = "shop"; crafting_open = False; shop_msg_frames = 0; shop_sel = 0
                pause_start = pygame.time.get_ticks()
            if cafe and any(pf.rect.colliderect(cafe.door) for pf in players) and state == "playing":
                enter_cafe()
            if any(pf.rect.colliderect(CAVE_DOOR) for pf in players) and state == "playing":
                enter_cave()
            if any(pf.rect.colliderect(BERRY_CAVE_DOOR) for pf in players) and state == "playing":
                enter_berry_cave()
            if state == "playing": update_warp(players)
            for v in villagers: v.update()
            for fr in frogs: fr.update()
            for t in trolls:   # each troll chases the closest fox
                t.update(min(players, key=lambda pf: math.hypot(pf.rect.centerx-t.rect.centerx, pf.rect.centery-t.rect.centery)))
            if boss: boss.update(troll_steps)
            axes.update()
            bombs.update()
            update_dagger()

            cfx = (fox.rect.centerx + fox2.rect.centerx)//2 if two_player else fox.rect.centerx   # two players: middle of both
            cfy = (fox.rect.centery + fox2.rect.centery)//2 if two_player else fox.rect.centery
            if two_player and (fox.out or fox2.out):   # one fox is a ghost: follow the one still playing
                cfx, cfy = (fox2 if fox.out else fox).rect.center
            camera_x = max(0, min(WORLD_W-WIDTH, cfx - WIDTH//2))
            camera_y = max(0, min(WORLD_H-HEIGHT, cfy - HEIGHT//2 - CAM_FOX_DOWN))   # fox sits a bit below the middle = more room to see ahead above her

            for pf in players:
              for item in pygame.sprite.spritecollide(pf, collectibles, True):
                pf.happy_t = 36; spawn_sparkles(item.rect.center, item.type)   # looks only: happy eyes + sparkles
                if item.type == "golden_berry":
                    pf.speed_boost = 4.0; pf.boost_frames = 600   # 10 seconds
                elif item.type == "berry":
                    fox.inventory["berries"]+=1; picked_order.append("berry")
                    if not getattr(item, "dropped", False): task_berry()   # a berry she dropped herself doesn't count twice
                elif item.type == "cave_entrance":
                    spirit_active = True
                elif item.type == "ruby":   # counts for the task (and is a tasty berry too)
                    tk = LEVELS[level-1].get("task") or ("ruby", 8)
                    TASK["n"] += 1; fox.inventory["berries"] += 1; picked_order.append("berry")
                    ruby_pops.append([pf.rect.centerx, pf.rect.top, 90, f"Ruby Berry! {min(TASK['n'], tk[1])}/{tk[1]}"])
                    if TASK["n"] == tk[1]: TASK["done_t"] = 180   # ding ding! task done
                elif item.type == "mushroom":
                    pf.dizzy = 600; pf.dz_t = 0                     # 10 s of zigzag running (no heart lost)
                elif item.type.startswith("meat"):
                    pf.meat_t = 600                                 # 10 s of DOUBLE speed
                else:
                    fox.inventory[item.type+"s"] += 1; picked_order.append(item.type)

            if spirit_active:
                # pet floats just behind the fox with a little bounce
                tx = fox.rect.centerx - fox.direction.x*45
                ty = fox.rect.centery - fox.direction.y*45 - 10 + 6*math.sin(pygame.time.get_ticks()/150)
                spirit.rect.centerx += (tx - spirit.rect.centerx)*0.08
                spirit.rect.centery += (ty - spirit.rect.centery)*0.08
                # pet protects the fox: trolls that come close get shooed away
                for t in trolls:
                    dx = t.rect.centerx - fox.rect.centerx
                    dy = t.rect.centery - fox.rect.centery
                    d = math.hypot(dx,dy)
                    if d < 170:
                        if d < 1: dx, dy, d = 1, 0, 1
                        t.rect.x += dx/d*6
                        t.rect.y += dy/d*6
                        pet_shoo = 30
                if pet_shoo > 0: pet_shoo -= 1

            if False and random.random() < rain_chance(players) and not raindrops:   # old random showers off: draw_weather rains all the time now   # rains a lot more up in the mountains
                raindrops = [(random.randint(0,WIDTH),random.randint(-HEIGHT,0),random.randint(8,14)) for _ in range(300)]
                rain_end = pygame.time.get_ticks() + 5000
            if raindrops and pygame.time.get_ticks() >= rain_end: raindrops = []

            if raindrops:
                for i,(x,y,s) in enumerate(raindrops):
                    raindrops[i] = (x,y+s,s)
                    if y>HEIGHT: raindrops[i] = (random.randint(0,WIDTH),-10,random.randint(8,14))

            for axe in axes:
                hit = pygame.sprite.spritecollide(axe, trolls, False)
                if hit:
                    for t in hit: hit_troll(t)   # green candy trolls need 3 axes
                    axe.kill()
                elif boss and axe.rect.colliderect(boss.rect):   # the boss can't be knocked out: CLANG!
                    clangs.append([axe.rect.centerx, axe.rect.centery, 45]); axe.kill()

            if update_cold(players): state = "freezing"     # frozen solid: game over (after a short shiver)
            for pf in players:   # trolls can hurt either fox (the hearts are shared)
              if pf.invuln > 0: pf.invuln -= 1
              hit = pygame.sprite.spritecollideany(pf, trolls)
              if hit and pf.invuln == 0:
                fx_hit(pf)   # looks only: impact burst
                pf.hearts -= 1; pf.invuln = 120   # each fox has her OWN hearts (2 seconds of blinking safety)
                knock_out(pf)
                tk_ = LEVELS[level-1].get("task")
                if tk_ and tk_[0] == "nohit":      # Level 3 no-hit challenge: any troll hit = try this level again
                    TASK["n"] += 1; game_over_why[0] = "troll_hit"; state = "game_over"
                dx = hit.rect.centerx - pf.rect.centerx; dy = hit.rect.centery - pf.rect.centery
                d = math.hypot(dx, dy) or 1
                hit.rect.x += dx/d*120; hit.rect.y += dy/d*120   # bump the troll back
              if boss and boss.stagger == 0 and pf.invuln == 0 and pf.rect.colliderect(boss.rect.inflate(16,16)) and not pf.rect.colliderect(VILLAGE_RECT):
                fx_hit(pf)   # looks only: impact burst
                pf.hearts -= 1; pf.invuln = 120                   # the boss catches: one heart from THAT fox, same safety window
                knock_out(pf)
                boss.bump_from(pf.rect.center)

            # trolls can never come into Fox Village or the Secret Cave: push any troll back out to the nearest edge
            for t in trolls:
                for zone in (VILLAGE_RECT, CAVE_RECT.inflate(80,80), BERRY_CAVE_RECT.inflate(80,80), POND_SAFE, WARP_RECT.inflate(60,60)):
                  if t.rect.colliderect(zone):
                    if zone is POND_SAFE: troll_bounce(t)
                    gaps = {"left": t.rect.right - zone.left, "right": zone.right - t.rect.left,
                            "top": t.rect.bottom - zone.top, "bottom": zone.bottom - t.rect.top}
                    side = min(gaps, key=gaps.get)
                    if side == "left": t.rect.right = zone.left
                    elif side == "right": t.rect.left = zone.right
                    elif side == "top": t.rect.bottom = zone.top
                    else: t.rect.top = zone.bottom
            if state == "game_over": pass   # the no-hit challenge just failed this frame
            elif (LEVELS[level-1].get("task") or ("",))[0] == "village" and any(pf.rect.colliderect(VILLAGE_RECT) for pf in players if not getattr(pf, "out", False)):   # Level 7: reaching Fox Village ends it (with 2+ hearts)
                if task_gate():
                    state = "won" if level >= len(LEVELS) else "level_done"
                    for _ in range(12): fireworks.append(Firework(WIDTH//2, HEIGHT//2))
            elif any(pf.rect.colliderect(STATUE_RECT) for pf in players) and task_gate() and task_done():   # level task must be done first (the ONLY way to finish a level)
                state = "won" if level >= len(LEVELS) else "level_done"   # each level ends at the golden statue
                for _ in range(12): fireworks.append(Firework(WIDTH//2, HEIGHT//2))
            elif state == "freezing": pass
            elif (TIMER_ON and time_left_ms<=0) or team_out():   # time up or no hearts left
                state = "game_over"

        elif state == "freezing":
            freeze_t[0] -= 1
            if freeze_t[0] <= 0: state = "game_over"
        elif state == "shop":
            if shop_msg_frames > 0: shop_msg_frames -= 1
        elif state == "cafe":
            keys = MobileKeys()
            dx = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * (0 if fox.out else 6)
            dy = (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * (0 if fox.out else 6)
            fox.pose(dx, dy)
            room_step(inside_fox, dx, dy, CAFE_BLOCKS)
            inside_fox.clamp_ip(pygame.Rect(ROOM.x+20, ROOM.y+180, ROOM.w-40, ROOM.h-180))
            if two_player:
                dx2 = (keys[pygame.K_l] - keys[pygame.K_j]) * (0 if fox2.out else 6)
                dy2 = (keys[pygame.K_k] - keys[pygame.K_i]) * (0 if fox2.out else 6)
                fox2.pose(dx2, dy2)
                room_step(inside_fox2, dx2, dy2, CAFE_BLOCKS)
                inside_fox2.clamp_ip(pygame.Rect(ROOM.x+20, ROOM.y+180, ROOM.w-40, ROOM.h-180))
            if cafe_msg_t > 0: cafe_msg_t -= 1
            if inside_fox.colliderect(INSIDE_DOOR) or (two_player and inside_fox2.colliderect(INSIDE_DOOR)):
                leave_cafe()
        elif state == "cave":
            keys = MobileKeys()
            dx = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * (0 if fox.out else 6)
            dy = (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * (0 if fox.out else 6)
            fox.pose(dx, dy)
            room_step(cave_fox, dx, dy, [CAVE_FIRE_BLOCK])
            cave_fox.clamp_ip(pygame.Rect(CAVE_ROOM.x+30, CAVE_ROOM.y+240, CAVE_ROOM.w-60, CAVE_ROOM.h-240))
            if two_player:
                dx2 = (keys[pygame.K_l] - keys[pygame.K_j]) * (0 if fox2.out else 6)
                dy2 = (keys[pygame.K_k] - keys[pygame.K_i]) * (0 if fox2.out else 6)
                fox2.pose(dx2, dy2)
                room_step(cave_fox2, dx2, dy2, [CAVE_FIRE_BLOCK])
                cave_fox2.clamp_ip(pygame.Rect(CAVE_ROOM.x+30, CAVE_ROOM.y+240, CAVE_ROOM.w-60, CAVE_ROOM.h-240))
            if cave_fox.colliderect(CAVE_EXIT) or (two_player and cave_fox2.colliderect(CAVE_EXIT)): leave_cave()
        elif state == "berry_cave":
            keys = MobileKeys()
            dx = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * (0 if fox.out else 6)
            dy = (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * (0 if fox.out else 6)
            fox.pose(dx, dy)
            room_step(cave_fox, dx, dy, [])
            cave_fox.clamp_ip(pygame.Rect(CAVE_ROOM.x+30, CAVE_ROOM.y+240, CAVE_ROOM.w-60, CAVE_ROOM.h-240))
            if two_player:
                dx2 = (keys[pygame.K_l] - keys[pygame.K_j]) * (0 if fox2.out else 6)
                dy2 = (keys[pygame.K_k] - keys[pygame.K_i]) * (0 if fox2.out else 6)
                fox2.pose(dx2, dy2)
                room_step(cave_fox2, dx2, dy2, [])
                cave_fox2.clamp_ip(pygame.Rect(CAVE_ROOM.x+30, CAVE_ROOM.y+240, CAVE_ROOM.w-60, CAVE_ROOM.h-240))
            pick_cave_berries()
            if cave_fox.colliderect(CAVE_EXIT) or (two_player and cave_fox2.colliderect(CAVE_EXIT)): leave_berry_cave()
        elif state == "inside":
            keys = MobileKeys()
            dx = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * (0 if fox.out else 6)
            dy = (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * (0 if fox.out else 6)
            fox.pose(dx, dy)
            room_step(inside_fox, dx, dy, [HOUSE_FIRE_BLOCK])
            for hf in house_folks: hf.update()
            inside_fox.clamp_ip(pygame.Rect(ROOM.x+20, ROOM.y+180, ROOM.w-40, ROOM.h-180))
            fox.health = min(100, fox.health + 0.1)
            if two_player:
                dx2 = (keys[pygame.K_l] - keys[pygame.K_j]) * (0 if fox2.out else 6)
                dy2 = (keys[pygame.K_k] - keys[pygame.K_i]) * (0 if fox2.out else 6)
                fox2.pose(dx2, dy2)
                room_step(inside_fox2, dx2, dy2, [HOUSE_FIRE_BLOCK])
                inside_fox2.clamp_ip(pygame.Rect(ROOM.x+20, ROOM.y+180, ROOM.w-40, ROOM.h-180))
                fox2.health = min(100, fox2.health + 0.1)
            kz = KETTLE_SPOT.inflate(10, 10)
            touching = 1 if inside_fox.colliderect(kz) else (2 if two_player and inside_fox2.colliderect(kz) else 0)
            if touching and not kettle_touch_prev: sip_kettle(touching)   # touch the kettle (no key needed)
            kettle_touch_prev = touching
            if kettle_msg_t > 0: kettle_msg_t -= 1
            pz = PLATE_SPOT.inflate(10, 10)   # walk up to the berry plate to eat (like the kettle: no key needed)
            if inside_fox.colliderect(pz): eat_plate(1)
            elif two_player and inside_fox2.colliderect(pz): eat_plate(2)
            if plate_msg_t > 0: plate_msg_t -= 1
            if inside_fox.colliderect(INSIDE_DOOR) or (two_player and inside_fox2.colliderect(INSIDE_DOOR)):
                leave_house()

        ghost_step()          # a knocked-out fox floats along as a little ghost (2 players)
        update_shoo_ball()
        if state == "playing" and not crafting_open: grr_step(players)   # "Grr!" when a fox gets away
        # DRAW
        screen.fill(GREEN)

        if state == "inside":
            draw_inside(); draw_indoor_anim("house")
            if two_player:
                blit_fox(screen, fox2.image, inside_fox2.topleft, fox2.face_left, 2); p2_label(inside_fox2.centerx, inside_fox2.y)
        elif state == "shop":
            draw_shop(); draw_indoor_anim("shop")
        elif state == "cafe":
            draw_cafe(); draw_indoor_anim("cafe")
            if two_player:
                blit_fox(screen, fox2.image, inside_fox2.topleft, fox2.face_left, 2); p2_label(inside_fox2.centerx, inside_fox2.y)
        elif state == "berry_cave":
            draw_berry_cave(); draw_indoor_anim("cave")
            if two_player:
                blit_fox(screen, fox2.image, cave_fox2.topleft, fox2.face_left, 2); p2_label(cave_fox2.centerx, cave_fox2.y)
        elif state == "cave":
            draw_cave(); draw_indoor_anim("cave")
            if two_player:
                blit_fox(screen, fox2.image, cave_fox2.topleft, fox2.face_left, 2); p2_label(cave_fox2.centerx, cave_fox2.y)
        elif state == "menu":
            screen.blit(MENU_BG, (0,0)); draw_menu_anim()   # BotW wind, leaves and light on the menu
            screen.blit(otext(bigfont, "FOREST FOX", (255,150,60), WHITE, 4), (WIDTH//2-304+4, 96+6))
            screen.blit(otext(bigfont, "FOREST FOX", YELLOW, INK, 4), (WIDTH//2-304, 96))
            bob = int(6*math.sin(pygame.time.get_ticks()/300))
            sway_ = int(round(3*math.sin(pygame.time.get_ticks()/1100.0)))
            blit_fox(screen, toon_menu_fox(False), (25 + sway_, 480+bob), False, 3)
            if two_player: blit_fox(screen, toon_menu_fox(True), (WIDTH-25-MENU_FOX2.get_width() - sway_, 480-bob), True, 5)
            for i,t in enumerate(["3-Min Speedrun","Huge map","Golden berries","Secret cave","Rain + fireworks","Cozy houses to explore","Fox friends + Berry Shop in the village","P = pause    S = music    SHIFT = sprint","Press SPACE"]):
                s = otext(tinyfont,t,WHITE)
                screen.blit(s,(WIDTH//2-s.get_width()//2,280+i*40))
            lv = otext(tinyfont, f"Level 1 of {len(LEVELS)-1} + Special", GOLD); screen.blit(lv, (WIDTH//2-lv.get_width()//2, 645))
            # pick one or two players
            for k, (lbl, on) in enumerate((("1 = ONE PLAYER", not two_player), ("2 = TWO PLAYERS", two_player))):
                m = otext(font, lbl, YELLOW if on else (190,200,215))
                mx = WIDTH//2 - 20 - m.get_width() if k == 0 else WIDTH//2 + 20
                if on: pygame.draw.rect(screen, YELLOW, (mx-10, 192, m.get_width()+20, m.get_height()+12), 3, border_radius=8)
                screen.blit(m, (mx, 198))
            if two_player:
                h2 = otext(tinyfont, "Player 1: arrows + SHIFT sprint     Player 2 (silver fox): I J K L + U sprint", (120,230,255))
                screen.blit(h2, (WIDTH//2-h2.get_width()//2, 248))
        else:
            # ground: soft anime grass tiles (only the ones on screen)
            T6 = TILE*6
            for x in range(max(0, camera_x//T6*T6), min(WORLD_W, camera_x+WIDTH+T6), T6):
                for y in range(max(0, camera_y//T6*T6), min(WORLD_H, camera_y+HEIGHT+T6), T6):
                    screen.blit(theme_tile(), (x-camera_x, y-camera_y))
            draw_space_backdrop(camera_x, camera_y)   # level 8: nebulas, far planets (parallax), dust specks - behind everyone
            draw_ground_anim(camera_x, camera_y)   # waving grass tufts / snow sparkle / heat shimmer / torchlight (looks only)
            # mountains with snowy tops
            if camera_y < 320 and THEME[0] not in ("space", "dungeon"):
                for x in range(0,WORLD_W,80):
                    mx = x-camera_x
                    if -250 < mx < WIDTH+10:
                        my = (200+80*math.sin(x*0.02))-camera_y
                        screen.blit(MOUNTAIN_IMG, (mx, my-205))

            # village ground with a dirt road and a welcome sign
            vr = VILLAGE_RECT.move(-camera_x, -camera_y)
            if vr.colliderect(screen.get_rect()): screen.blit(VILLAGE_IMG, vr.topleft)
            if CANDY[0] and village_locked(): draw_candy_village(camera_x, camera_y)   # cane posts only with the barrier (no leftover canes once the boss is beaten)
            # golden fox statue on a stone base
            st = STATUE_RECT.move(-camera_x, -camera_y)
            draw_statue_shimmer(st); screen.blit(STATUE_IMG, (st.x-20, st.y-20)); draw_statue_glint(st); draw_statue_wink(st)
            screen.blit(otext(tinyfont, "Touch the statue!", (255,230,120), (90,50,20)),(st.centerx-82, st.bottom+2))
            draw_village_barrier(camera_x, camera_y)
            draw_cave_outside(camera_x, camera_y)
            draw_berry_cave_outside(camera_x, camera_y)
            draw_warp(camera_x, camera_y)
            draw_pond(camera_x, camera_y); draw_pond_anim(camera_x, camera_y)
            draw_theme_decor(camera_x, camera_y)   # holes, torches, alien plants, drifts (looks only)
            for o in obstacles:
                ox, oy = o.draw_pos if isinstance(o, VillageTree) else o.rect.topleft
                blit_swaying(o, ox-camera_x, oy-camera_y)   # trees sway in the wind (same spot, same hitbox)
                draw_house_anim(o, ox-camera_x, oy-camera_y)   # window light flicker + roof pennant
                if isinstance(o, (House, Shop)) and -150 < ox-camera_x < WIDTH+20 and -150 < oy-camera_y < HEIGHT+20:
                    cx_ = 91 if isinstance(o, House) else 129
                    draw_chimney_smoke(screen, ox-camera_x+cx_, oy-camera_y+int(_roof_y(cx_-7, o.rect.w, 52 if isinstance(o, House) else 46, 46 if isinstance(o, House) else 42))-16, ox % 7)
                elif isinstance(o, Cafe) and -150 < ox-camera_x < WIDTH+20 and -150 < oy-camera_y < HEIGHT+20:
                    draw_chimney_smoke(screen, ox-camera_x+119, oy-camera_y+int(_roof_y(112, o.rect.w, 48, 40))-16, ox % 7)
            for s in collectibles:
                blit_item(s, camera_x, camera_y)   # soft bob + glow pulse (same size)
                if s.type == "golden_berry":   # golden twinkle so she can spot them
                    tw = (math.sin(pygame.time.get_ticks()/220 + s.rect.x) + 1) / 2
                    if tw > 0.5: _star_glint(screen, s.rect.right-camera_x-4, s.rect.y-camera_y+4, int(2 + 5*tw), (255,240,150))
                if s.type == "mushroom":   # a gentle twinkle on the dizzy cupcakes
                    tw = (math.sin(pygame.time.get_ticks()/300 + s.rect.x) + 1) / 2
                    if tw > 0.6: _star_glint(screen, s.rect.x-camera_x+6, s.rect.y-camera_y+12, int(2 + 4*tw), (255,245,255))
            tick_now = pygame.time.get_ticks()
            for t in trolls: draw_troll_full(t, camera_x, camera_y, players, tick_now)   # ANIMATED (Nov 3): walk cycle, arm swing, bob, blink, mouth, lean, turn squash
            if boss: boss.draw(camera_x, camera_y, players)
            for a in axes: screen.blit(a.image, a.image.get_rect(center=(a.rect.centerx-camera_x, a.rect.centery-camera_y)))
            for b in bombs: screen.blit(b.image,(b.rect.x-camera_x,b.rect.y-camera_y))
            for sp in splats[:]:
                r = int(170 * (1 - sp[2]/40)) + 10
                pygame.draw.circle(screen,(190,60,230),(int(sp[0]-camera_x),int(sp[1]-camera_y)),r,6)
                pygame.draw.circle(screen,(240,150,255),(int(sp[0]-camera_x),int(sp[1]-camera_y)),max(4,r//2),4)
                sp[2] -= 1
                if sp[2] <= 0: splats.remove(sp)
            for v in villagers: v.draw(screen, camera_x, camera_y)
            for fr in frogs: fr.draw(screen, camera_x, camera_y)
            if state == "playing":
                for v in villagers + frogs:
                    if v.talk_frames == 0 and math.hypot(v.rect.centerx-fox.rect.centerx, v.rect.centery-fox.rect.centery) < 100:
                        h = tinyfont.render(f"Press T to talk to {v.name}", True, YELLOW)
                        screen.blit(h, (fox.rect.centerx-camera_x-h.get_width()//2, fox.rect.bottom-camera_y+8)); break
            if spirit_active:
                toon_draw_spirit(camera_x, camera_y)
                if pet_shoo > 0:
                    screen.blit(tinyfont.render("Shoo!",True,YELLOW),(spirit.rect.x-camera_x-8,spirit.rect.y-camera_y-24))
            draw_dust(camera_x, camera_y)
            if getattr(fox, "frozen", False) and game_over_why[0] == "frozen":
                screen.blit(iced_image(fox.image), (fox.rect.x-camera_x, fox.rect.y-camera_y))
            elif not (fox.invuln > 0 and (fox.invuln//6) % 2 == 0):   # blink after a hit
                draw_fox_world(fox, camera_x, camera_y); draw_space_helmet(fox, camera_x, camera_y)
                draw_held_dagger(fox.rect.move(-camera_x, -camera_y), fox.face_left)
            if two_player:
                if getattr(fox2, "frozen", False) and game_over_why[0] == "frozen":
                    screen.blit(iced_image(fox2.image), (fox2.rect.x-camera_x, fox2.rect.y-camera_y))
                elif not (fox2.invuln > 0 and (fox2.invuln//6) % 2 == 0):
                    draw_fox_world(fox2, camera_x, camera_y); draw_space_helmet(fox2, camera_x, camera_y)
                p2_label(fox2.rect.centerx-camera_x, fox2.rect.y-camera_y)
            draw_shoo_ball(camera_x, camera_y)   # Shoo Ball trailing behind (after you talked to her in the Secret Cave)
            draw_ko_msg()
            draw_dagger_swing(camera_x, camera_y)
            if energize_t > 0:
                ef = fox2 if energize_who == 2 and two_player else fox
                draw_energize(ef.rect.centerx-camera_x, ef.rect.centery-camera_y, ef.rect.top-camera_y)
            draw_pops(camera_x, camera_y)
            draw_fx(camera_x, camera_y)
            draw_grr(camera_x, camera_y)
            draw_barrier_fx(camera_x, camera_y)
            draw_rubies(camera_x, camera_y)
            draw_power(camera_x, camera_y, players)
            draw_cold(camera_x, camera_y, players)

            update_draw_snow(camera_x, camera_y, state == "playing")
            # rain
            draw_ambient(camera_x, camera_y, players)   # drifting motes, kicked-up dust, cloud shadows (looks only)
            draw_theme_overlay(camera_x, camera_y)   # space sky / desert warmth / dungeon gloom
            draw_weather(camera_x, camera_y)   # gentle rain on every level (snow on level 6), never over Fox Village
            if storm_on: draw_storm(camera_x, camera_y, players)               # DARK GLOW lightning mode
            elif LEVELS[level-1].get("night"): screen.blit(NIGHT_TINT, (0,0))   # Night Run
            if LEVELS[level-1].get("finale") and state in ("playing", "paused") and THEME[0] != "dungeon": draw_festive()
            if state in ("playing", "paused"): draw_task_panel(); draw_level_banner(); draw_lock_popups()

            # HUD + big timer
            if not _HUD_BAR:   # soft cartoon HUD panel (no black bar)
                gr = _vgrad(WIDTH, 110, (92,70,150), (52,40,100)); m = pygame.Surface((WIDTH, 110), pygame.SRCALPHA)
                pygame.draw.rect(m, (255,255,255,255), (0, -24, WIDTH, 132), border_radius=26)
                hb = pygame.Surface((WIDTH, 110), pygame.SRCALPHA); hb.blit(gr, (0, 0)); hb.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
                pygame.draw.rect(hb, (175,150,235), (1, -24, WIDTH-2, 132), 3, border_radius=26)            # rounded glossy edge
                pygame.draw.rect(hb, (255,255,255,40), (14, 3, WIDTH-28, 18), border_radius=9)              # gloss band
                for sx_, sy_ in ((300,96),(720,94),(980,100)): _glint4(hb, sx_, sy_, 4, (255,240,170))
                _HUD_BAR.append(hb)
            screen.blit(_HUD_BAR[0], (0, 0))
            secs = max(0,(level_time_ms()-((pause_start if state=="paused" else craft_pause_start if (crafting_open and state=="playing") else pygame.time.get_ticks())-start_ticks))//1000)
            secs = hud_secs(secs)   # frozen on the win screen
            timer = f"{secs//60}:{secs%60:02d}"
            col = RED if secs<30 else YELLOW if secs<60 else WHITE
            if TIMER_ON:
                if any(pf.rect.colliderect(VILLAGE_RECT) for pf in players) and state == "playing":
                    col = (120,220,255)   # light blue = frozen
                    vt = tinyfont.render("Timer frozen in Fox Village", True, (120,220,255))
                    screen.blit(vt, (WIDTH//2-vt.get_width()//2, 82))
                screen.blit(otext(bigfont, timer, col, (55,35,95), 2),(WIDTH//2-100,10))   # bubbly outlined timer
            else:
                nt = font.render("No time limit!",True,YELLOW)
                screen.blit(nt,(WIDTH//2-nt.get_width()//2,30))
            # three hearts
            nh = max(4, min(MAX_HEARTS, fox.hearts))   # up to 6 hearts (tea gives extra ones)
            for i in range(nh):
                hx, hy = 22 + i*44, 18
                col = (240,50,70) if i < fox.hearts else (200,165,185)   # empty hearts: soft pink-gray
                screen.blit(heart_img(col, True), (hx-4, hy-3))   # anime heart (cel shading + outline + sparkle), same spot
            draw_p2_hearts()
            hud = f"{fox.inventory['berries']}"   # BERRY COUNTER (where hunger used to be)
            has_d = fox.inventory.get('dagger', 0) > 0
            if has_d: draw_hud_dagger(22 + nh*44 + 8, 26)
            hx0 = 160 + (nh-3)*44 + (36 if has_d else 0)
            screen.blit(_th_c("hud_crystal", lambda: pygame.transform.scale(collectible_image("s_crystal"), (34,34))) if is_space() else real_berry_small("strawberry", 34), (hx0, 14))
            screen.blit(font.render(hud,True,WHITE),(hx0 + 40,20))
            hl1 = otext(tinyfont, f"{'P1 ' if two_player else ''}Hearts left: {hearts_left(fox)}", WHITE, (85,60,150), 1)
            screen.blit(hl1, (hx0 + 40 + font.size(hud)[0] + 16, 22))   # small count next to the hearts + berries
            ln = LEVELS[level-1]["name"]
            lt = otext(tinyfont, ("SPECIAL FINALE: " + ln) if LEVELS[level-1].get("finale") else f"Level {level}: {ln}", GOLD)
            screen.blit(lt, (WIDTH - MINI_W - 30 - lt.get_width(), 14))
            screen.blit(tinyfont.render(f"{mat_word('sticks').capitalize()}:{fox.inventory['sticks']}  {mat_word('stones').capitalize()}:{fox.inventory['stones']}  {berry_word().capitalize()}:{fox.inventory['berries']}  Axes:{fox.inventory['axes']}  Bombs:{fox.inventory.get('bombs',0)}  Treasures:{sum(fox.inventory.get(k,0) for k in TREASURES)}" + (f"  Dagger:{fox.inventory.get('dagger',0)}" if fox.inventory.get('dagger',0) else ""),True,WHITE),(20,62))
            screen.blit(tinyfont.render("C or M = craft   X or A = axe   B = berry bomb   D = dagger   SHIFT = sprint",True,YELLOW),(20,86))

            # 4× BIG mini-map top-left
            mini = pygame.Surface((MINI_W,MINI_H), 0, 32)
            mini.fill({"candy": (240,175,205), "space": (90,80,120), "desert": (215,180,120), "dungeon": (70,66,82), "snow": (215,228,245)}.get(THEME[0], (70,130,80)))
            px = int(fox.rect.centerx * MINI_W // WORLD_W)
            py = int(fox.rect.centery * MINI_H // WORLD_H)
            pygame.draw.circle(mini,YELLOW,(px,py),6)
            pygame.draw.rect(mini,(200,150,100),(VILLAGE_RECT.x*MINI_W//WORLD_W, VILLAGE_RECT.y*MINI_H//WORLD_H,
                                                 max(8,VILLAGE_RECT.w*MINI_W//WORLD_W), max(8,VILLAGE_RECT.h*MINI_H//WORLD_H)))
            cdot = (CAVE_RECT.centerx*MINI_W//WORLD_W, CAVE_RECT.centery*MINI_H//WORLD_H)
            pygame.draw.circle(mini,(110,110,110),cdot,5)    # darker-gray edge so it stands out
            pygame.draw.circle(mini,(190,190,190),cdot,4)    # gray dot = secret cave
            pdot = (POND_RECT.centerx*MINI_W//WORLD_W, POND_RECT.centery*MINI_H//WORLD_H)
            pygame.draw.circle(mini,(30,80,160),pdot,6)
            pygame.draw.circle(mini,(70,150,255),pdot,5)     # blue dot = frog pond (25% smaller)
            for side in (-1, 1):   # the 2 pond trees: tiny tree marks either side of the pond dot
                tx, ty = pdot[0] + side*9, pdot[1] + side*1
                pygame.draw.rect(mini, (100,60,30), (tx-1, ty, 2, 3))
                pygame.draw.circle(mini, (20,70,25), (tx, ty-1), 3); pygame.draw.circle(mini, (60,160,60), (tx, ty-1), 2)
            # (no berry cave dot: the Berry Cave is a secret on the map)
            # (no warp dot: the warping zone is a secret to find on the map)
            if boss:
                odot = (boss.rect.centerx*MINI_W//WORLD_W, boss.rect.centery*MINI_H//WORLD_H)
                pygame.draw.circle(mini,(130,10,10),odot,11)
                pygame.draw.circle(mini,(235,30,30),odot,9)  # big red dot = BOSS TROLL
            for c in collectibles:
                if c.type == "ruby":   # red dot = Ruby Berry
                    rd = (c.rect.centerx*MINI_W//WORLD_W, c.rect.centery*MINI_H//WORLD_H)
                    pygame.draw.circle(mini,(120,10,30),rd,5); pygame.draw.circle(mini,(240,30,60),rd,4)
            pygame.draw.circle(mini,YELLOW,(px,py),6)   # fox stays on top
            if two_player:   # player 2 = cyan dot
                pygame.draw.circle(mini,(120,230,255),(int(fox2.rect.centerx*MINI_W//WORLD_W), int(fox2.rect.centery*MINI_H//WORLD_H)),6)
            mx0 = WIDTH - MINI_W - 20
            screen.blit(mini,(mx0,5))
            pygame.draw.rect(screen,YELLOW,(mx0,5,MINI_W,MINI_H),4)
            ml = music_label(); screen.blit(ml, (mx0 - 10 - ml.get_width(), 40))   # 'S: music on/off' next to the mini-map
            draw_sprint_meter(mx0 - 10, 40 + ml.get_height() + 8, players)   # Nov 8: SPRINT meter

            # 5: crafting menu
            if crafting_open and state == "playing":
                cp = pygame.Rect(WIDTH//2-310, HEIGHT//2-165, 620, 330)   # cream cartoon panel like the shop
                pn = pygame.Surface(cp.size, pygame.SRCALPHA); pygame.draw.rect(pn, (255,255,255), (0,0)+cp.size, border_radius=18)
                pn.blit(_vgrad(cp.w, cp.h, (255,244,220), (238,210,170)), (0,0), special_flags=pygame.BLEND_RGB_MULT)
                screen.blit(pn, cp.topleft)
                pygame.draw.rect(screen, GOLD, cp, 4, border_radius=18); pygame.draw.rect(screen, (170,120,70), cp.inflate(6,6), 2, border_radius=20)
                inv = fox.inventory
                can = inv["sticks"] >= 3 and inv["stones"] >= 2
                can2 = inv["berries"] >= 10 and inv["sticks"] >= 5 and inv["stones"] >= 3
                ok = (25,120,35); IN = (60,35,15)
                lines = [("CRAFTING - game paused  (press C, M or SPACE to close)", (150,60,20)),
                         (f"Press 1: AXE = 3 {mat_word('sticks')} + 2 {mat_word('stones')}" + ("   READY!" if can else ""), ok if can else IN),
                         (("Press 2: BERRY BOMB = 10 crystals + 5 dust + 3 rocks" if is_space() else "Press 2: BERRY BOMB = 10 berries + 5 sticks + 3 stones") + ("   READY!" if can2 else ""), ok if can2 else IN),
                         (f"You have: {inv['berries']} {berry_word()}, {inv['sticks']} {mat_word('sticks')}, {inv['stones']} {mat_word('stones')}", IN),
                         (f"Axes: {inv['axes']}   Berry bombs: {inv.get('bombs',0)}", IN),
                         ("X throws an axe.  B throws a berry bomb:", IN),
                         ("SPLAT! It scares away every troll nearby!", (140,30,150))]
                for i, (t, col) in enumerate(lines):
                    surf = shop_txt(tinyfont, t, True, col)
                    screen.blit(surf, (WIDTH//2 - surf.get_width()//2, HEIGHT//2-145 + i*42))
                    if i == 1: screen.blit(axe_art(), (WIDTH//2 - surf.get_width()//2 - 50, HEIGHT//2-145 + i*42 - 4))

            # fireworks
            if state in ("won", "level_done"):
                if len(fireworks) < 8:
                    fireworks.append(Firework(WIDTH//2, HEIGHT//2))
                for fw in fireworks[:]:
                    if not fw.update(): fireworks.remove(fw)
                    else: fw.draw(screen)

            if state=="level_done":
                draw_level_done()
            if state=="won":
                draw_victory(); draw_win_dance()
            if state=="game_over":
                frozen_over = game_over_why[0] == "frozen"
                cartoon_panel(WIDTH//2-360, 175, 720, 250, (120,170,230) if frozen_over else (125,90,195), (70,100,170) if frozen_over else (85,60,150))
                troll_over = game_over_why[0] == "troll_hit"
                gt = otext(bigfont, "FROZEN!" if frozen_over else "OOPS!" if troll_over else "GAME OVER" if team_out() else "TIME UP!", (200,240,255) if frozen_over else (255,235,150), th=3)
                if troll_over:
                    ft = otext(tinyfont, LEVELS[level-1].get("hit_msg", "Oops! A troll got you! Try Level {lv} again!").format(lv=level), WHITE, (85,60,150))
                    screen.blit(ft, (WIDTH//2-ft.get_width()//2, 295))
                if frozen_over:
                    ft = otext(tinyfont, "Brrr! Your fox froze in the mountains! Stay off the snow for too long.", WHITE, (50,80,140))
                    screen.blit(ft, (WIDTH//2-ft.get_width()//2, 295))
                screen.blit(gt, (WIDTH//2-gt.get_width()//2, 200))
                rt = otext(font, f"Press R to try Level {level} again", WHITE)
                screen.blit(rt, (WIDTH//2-rt.get_width()//2, 335))
            if state=="paused":
                shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); shade.fill((70,45,110,140))   # soft purple, not black
                screen.blit(shade,(0,0))
                pt = bigfont.render("PAUSED",True,YELLOW); screen.blit(pt,(WIDTH//2-pt.get_width()//2,HEIGHT//2-120))
                ht = font.render("Press P to keep playing",True,WHITE); screen.blit(ht,(WIDTH//2-ht.get_width()//2,HEIGHT//2+20))

        draw_mobile_controls()
        DISPLAY.blit(screen, (0, 0))
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

asyncio.run(main())
